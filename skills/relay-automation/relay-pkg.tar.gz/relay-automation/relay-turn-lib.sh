#!/usr/bin/env bash
# relay-turn-lib.sh — shared, model-AGNOSTIC safety core for headless relay turn-takers.
# SOURCED by codex-turn.sh and gemini-drive.sh (thin dispatch wrappers); not run on its own.
#
# Containment contract — decisions/2026-06-15-unattended-agent-containment.md (3-model validated):
#   (1) path-allowlist      — revert + FAIL on any change outside {relay file, ALLOW_PATHS}
#   (2) commit-bypass guard — reset --hard + FAIL if the agent committed during its own turn
#   (3) no push             — stage only the allowlist, commit file-scoped, never push
# Keeping this in ONE place means a new turn-taker (gemini-drive.sh, …) inherits the exact
# boundary instead of reimplementing it — reimplementation is where a fourth bypass sneaks in.
#
# API (all state in namespaced RTL_* globals):
#   rtl_init        <root> <relay_file> <allow_csv>   — set ROOT + build normalized allowlist
#   rtl_turn_prompt <agent> <relay_file> <task> <csv> — emit the shared ▶ TAKE-YOUR-TURN prompt
#   rtl_before                                         — snapshot HEAD before the agent runs
#   rtl_enforce     <task> <agent> <log> <tool>        — guards (2)+(1)+(3); EXITS 6 on violation
#   rtl_run_bounded <timeout_secs> <cmd...>            — run <cmd...> under a wall-clock cap;
#                                                        returns 0 on success, the cmd's own exit
#                                                        code on normal failure, or 7 on timeout-kill.
#                                                        No dependency on coreutils `timeout` (absent
#                                                        on stock macOS) — sleep+kill watchdog pattern
#                                                        (same as consult.sh _guarded). Kills by PID;
#                                                        see function body for the process-group gap.
#
# rtl_enforce deliberately `exit 6`s the calling shell on any violation — that fails the turn.
# rtl_run_bounded returns 7 on timeout; the CALLER must decide whether to continue to rtl_enforce
# (it should — a killed agent may have left off-lane changes) and then exit 7 after enforcement.
# Exit-code priority: containment violation (6) takes precedence over timeout (7). Rationale: a
# containment violation means unsafe state was left in the repo; that signal is more critical to
# surface than the mechanism (timeout) that caused the agent to be killed. A shim that detects a
# timeout should still call rtl_enforce, and if rtl_enforce exits 6 the process exits 6 — correct.
# If rtl_enforce completes without violation the shim then exits 7 to report the timeout.

rtl_init() {  # <root> <relay_file> <allow_csv>
  RTL_ROOT="$1"; local f="$2" csv="$3"
  RTL_ALLOW=("$f")
  local _extra p; IFS=',' read -ra _extra <<<"$csv"
  for p in "${_extra[@]:-}"; do [[ -n "$p" ]] && RTL_ALLOW+=("$p"); done
  local _n=() a                       # normalize to repo-root-relative (git status emits relative)
  for a in "${RTL_ALLOW[@]}"; do _n+=("${a#"$RTL_ROOT"/}"); done
  RTL_ALLOW=("${_n[@]}")
}

rtl_in_allow() { local x="$1" a; for a in "${RTL_ALLOW[@]}"; do [[ "$x" == "$a" ]] && return 0; done; return 1; }

rtl_run_bounded() {  # <timeout_secs> <cmd...>
  # Run <cmd...> under a wall-clock ceiling without coreutils `timeout` (absent on stock macOS).
  # Mirrors the consult.sh _guarded() pattern: sleep-then-kill watchdog, no external deps.
  # Process-group note: `setsid` is absent on stock macOS so we kill by PID (same as consult.sh).
  # A multi-process CLI whose children outlive the leader is a known gap; worktree isolation is
  # the airtight follow-up (ROADMAP 3.6). The PID kill is sufficient for hung single-process CLIs.
  # NOTE: disk-quota and per-turn spend ceilings are NOT yet enforced here — wall-clock only (R5
  # partial). Disk-quota belongs in a TMPDIR watchdog; spend ceilings are model-shim-specific.
  local secs="$1"; shift
  local apid kpid rc=0
  "$@" &
  apid=$!
  ( sleep "$secs"; kill -9 "$apid" 2>/dev/null ) >/dev/null 2>&1 &
  kpid=$!
  wait "$apid" 2>/dev/null || rc=$?
  kill "$kpid" 2>/dev/null || true; wait "$kpid" 2>/dev/null || true
  # Distinguish timeout-kill (signal 9 → exit 137) from a genuine rc=137 from the CLI itself.
  # We use rc=137 as the proxy for "killed by our watchdog" and map it to 7.
  # This is the same tradeoff consult.sh accepts: a CLI that genuinely crashes with rc=137 looks
  # like a timeout. Acceptable — both cases are "turn failed abnormally."
  if [[ "$rc" -eq 137 ]]; then
    return 7
  fi
  return "$rc"
}

# --- Worktree isolation (ROADMAP Part A Phase 3.6 — the airtight async/side-effect close) ----------
# OPT-IN: callers gate on RELAY_WORKTREE_ISOLATION=1. Default OFF → behaviour is unchanged.
# Run the agent turn in a THROWAWAY git worktree of RTL_ROOT@HEAD, so any async/background write
# lands in a tree we delete — RTL_ROOT is never the agent's target. This closes the gap left by the
# point-in-time `rtl_enforce` + the (macOS-absent) setsid process-group reap: ROOT safety no longer
# depends on killing the process group, because the agent can't reach ROOT in the first place.
# Coordination state (.tick) stays SHARED — the caller must run the agent with TICK_REPO_ROOT=RTL_ROOT.
rtl_worktree_begin() {
  # Create the worktree, seed the CURRENT working-tree allowlist into it (the HEAD checkout may be
  # stale, e.g. an uncommitted relay file), and echo the worktree path. Returns non-zero on failure
  # so the caller can fall back to an in-ROOT run. Sets RTL_WT.
  local wt a
  wt="$(mktemp -d "${TMPDIR:-/tmp}/rtl-wt.XXXXXX")" || return 1
  rm -rf "$wt"                         # git worktree add wants a non-existent path
  if ! git -C "$RTL_ROOT" worktree add --detach "$wt" HEAD >/dev/null 2>&1; then
    rm -rf "$wt" 2>/dev/null; return 1
  fi
  for a in "${RTL_ALLOW[@]}"; do       # seed current content (overwrite HEAD versions)
    if [[ -e "$RTL_ROOT/$a" ]]; then
      mkdir -p "$wt/$(dirname "$a")"
      cp -R "$RTL_ROOT/$a" "$wt/$a"
    fi
  done
  RTL_WT="$wt"
  printf '%s\n' "$wt"
}

rtl_worktree_end() {  # [<wt>] — sets RTL_WT_OFFLANE (0|1); copies allowlist back unless off-lane found
  # Contain + DETECT: if the agent touched anything outside {allowlist, .tick} in the worktree, that's
  # an off-lane attempt — do NOT copy anything back (the turn must fail like an in-ROOT exit-6), set
  # RTL_WT_OFFLANE=1, and destroy the worktree. Otherwise copy ONLY the allowlist back to RTL_ROOT
  # (forward-only: edits/creates propagate; deletions do not — v1) and destroy the worktree.
  local wt="${1:-${RTL_WT:-}}" a entry xy path
  RTL_WT_OFFLANE=0
  [[ -n "$wt" && -d "$wt" ]] || return 0
  while IFS= read -r -d '' entry; do
    [[ -n "$entry" ]] || continue
    xy="${entry:0:2}"; path="${entry:3}"
    case "$xy" in R*|C*) IFS= read -r -d '' _ || true ;; esac   # rename/copy: consume 2nd NUL field
    case "$path" in .tick/*|.tick) continue ;; esac
    rtl_in_allow "$path" && continue
    RTL_WT_OFFLANE=1                    # a non-allowlist, non-.tick change → off-lane
  done < <(git -C "$wt" status --porcelain -z 2>/dev/null)
  if ((RTL_WT_OFFLANE == 0)); then
    for a in "${RTL_ALLOW[@]}"; do
      if [[ -e "$wt/$a" ]]; then
        mkdir -p "$RTL_ROOT/$(dirname "$a")"
        cp -R "$wt/$a" "$RTL_ROOT/$a"
      fi
    done
  fi
  git -C "$RTL_ROOT" worktree remove --force "$wt" >/dev/null 2>&1 || rm -rf "$wt"
  git -C "$RTL_ROOT" worktree prune >/dev/null 2>&1 || true
  RTL_WT=""
}

rtl_turn_prompt() {  # <agent> <relay_file> <task> <allow_csv> [peer]
  local agent="$1" f="$2" task="$3" csv="$4" peer="${5:-}"
  # Name the peer explicitly when known — a live Gemini turn (2026-06-15) released the token to the
  # literal role "Producer" because "the other agent" was unnamed. RELAY_PEER closes that ambiguity.
  local handoff="release --to the other agent (the role named by NEXT in the file)"
  [[ -n "$peer" ]] && handoff="release --to ${peer}"
  printf 'You are agent %s, taking your turn in a file-based relay. Read %s and follow its embedded "\xe2\x96\xb6 TAKE YOUR TURN" steps for your role. Use ./bin/tick for the %s token (claim/ping, then %s, or done + set STATUS: Approved when approving). Edit ONLY %s%s. Do NOT run git (no add/commit/push) and do NOT touch any other file — the harness commits for you.' \
    "$agent" "$f" "$task" "$handoff" "$f" "${csv:+ and: $csv}"
}

rtl_before() {
  RTL_BEFORE_HEAD="$(git -C "$RTL_ROOT" rev-parse HEAD 2>/dev/null || echo none)"
  # Snapshot the PRE-turn dirty set (raw -z porcelain fields) so enforcement touches only the
  # agent's OWN changes — never pre-existing ambient WIP in the host repo (field report MBP16 [1]).
  RTL_BEFORE=()
  local fld
  while IFS= read -r -d '' fld; do RTL_BEFORE+=("$fld"); done \
    < <(git -C "$RTL_ROOT" status --porcelain -z 2>/dev/null)
}

rtl_was_dirty_before() {  # <porcelain-entry> — true if this exact status+path was dirty pre-turn
  local e="$1" b
  for b in ${RTL_BEFORE[@]+"${RTL_BEFORE[@]}"}; do [[ "$b" == "$e" ]] && return 0; done
  return 1
}

rtl_check() {  # <path> — reads RTL_ROOT/RTL_LOG_REL/RTL_TOOL, sets RTL_VIOLATION
  local p="$1"
  [[ -n "$p" ]] || return 0
  # tick's own state dir is coordination state the turn legitimately writes — exempt it intrinsically,
  # independent of whether the HOST repo gitignores .tick (field report MBP16 [2]).
  case "$p" in .tick/*|.tick) return 0 ;; esac
  # the shim's own transcript log, if it lands in the tree, is not an agent edit — drop it, don't flag
  if [[ -n "$RTL_LOG_REL" && "$p" == "$RTL_LOG_REL" ]]; then rm -f "$RTL_ROOT/$p"; return 0; fi
  rtl_in_allow "$p" && return 0
  printf '%s-turn: OFF-ALLOWLIST change: %s — reverting\n' "$RTL_TOOL" "$p" >&2
  git -C "$RTL_ROOT" checkout -- "$p" 2>/dev/null || rm -rf "$RTL_ROOT/${p%/}"
  RTL_VIOLATION=1
}

rtl_enforce() {  # <task> <agent> <log> <tool>
  local task="$1" agent="$2" log="$3"; RTL_TOOL="$4"
  # (2) commit-bypass guard: the agent must NOT git. If HEAD moved, its edits are hidden from
  # `git status` — undo the commit(s) and fail, so off-lane changes can't slip in committed.
  if [[ "$(git -C "$RTL_ROOT" rev-parse HEAD 2>/dev/null || echo none)" != "$RTL_BEFORE_HEAD" ]]; then
    git -C "$RTL_ROOT" reset --hard "$RTL_BEFORE_HEAD" >/dev/null 2>&1 || true
    printf '%s-turn: %s committed during its turn (forbidden) — reset to %s, failing\n' "$RTL_TOOL" "$agent" "${RTL_BEFORE_HEAD:0:8}" >&2
    exit 6
  fi
  # (1) allowlist enforcement on tracked-tree changes (.tick is gitignored, so token ops don't show).
  # -z = NUL-delimited RAW unquoted paths (spaces/special chars can't slip the match or break the
  # revert); rename/copy records (R/C) carry a second NUL field — check both old+new. We deliberately
  # do NOT `git clean -Xdf` (it would wipe .tick, the coordination state the turn legitimately writes);
  # ignored-file safety belongs to the agent sandbox, tracked as future.
  RTL_LOG_REL="${log:+${log#"$RTL_ROOT"/}}"
  RTL_VIOLATION=0
  # Pre-existing ambient WIP (same status+path as before the turn) is left untouched, never failed.
  # (Documented minor gap: a file already dirty that the agent edits further to the SAME status code
  # isn't caught — acceptable for review turns.)
  local entry xy path src
  while IFS= read -r -d '' entry; do
    [[ -n "$entry" ]] || continue
    xy="${entry:0:2}"; path="${entry:3}"
    case "$xy" in
      R*|C*)
        IFS= read -r -d '' src || true
        # A rename counts as pre-existing only if BOTH dest and src were dirty before — else enforce
        # both paths. Prevents a staged rename whose dest matches an ambient rename's dest from hiding
        # a clean file's move/deletion via the src field (Gemini review 2026-06-15, rename-hijack).
        if rtl_was_dirty_before "$entry" && rtl_was_dirty_before "$src"; then continue; fi
        rtl_check "$path"; rtl_check "$src"
        ;;
      *)
        rtl_was_dirty_before "$entry" && continue
        rtl_check "$path"
        ;;
    esac
  done < <(git -C "$RTL_ROOT" status --porcelain -z)
  ((RTL_VIOLATION == 0)) || { printf '%s-turn: off-lane edits reverted; failing the turn\n' "$RTL_TOOL" >&2; exit 6; }
  # (3) stage ONLY the allowlist; commit file-scoped; NO push.
  git -C "$RTL_ROOT" add -- "${RTL_ALLOW[@]}" 2>/dev/null || true
  if git -C "$RTL_ROOT" diff --cached --quiet; then
    printf '%s-turn: %s turn produced no tracked changes (token-only move?)\n' "$RTL_TOOL" "$agent"
  else
    git -C "$RTL_ROOT" commit -q -m "relay(${task}): ${agent} turn (${RTL_TOOL} headless; no push)"
    printf '%s-turn: committed %s turn (file-scoped, no push)\n' "$RTL_TOOL" "$agent"
  fi
}
