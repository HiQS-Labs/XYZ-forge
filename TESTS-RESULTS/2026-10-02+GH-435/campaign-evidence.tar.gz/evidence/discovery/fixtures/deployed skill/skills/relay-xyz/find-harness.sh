#!/usr/bin/env bash
#
# find-harness.sh — device-agnostic locator for the XYZ-forge relay harness.
#
# Prints the absolute path to the repo root that ships relay-automation/ (the relay
# harness: relay-drive.sh, the turn shims, poll.sh, bin/tick). It resolves WITHOUT any
# hardcoded machine path, so /relay-xyz works from any working directory — including
# when Skills Army copies the skill outside the harness repo.
#
# Usage:
#   find-harness.sh            # print the harness root, or error to stderr (exit 1)
#   find-harness.sh --root     # same as default
#   find-harness.sh --env      # print shell `export …` lines, safe to eval
#   find-harness.sh --check    # human-readable readiness checklist
#
# Resolution order (first hit wins):
#   1. $XYZ_HARNESS / $XYZ_REPO_ROOT          — explicit override
#   2. <caller-root>/.xyz                     — vendored local copy in the repo you're standing in
#   3. <main-checkout>/.xyz                   — vendored copy visible from a linked worktree
#   4. the current git repo root              — you're already standing in a harness clone
#   5. this script's own real location        — …/<repo>/skills/1-hourly/relay-xyz → <repo>
#   6. per-device config, then bounded canonical-clone search
#
# bash 3.2-safe (macOS default): no `readlink -f`, no associative arrays.
set -u

_has_harness() { [ -n "${1:-}" ] && [ -x "$1/relay-automation/relay-drive.sh" ]; }
_has_vendored_harness() { _has_harness "${1:-}" && [ -f "$1/bin/tick" ]; }
_canon_dir() { [ -n "${1:-}" ] && (cd "$1" >/dev/null 2>&1 && pwd); }
_canonical_clone() {
  _has_harness "${1:-}" || return 1
  [ "$(basename "$1")" = "XYZ-forge" ] || return 1
  _origin="$(git -C "$1" remote get-url origin 2>/dev/null || true)"
  case "$_origin" in
    https://github.com/HiQS-Labs/XYZ-forge|https://github.com/HiQS-Labs/XYZ-forge.git|git@github.com:HiQS-Labs/XYZ-forge|git@github.com:HiQS-Labs/XYZ-forge.git|ssh://git@github.com/HiQS-Labs/XYZ-forge|ssh://git@github.com/HiQS-Labs/XYZ-forge.git) return 0 ;;
  esac
  return 1
}
_branch() { git -C "$1" symbolic-ref --quiet --short HEAD 2>/dev/null || true; }
_short_sha() { printf '%.12s' "${1:-unknown}"; }
_read_source_commit() {
  [ -f "${1:-}/VERSION" ] || return 1
  while IFS='=' read -r _k _v; do
    [ "$_k" = "source_commit" ] || continue
    [ -n "$_v" ] || return 1
    printf '%s\n' "$_v"
    return 0
  done < "${1}/VERSION"
  return 1
}
_find_case_collision_pair() {
  [ -n "${1:-}" ] || return 0
  [ "$(git -C "$1" config --get core.ignorecase 2>/dev/null || true)" = "true" ] || return 0
  git -C "$1" ls-files 2>/dev/null | awk '
    {
      count = split($0, parts, "/")
      exact = ""
      lower = ""
      for (i = 1; i <= count; i++) {
        exact = exact (i > 1 ? "/" : "") parts[i]
        lower = lower (i > 1 ? "/" : "") tolower(parts[i])
        if ((lower in seen_exact) && seen_exact[lower] != exact) {
          print seen_path[lower] "\t" $0
          exit 0
        }
        if (!(lower in seen_exact)) {
          seen_exact[lower] = exact
          seen_path[lower] = $0
        }
      }
    }
  '
}

# --- parse arguments ---
QUIET=0
ACTION="root"
while [ "$#" -gt 0 ]; do
  case "$1" in
    --quiet|-q)
      QUIET=1
      shift
      ;;
    ""|--root)
      ACTION="root"
      shift
      ;;
    --env)
      ACTION="env"
      shift
      ;;
    --check)
      ACTION="check"
      shift
      ;;
    *)
      echo "usage: find-harness.sh [--root|--env|--check] [--quiet]" >&2
      exit 2
      ;;
  esac
done

# --- resolve this script's real directory (symlink-safe) ---
_src="${BASH_SOURCE[0]}"
while [ -h "$_src" ] || [ -L "$_src" ]; do
  _dir="$(cd -P "$(dirname "$_src")" >/dev/null 2>&1 && pwd)"
  _src="$(readlink "$_src")"
  case "$_src" in /*) ;; *) _src="$_dir/$_src" ;; esac
done
SELF_DIR="$(cd -P "$(dirname "$_src")" >/dev/null 2>&1 && pwd)"

HARNESS=""
VENDORED=0
CALLER_ROOT=""
VENDORED_COMMIT=""
LIVE_HARNESS=""
LIVE_HARNESS_HEAD=""
VENDORED_STATUS=""
MAIN_CHECKOUT_VENDORED=""
VIA=""
CONFIG_FILE="${XDG_CONFIG_HOME:-$HOME/.config}/xyz/harness"
SEARCH_CANDIDATES=("")
SEARCH_ROOTS=(
  "$HOME/Documents/GH Repos/XYZ-forge"
  "$HOME/Documents/GitHub/XYZ-forge"
  "$HOME/Documents/GitHub Repos/XYZ-forge"
  "$HOME/Documents/GitHub-Repos/XYZ-forge"
  "$HOME/Documents/Github/XYZ-forge"
  "$HOME/XYZ-forge"
  "$HOME/Developer/XYZ-forge"
)
_read_config() {
  [ -f "$CONFIG_FILE" ] || return 1
  _configured=""
  IFS= read -r _configured < "$CONFIG_FILE" || [ -n "${_configured:-}" ]
  [ -n "${_configured:-}" ] || return 1
  _canonical_clone "$_configured" || return 1
  _canon_dir "$_configured"
}
_search_clone() {
  SEARCH_CANDIDATES=("")
  FOUND_CLONE=""
  for _path in "${SEARCH_ROOTS[@]}"; do
    if _canonical_clone "$_path"; then
      _path="$(cd -P "$_path" >/dev/null 2>&1 && pwd)"
      _duplicate=0
      for _seen in "${SEARCH_CANDIDATES[@]:1}"; do
        [ "$_path" -ef "$_seen" ] && _duplicate=1 && break
      done
      [ "$_duplicate" = 1 ] || SEARCH_CANDIDATES+=("$_path")
    fi
  done
  [ "${#SEARCH_CANDIDATES[@]}" -gt 1 ] || return 1
  if [ "${#SEARCH_CANDIDATES[@]}" -eq 2 ]; then
    FOUND_CLONE="${SEARCH_CANDIDATES[1]}"
    return 0
  fi
  _development=("")
  for _path in "${SEARCH_CANDIDATES[@]:1}"; do
    [ "$(_branch "$_path")" = development ] && _development+=("$_path")
  done
  if [ "${#_development[@]}" -eq 2 ]; then
    FOUND_CLONE="${_development[1]}"
    return 0
  fi
  return 2
}

_g="$(git rev-parse --show-toplevel 2>/dev/null || true)"

# 1. explicit override
for _o in "${XYZ_HARNESS:-}" "${XYZ_REPO_ROOT:-}"; do
  if _has_harness "$_o"; then
    HARNESS="$(cd "$_o" && pwd)"
    VIA="override"
    if [ "$(basename "$HARNESS")" = ".xyz" ]; then
      VENDORED=1
      CALLER_ROOT="${_g:-$(git -C "$_o" rev-parse --show-toplevel 2>/dev/null || dirname "$(cd "$_o" && pwd)")}"
    fi
    break
  fi
done
# 2. vendored .xyz/ copy in the repo/PWD I'm standing in
if [ -z "$HARNESS" ]; then
  CALLER_ROOT="$_g"
  [ -n "$CALLER_ROOT" ] || CALLER_ROOT="${PWD:-$(pwd)}"
  _vendored="$CALLER_ROOT/.xyz"
  if _has_vendored_harness "$_vendored"; then
    HARNESS="$(cd "$_vendored" && pwd)"
    VENDORED=1
    VIA="caller-.xyz"
  fi
fi
# 3. vendored .xyz/ copy in the main checkout, when the caller is a linked
# worktree. Gitignored vendor files exist only in that main checkout.
if [ -z "$HARNESS" ] && [ -n "$_g" ] && [ "$(git rev-parse --is-bare-repository 2>/dev/null || true)" != "true" ]; then
  _common_dir="$(git rev-parse --path-format=absolute --git-common-dir 2>/dev/null || true)"
  if [ -n "$_common_dir" ] && [ -d "$_common_dir" ]; then
    _main_root="$(dirname "$_common_dir")"
    _main_vendored="$_main_root/.xyz"
    if [ -d "$_main_vendored" ]; then
      MAIN_CHECKOUT_VENDORED="$(_canon_dir "$_main_vendored" || true)"
      if _has_vendored_harness "$MAIN_CHECKOUT_VENDORED"; then
        HARNESS="$MAIN_CHECKOUT_VENDORED"
        VENDORED=1
        VIA="worktree-.xyz"
      fi
    fi
  fi
fi
# 4. current git repo (preserves "operate on the clone I'm standing in")
if [ -z "$HARNESS" ]; then
  if _has_harness "$_g"; then
    HARNESS="$_g"
    VIA="git-root"
  fi
fi
# 5. relative to this script (…/<repo>/skills/1-hourly/relay-xyz → <repo>) — fixes the
#    cross-repo case: the skill is global but the harness ships beside it.
if [ -z "$HARNESS" ]; then
  _cand="$(cd "$SELF_DIR/../../.." >/dev/null 2>&1 && pwd || true)"
  if _has_harness "$_cand"; then
    HARNESS="$_cand"
    VIA="self"
  fi
fi
# 6. a per-device pointer, then the known clone locations. Both require a
# canonical origin: a copied skill must not silently select a task clone.
CONFIG_PATH=""
if [ -z "$HARNESS" ]; then
  CONFIG_PATH="$(_read_config || true)"
  if [ -n "$CONFIG_PATH" ]; then
    HARNESS="$CONFIG_PATH"
    VIA="config"
  elif [ -f "$CONFIG_FILE" ]; then
    echo "find-harness: ignoring invalid config at $CONFIG_FILE" >&2
  fi
fi
SEARCH_STATUS=0
if [ -z "$HARNESS" ]; then
  _search_clone || SEARCH_STATUS=$?
  if [ "$SEARCH_STATUS" -eq 0 ]; then
    HARNESS="$FOUND_CLONE"
    VIA="search"
  fi
fi

if [ -z "$HARNESS" ]; then
  echo "find-harness: relay-automation/ harness not found." >&2
  echo "  attempted locations:" >&2
  [ -z "${XYZ_HARNESS:-}" ] || echo "    XYZ_HARNESS=$XYZ_HARNESS" >&2
  [ -z "${XYZ_REPO_ROOT:-}" ] || echo "    XYZ_REPO_ROOT=$XYZ_REPO_ROOT" >&2
  echo "    ${_g:-${PWD:-$(pwd)}}/.xyz" >&2
  [ -z "${_main_vendored:-}" ] || echo "    $_main_vendored" >&2
  [ -z "$_g" ] || echo "    $_g" >&2
  echo "    $SELF_DIR/../../.." >&2
  echo "    $CONFIG_FILE" >&2
  printf '    %s\n' "${SEARCH_ROOTS[@]}" >&2
  if [ "$SEARCH_STATUS" -eq 2 ]; then
    echo "  multiple canonical candidates:" >&2
    printf '    %s\n' "${SEARCH_CANDIDATES[@]:1}" >&2
  fi
  printf "  remedy: export XYZ_HARNESS='/path/to/XYZ-forge'; bash %q --check\n" "$SELF_DIR/find-harness.sh" >&2
  exit 1
fi

# The copied skill has no sibling relay-automation/. Load shared helpers from
# the chosen harness, including its driver lock resolver.
_hp_lib="$HARNESS/relay-automation/harness-paths.sh"
if [ -f "$_hp_lib" ]; then
  # shellcheck source=relay-automation/harness-paths.sh
  . "$_hp_lib"
fi

# TICK_REPO_ROOT is the repo root that bin/tick and tick-consuming shims expect.
# When a vendored .xyz/ copy is in play, $HARNESS is $CALLER_ROOT/.xyz — one
# directory too deep — so use the already-resolved caller root instead.
TICK_REPO_ROOT="$HARNESS"
[ "$VENDORED" = 1 ] && TICK_REPO_ROOT="$CALLER_ROOT"

if [ "$QUIET" = 0 ]; then
  echo "find-harness: HARNESS=$HARNESS REPO_ROOT=$TICK_REPO_ROOT vendored=$VENDORED via=$VIA" >&2
fi

# Vendored copies are opt-in fallbacks: warn on reachable drift, never block.
if [ "$VENDORED" = 1 ]; then
  for _o in "${XYZ_HARNESS:-}" "${XYZ_REPO_ROOT:-}"; do
    if _has_harness "$_o"; then
      _live="$(_canon_dir "$_o" || true)"
      if [ -n "$_live" ] && [ "$_live" != "$HARNESS" ]; then
        LIVE_HARNESS="$_live"
        break
      fi
    fi
  done
  if [ -z "$LIVE_HARNESS" ]; then
    _cand="$(_canon_dir "$SELF_DIR/../../.." || true)"
    if _has_harness "$_cand" && [ "$_cand" != "$HARNESS" ]; then
      LIVE_HARNESS="$_cand"
    fi
  fi
  if [ -z "$LIVE_HARNESS" ]; then
    _cand="$(_read_config || true)"
    if [ -n "$_cand" ] && [ "$_cand" != "$HARNESS" ]; then
      LIVE_HARNESS="$_cand"
    fi
  fi
  if [ -z "$LIVE_HARNESS" ] && _search_clone && [ "$FOUND_CLONE" != "$HARNESS" ]; then
    LIVE_HARNESS="$FOUND_CLONE"
  fi

  if [ -n "$LIVE_HARNESS" ]; then
    VENDORED_COMMIT="$(_read_source_commit "$HARNESS" || true)"
    LIVE_HARNESS_HEAD="$(git -C "$LIVE_HARNESS" rev-parse HEAD 2>/dev/null || true)"
    if [ -n "$VENDORED_COMMIT" ] && [ -n "$LIVE_HARNESS_HEAD" ]; then
      if [ "$VENDORED_COMMIT" = "$LIVE_HARNESS_HEAD" ]; then
        VENDORED_STATUS="current"
      elif git -C "$LIVE_HARNESS" merge-base --is-ancestor "$VENDORED_COMMIT" HEAD >/dev/null 2>&1; then
        VENDORED_STATUS="behind"
        {
          echo "find-harness: WARNING — vendored .xyz harness is behind the live harness."
          echo "  vendored: $(_short_sha "$VENDORED_COMMIT")"
          echo "  live:     $(_short_sha "$LIVE_HARNESS_HEAD")"
          echo "  remedy:   bash $LIVE_HARNESS/relay-automation/xyz-sync.sh update $CALLER_ROOT"
        } >&2
      else
        VENDORED_STATUS="different"
      fi
    else
      VENDORED_STATUS="different"
    fi

    if [ "$VENDORED_STATUS" = "different" ]; then
      echo "find-harness: vendored copy differs from or can't be compared to the live harness." >&2
    fi
  else
    VENDORED_STATUS="standalone"
  fi
fi

# --- capability probes (read-only; safe under any sandbox) ---
TICK="$HARNESS/bin/tick"; [ -x "$TICK" ] || TICK=""
_bin() { command -v "${1:-}" 2>/dev/null || true; }
CODEX_PATH="$(_bin "${CODEX_BIN:-codex}")"
AGY_PATH="$(_bin "${AGY_BIN:-agy}")"
# Antigravity installs agy at ~/.local/bin/agy on macOS by default (not on system PATH).
# Fall back to that well-known location when neither AGY_BIN nor PATH resolves it.
if [ -z "$AGY_PATH" ] && [ -z "${AGY_BIN:-}" ] && [ -x "$HOME/.local/bin/agy" ]; then
  AGY_PATH="$HOME/.local/bin/agy"
fi

# GH-346 Phase 2: commandcode and deepseek are shipped Path A workers, but neither was reported
# here, so "which workers can I use?" was answerable only by grepping relay-automation/. These
# flags are ADVISORY — nothing in the dispatch chain consumes them (route_agent and
# marathon-agent.sh key on the *_AGENT vars, not these), exactly like RELAY_HAS_CODEX/AGY. They
# close a discoverability gap, not a functional one.
COMMANDCODE_PATH="$(_bin "${COMMANDCODE_BIN:-cmd}")"
DEEPSEEK_PATH=""
if [ -f "$HARNESS/utils/py/deepseek-turn.py" ] && command -v python3 >/dev/null 2>&1 \
   && python3 -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,8) else 1)' 2>/dev/null; then
  _dsh_out="$(python3 "$HARNESS/utils/py/deepseek-turn.py" --print-bin 2>/dev/null || true)"
  if [ -n "$_dsh_out" ] && [ -e "$_dsh_out" ]; then
    DEEPSEEK_PATH="$_dsh_out"
  fi
fi

HAS_DEEPSEEK=0
if [ -n "$DEEPSEEK_PATH" ] && { [ -n "${OPENROUTER_API_KEY:-}" ] || [ -n "${DEEPSEEK_API_KEY:-}" ]; }; then
  HAS_DEEPSEEK=1
fi

_flag() { [ -n "${1:-}" ] && echo 1 || echo 0; }

case "$ACTION" in
  root)
    printf '%s\n' "$HARNESS"
    ;;
  env)
    printf 'export HARNESS=%q\n'         "$HARNESS"
    printf 'export TICK_REPO_ROOT=%q\n'  "$TICK_REPO_ROOT"
    [ -n "$TICK" ]       && printf 'export TICK=%q\n'       "$TICK"
    [ -n "$CODEX_PATH" ] && printf 'export CODEX_BIN=%q\n'  "$CODEX_PATH"
    [ -n "$AGY_PATH" ]   && printf 'export AGY_BIN=%q\n'    "$AGY_PATH"
    [ -n "$COMMANDCODE_PATH" ] && printf 'export COMMANDCODE_BIN=%q\n' "$COMMANDCODE_PATH"
    [ -n "$DEEPSEEK_PATH" ]    && printf 'export DEEPSEEK_BIN=%q\n'    "$DEEPSEEK_PATH"
    printf 'export RELAY_HAS_TICK=%s\n'  "$(_flag "$TICK")"
    printf 'export RELAY_HAS_CODEX=%s\n' "$(_flag "$CODEX_PATH")"
    printf 'export RELAY_HAS_AGY=%s\n'   "$(_flag "$AGY_PATH")"
    printf 'export RELAY_HAS_COMMANDCODE=%s\n' "$(_flag "$COMMANDCODE_PATH")"
    printf 'export RELAY_HAS_DEEPSEEK=%s\n'    "$HAS_DEEPSEEK"
    printf 'export XYZ_VENDORED=%s\n'    "$VENDORED"
    [ -n "$CALLER_ROOT" ]     && printf 'export XYZ_CALLER_ROOT=%q\n'     "$CALLER_ROOT"
    [ -n "$VENDORED_STATUS" ] && printf 'export XYZ_VENDORED_STATUS=%q\n' "$VENDORED_STATUS"
    [ -n "$VENDORED_COMMIT" ] && printf 'export XYZ_VENDORED_COMMIT=%q\n' "$VENDORED_COMMIT"
    true
    ;;
  check)
    mark() { if [ -n "${1:-}" ]; then echo "  ok  $2  ($1)"; else echo "  --  $2  (not found)"; fi; }
    _caller="$(git rev-parse --show-toplevel 2>/dev/null || true)"
    echo "relay harness readiness:"
    echo "  ok  harness  ($HARNESS)"
    if [ "$VENDORED" = 0 ] && _canonical_clone "$HARNESS"; then
      _configured_now="$(_read_config || true)"
      if [ "$_configured_now" != "$HARNESS" ]; then
        _config_dir="$(dirname "$CONFIG_FILE")"
        printf '  save this harness on this Mac: mkdir -p %q && printf %q %q > %q\n' \
          "$_config_dir" '%s\n' "$HARNESS" "$CONFIG_FILE"
      fi
    fi
    if [ "$VENDORED" = 0 ] && git -C "$HARNESS" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
      _h_branch="$(_branch "$HARNESS")"
      if [ "$_h_branch" != development ]; then
        echo "  !   harness clone is on ${_h_branch:-detached HEAD}, expected development"
      fi
      _upstream="$(git -C "$HARNESS" rev-parse --abbrev-ref --symbolic-full-name '@{u}' 2>/dev/null || true)"
      if [ -n "$_upstream" ]; then
        _behind="$(git -C "$HARNESS" rev-list --count "HEAD..$_upstream" 2>/dev/null || true)"
        if [ -n "$_behind" ] && [ "$_behind" -gt 0 ]; then
          _fetch_path="$(git -C "$HARNESS" rev-parse --path-format=absolute --git-path FETCH_HEAD 2>/dev/null || true)"
          _last_fetch="unknown"
          if [ -n "$_fetch_path" ] && [ -f "$_fetch_path" ]; then
            _last_fetch="$(date -r "$_fetch_path" '+%Y-%m-%d %H:%M:%S %Z' 2>/dev/null || echo unknown)"
          fi
          echo "  !   harness clone is $_behind commits behind $_upstream (last fetch $_last_fetch)"
        fi
      fi
    fi
    if [ "$VENDORED" = 1 ]; then
      echo "  ok  vendored resolution  ($HARNESS)"
      case "$VENDORED_STATUS" in
        current)
          echo "  ok  vendored copy is current with the live harness ($(_short_sha "$VENDORED_COMMIT") = $(_short_sha "$LIVE_HARNESS_HEAD"))"
          ;;
        behind)
          echo "  !   vendored copy is behind the live harness ($(_short_sha "$VENDORED_COMMIT") < $(_short_sha "$LIVE_HARNESS_HEAD")); run: bash $LIVE_HARNESS/relay-automation/xyz-sync.sh update $CALLER_ROOT"
          ;;
        different)
          echo "  !   vendored copy differs from or can't be compared to the live harness"
          ;;
        standalone)
          echo "  ok  no reachable live harness to compare; using vendored copy"
          ;;
      esac
    fi
    mark "$TICK"       "tick CLI"
    mark "$CODEX_PATH" "codex CLI (Path A worker)"
    mark "$AGY_PATH"   "agy CLI   (Path A worker)"
    mark "$COMMANDCODE_PATH" "cmd CLI   (Path A worker, Command Code)"
    mark "$DEEPSEEK_PATH"    "dsh CLI   (Path A worker, DeepSeek)"
    if [ -z "$CODEX_PATH" ] && [ -z "$AGY_PATH" ]; then
      echo "  !   no cross-model headless worker on PATH — only Path B (all-Claude poll) is available"
    fi
    # GH-70: concurrency-readiness. When a FOREIGN repo (not the harness clone) has no local .xyz/, it
    # resolves to the CENTRALIZED harness, whose single global driver lock serializes ALL relays run
    # through it — so it cannot run a relay concurrently with another repo pointed at the same harness.
    # Advise vendoring for per-repo lock isolation. Fail-open: this only prints; --check still exits 0.
    if [ "$VENDORED" = 0 ]; then
      if [ -n "$_caller" ] && [ "$(_canon_dir "$_caller")" != "$HARNESS" ]; then
        if [ -n "$MAIN_CHECKOUT_VENDORED" ]; then
          echo "  !   concurrency: vendored .xyz found in the main checkout at $MAIN_CHECKOUT_VENDORED, but it is not"
          echo "      a usable harness here; relays fall back to the CENTRALIZED harness and"
        else
          echo "  !   concurrency: no local .xyz/ in this repo — relays here use the CENTRALIZED harness and"
        fi
        echo "      share ONE global driver lock (can't run concurrently with another repo's relay). For"
        echo "      per-repo isolation / concurrent relays, vendor this repo:"
        echo "        relay-automation/xyz-vendor.sh $_caller"
        # GH-448: resolve via the shared resolver, not a 2-candidate guess — when $HARNESS itself is a
        # linked worktree (.git is a FILE), the driver's real lock lives at the git common dir, which
        # neither hardcoded candidate above matched, so this warning silently never fired.
        if type driver_lock_path_for_repo >/dev/null 2>&1; then
          _lk="$(driver_lock_path_for_repo "$HARNESS")"
          if [ -d "$_lk" ]; then
            _holder=""
            [ ! -f "$_lk/pid" ] || IFS= read -r _holder < "$_lk/pid" || true
            case "$_holder" in
              ''|*[!0-9]*) _lock_live=0 ;;
              *) if [ "$_holder" -gt 0 ] && kill -0 "$_holder" 2>/dev/null; then _lock_live=1; else _lock_live=0; fi ;;
            esac
            if [ "$_lock_live" = 1 ]; then
              echo "  !   a driver lock is currently HELD ($_lk, pid $_holder) — a relay started here will BLOCK until it frees"
            else
              echo "  !   stale driver lock ($_lk, pid ${_holder:-none}) — the driver will try to reclaim it"
            fi
          fi
        else
          echo "  !   driver lock state unavailable: selected harness has no shared lock resolver"
        fi
      fi
    fi
    _collision="$(_find_case_collision_pair "${_caller:-}" || true)"
    if [ -n "$_collision" ]; then
      _path_a="${_collision%%$'\t'*}"
      _path_b="${_collision#*$'\t'}"
      echo "  !   case-collision: tracked paths '$_path_a' and '$_path_b' differ only by case in this repo"
      echo "      and only one casing can exist as a real directory tree on this filesystem. A headless"
      echo "      relay turn can misread git status here and revert a legitimate edit (exit 6). Remedy:"
      echo "      git mv one variant to match the other's casing, commit, then re-run --check."
    fi
    true   # --check is advisory: always exit 0 (fail-open), never block a relay on a warning
    ;;
esac
