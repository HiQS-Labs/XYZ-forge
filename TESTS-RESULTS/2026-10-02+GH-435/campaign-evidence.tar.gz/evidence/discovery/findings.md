# GH-435 environment campaign — discovery lane

Base: `4f69865bd04302d160467064f5852d2f8f743af5` (detached). Campaign lane: `discovery`; owned clone `/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/clones/discovery`; all disposable fixtures and outputs are outside the clone under this evidence directory. Current GH-435 title per parent: “Environment Matrix Testing Engine — Dependency Completeness, CWD/Symlink Topologies, Git Workspace States, and Sandbox Permissions.”

## Finding 1 — P2: explicit harness override crashes if `HOME` is unset

`skills/1-hourly/relay-xyz/find-harness.sh:121` eagerly evaluates `CONFIG_FILE="${XDG_CONFIG_HOME:-$HOME/.config}/xyz/harness"` under `set -u`, before the resolver checks `XYZ_HARNESS` or `XYZ_REPO_ROOT`. A valid explicit override therefore cannot short-circuit the optional per-user config/search setup. The shell exits with `HOME: unbound variable`; setting `XDG_CONFIG_HOME` does not avoid the failure. This is a bounded robustness defect for minimal/headless environments; normal shells with `HOME` set are unaffected.

Reproduction, bounded by the shared `proc_group` runner:

```sh
python3 utils/py/proc_group.py --timeout 10 -- env -u HOME XYZ_HARNESS='/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/clones/discovery' bash skills/1-hourly/relay-xyz/find-harness.sh --root
```

Observed: exit 1, `skills/1-hourly/relay-xyz/find-harness.sh: line 121: HOME: unbound variable`. The same failure is in the ATE cases `home_unset_valid_override` and `home_unset_with_xdg`; both use a real valid `XYZ_HARNESS`. Controls `home_empty_valid_override` and `home_missing_valid_override` pass, isolating the trigger to an *unset* variable. The test wrapper’s other output is an exit-status-driven deterministic assertion; ATE used `--mock-classifier`, with no model endpoint or GitHub filing.

**Existing issue/test match:** the deployed locator was extended under GH-856 to read `${XDG_CONFIG_HOME:-$HOME/.config}/xyz/harness` and to honor explicit overrides first. The existing `test/find-harness.sh` and `test/gh396-find-harness-roots.sh` set or inherit a HOME and do not cover `env -u HOME`. This campaign did not modify either suite. A focused addition to the existing GH-396 suite is the smallest future proof: assert valid `XYZ_HARNESS` with HOME unset, then repeat with XDG_CONFIG_HOME set and HOME unset; keep the existing HOME-set pass as a control. If HOME absence is unsupported by contract, emit a direct precondition diagnostic instead of a shell unbound-variable failure.

## Environment and topology matrix

The declared one-case grids contain 25 unique cases; authoritative logs cover all 25/25. Each ATE invocation uses a newly initialized disposable Git repo at `fixtures/ATE scratch repo 空白 Ω`, `--mock-classifier`, a 0.001 minute budget to stop after one variation, and an 8 second per-variation cap. The whole runner invocation is bounded with `utils/py/proc_group.py --timeout 30`. Three expected-refusal cases initially had a probe-output parser mistake; only those were rerun in `logs-v6`, with the corrected assertion. The first wrapper NameError and first YAML parse-error attempts remain preserved under `logs/` and are explicitly excluded from product case totals in `provenance.jsonl`.

Expected behavior passed for:

- Foreign CWD, a CWD containing spaces and Unicode, a bare Git repository CWD, and a linked worktree whose main checkout has a gitignored vendored `.xyz` copy.
- `XYZ_HARNESS` and `XYZ_REPO_ROOT` selection, precedence when both are valid, fallback from invalid `XYZ_HARNESS` to valid `XYZ_REPO_ROOT`, and override selection while preserving a consumer repository root for a vendored `.xyz` path.
- Vendor `.xyz` directory symlinks both inside and outside a consumer repo, plus a file-symlinked locator.
- Empty and nonexistent HOME values with valid overrides; a symlinked HOME reading a valid config; missing/empty configs refusing with the expected diagnostic; a valid config without a final newline; an XDG config path with spaces and Unicode; and ambiguous canonical clone candidates refusing to guess.
- Shell `%q` `--env` round-trip for an override path containing a single quote, `$`, spaces, Unicode, and a literal newline. The check evaluates only the locally generated export text from the trusted fixture locator.

A deliberate wrong-root assertion (`red_wrong_expected_root`) failed, witnessing that the same wrapper/ATE path detects a bad root oracle. Its failure is an intended red control, not a product defect. The two unset-HOME cases are the only product defects found in this lane. ATE’s own reset/clean and per-variation command-template path worked for the scratch target containing spaces/Unicode.

## Scope and limits

This lane source-read the exact current locator, harness-paths helper, ATE runner and shared process-group runner, plus the related existing tests and GH-856 doc. The graph entry was stale (generation `2026-09-01T15:54:30Z`, fast index rooted at the primary checkout); it marked the ATE subtree excluded and these current clone paths not tracked, so source reads and live probes are the evidence. No `validate.sh`, broad suite, live model, network service, or live GitHub write ran. This lane did not test dependency installation completeness, OS sandbox permissions, parallel load, or full ATE-duration behavior. No production files in the clone were modified.

## Action checklist for triage

1. Decide whether the locator contract supports an unset HOME when an explicit harness override is valid; the current override-first precedence and reported output support treating the HOME-dependent config/search as optional.
2. If supported, make every HOME expansion safe under `set -u` before the override loop, without changing the existing precedence or writing config/search data.
3. Add the two unset-HOME assertions to the existing GH-396 suite (no new suite), retain HOME-set as the green control, and witness the current line-121 failure as the red control.
4. Re-run those focused tests in a disposable full clone, capture the red and green evidence, and preserve the campaign provenance with the task record.

## Existing GH-912 confirmation — ambient `XYZ_HARNESS` reaches registered suites

This is confirmation of the existing GH-912 concern, not a new locator behavior defect. The focused `test/find-harness.sh` passes 50/0 with `XYZ_HARNESS` and `XYZ_REPO_ROOT` unset. Under `XYZ_HARNESS=<this owned clone>`, it fails 49/1 at `test/find-harness.sh:69-71`: its vendored-fixture check expects the fixture's local `.xyz` to win, while the valid ambient override intentionally takes precedence. The focused `test/gh396-find-harness-roots.sh` passes 41/0 in both modes because its probes explicitly unset or set `XYZ_HARNESS`.

The source path permits this inheritance: `validate.sh:1293` and `:1422` invoke each registered suite with plain `bash`; `ci-local.sh:298` does the same in its tee pipeline. `test/lib/runner-envelope.sh:59-73` prepares only `XYZ_HARNESS_DB` and does not scrub `XYZ_HARNESS`; `test/_setup.sh`'s unset list also omits it. These are exact source observations plus focused suite runs; no full `validate.sh` or `ci-local.sh` run was made, so this does not claim a full gate reproduction.

Raw commands, logs, and identical before/after clone identity snapshots are in `gh912/`; per-run records are appended to `provenance.jsonl`. The lane's 25-case ATE result remains unchanged: 22 expected behavior/refusal cases passed, two unset-HOME locator cases failed, and the deliberate wrong-root red control failed as intended. The GH-912 test-envelope issue is tracked separately from those two product-level locator failures.
