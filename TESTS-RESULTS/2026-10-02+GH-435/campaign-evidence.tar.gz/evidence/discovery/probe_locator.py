#!/usr/bin/env python3
"""Bounded, read-only root-discovery probe for one ATE variation."""
import json, os, sys
from pathlib import Path
E=Path(__file__).resolve().parent
F=E/'fixtures'
repo=Path.cwd().resolve()
case=sys.argv[1]; harness=Path(sys.argv[2]).resolve()
sys.path.insert(0,str(harness/'utils'/'py'))
from proc_group import run_bounded
alias=F/'XYZ-forge alias Ω'
alias_quote=F/"XYZ forge '$HOME' Ω"
alias_newline=F/'XYZ forge newline\nΩ'
consumer_in=F/'consumer inside .xyz'
consumer_out=F/'consumer outside .xyz'
main=F/'main repo .xyz'
worktree=F/'linked worktree Ω'
locator=harness/'skills/1-hourly/relay-xyz/find-harness.sh'
copied_locator=F/'deployed skill'/'skills'/'relay-xyz'/'find-harness.sh'
# Each case sets only the environment relevant to root discovery; real user credentials are excluded.
env={'PATH':os.environ.get('PATH','/usr/bin:/bin'),'HOME':str(E/'fixtures'/'private home'),'XDG_CONFIG_HOME':str(E/'fixtures'/'private xdg')}
Path(env['HOME']).mkdir(parents=True,exist_ok=True); Path(env['XDG_CONFIG_HOME']).mkdir(parents=True,exist_ok=True)
cwd=repo; want_harness=harness; want_repo=harness; control=False
if case=='foreign_cwd': pass
elif case=='unicode_space_cwd': pass
elif case=='bare_repo_cwd': cwd=F/'bare repo 空白 Ω'
elif case=='home_empty_valid_override': env['HOME']=''; env.pop('XDG_CONFIG_HOME',None); env['XYZ_HARNESS']=str(alias); want_harness=alias; want_repo=alias
elif case=='home_missing_valid_override': env['HOME']=str(F/'does not exist home'); env.pop('XDG_CONFIG_HOME',None); env['XYZ_HARNESS']=str(alias); want_harness=alias; want_repo=alias
elif case=='override_xyz_harness': env['XYZ_HARNESS']=str(alias); want_harness=alias; want_repo=alias
elif case=='override_xyz_repo_root': env['XYZ_REPO_ROOT']=str(alias); want_harness=alias; want_repo=alias
elif case=='invalid_then_valid_override': env.update(XYZ_HARNESS=str(F/'missing'),XYZ_REPO_ROOT=str(alias)); want_harness=alias; want_repo=alias
elif case=='valid_precedence': env.update(XYZ_HARNESS=str(alias),XYZ_REPO_ROOT=str(harness)); want_harness=alias; want_repo=alias
elif case=='local_inside_vendor': cwd=consumer_in; want_harness=consumer_in/'.xyz'; want_repo=consumer_in
elif case=='local_outside_vendor_symlink': cwd=consumer_out; want_harness=consumer_out/'.xyz'; want_repo=consumer_out
elif case=='linked_worktree_vendor': cwd=worktree; want_harness=main/'.xyz'; want_repo=worktree
elif case=='override_vendor_keeps_cwd_repo':
    cwd=consumer_out; env['XYZ_HARNESS']=str(consumer_out/'.xyz'); want_harness=consumer_out/'.xyz'; want_repo=consumer_out
elif case=='locator_file_symlink': locator=F/'locator link Ω'/'find-harness.sh'
elif case=='home_unset_valid_override': env.pop('HOME'); env['XYZ_HARNESS']=str(alias); want_harness=alias
elif case=='home_unset_with_xdg': env.pop('HOME'); env['XDG_CONFIG_HOME']=str(F/'private xdg'); env['XYZ_HARNESS']=str(alias); want_harness=alias
elif case=='home_symlink_config':
    cwd=F/'bare repo 空白 Ω'; locator=copied_locator; env.pop('XDG_CONFIG_HOME',None); env['HOME']=str(F/'HOME symlink Ω'); want_harness=F/'home config clone'/'XYZ-forge'; want_repo=want_harness
elif case=='config_missing_refuses':
    cwd=F/'bare repo 空白 Ω'; locator=copied_locator; env['HOME']=str(F/'home missing config'); env.pop('XDG_CONFIG_HOME',None)
elif case=='config_empty_refuses':
    cwd=F/'bare repo 空白 Ω'; locator=copied_locator; env['HOME']=str(F/'home empty config'); env.pop('XDG_CONFIG_HOME',None)
elif case=='config_valid_no_newline':
    cwd=F/'bare repo 空白 Ω'; locator=copied_locator; env['HOME']=str(F/'home no-newline config'); env.pop('XDG_CONFIG_HOME',None); want_harness=F/'home config clone'/'XYZ-forge'; want_repo=want_harness
elif case=='xdg_config_space':
    cwd=F/'bare repo 空白 Ω'; locator=copied_locator; env['XDG_CONFIG_HOME']=str(F/'XDG config Ω'); env['HOME']=str(F/'private home'); want_harness=F/'home config clone'/'XYZ-forge'; want_repo=want_harness
elif case=='ambiguous_search_refuses':
    cwd=F/'bare repo 空白 Ω'; locator=copied_locator; env['HOME']=str(F/'home ambiguous candidates'); env.pop('XDG_CONFIG_HOME',None)
elif case=='quoted_override': env['XYZ_HARNESS']=str(alias_quote); want_harness=alias_quote; want_repo=alias_quote
elif case=='newline_env_roundtrip': env['XYZ_HARNESS']=str(alias_newline); want_harness=alias_newline; want_repo=alias_newline
elif case=='red_wrong_expected_root': control=True
else: raise SystemExit('unknown case: '+case)
try:
    out=run_bounded(['bash',str(locator),'--root'],cwd=str(cwd),env=env,timeout=4)
    envout=run_bounded(['bash','-c','eval "$("$1" --env)" || exit; printf "%s\\0%s\\0" "$HARNESS" "$TICK_REPO_ROOT"','probe',str(locator)],cwd=str(cwd),env=env,timeout=4)
except Exception as exc:
    print(json.dumps({'case':case,'result':'probe_runner_error','error':str(exc)})); raise SystemExit(9)
if out.timed_out or envout.timed_out:
    print(json.dumps({'case':case,'result':'timeout'})); raise SystemExit(9)
# Only classify root discovery when both surfaces return successfully.
if case in {'config_missing_refuses','config_empty_refuses','ambiguous_search_refuses'}:
    expected=('multiple canonical candidates:' in (out.stderr+envout.stderr)) if case=='ambiguous_search_refuses' else ('relay-automation/ harness not found.' in (out.stderr+envout.stderr))
    if case=='config_empty_refuses': expected=expected and 'ignoring invalid config' in (out.stderr+envout.stderr)
    no_exports=not any(envout.stdout.split('\x00'))
    ok=out.rc==1 and expected and no_exports
    print(json.dumps({'case':case,'result':'expected_refusal' if ok else 'unexpected_result','root_rc':out.rc,'env_rc':envout.rc,'env_output_lines':len(envout.stdout.splitlines()),'stderr':(out.stderr+envout.stderr)[-1200:]},ensure_ascii=False))
    raise SystemExit(0 if ok else 1)
if case=='newline_env_roundtrip':
    lines=envout.stdout.split('\x00')
    actual_h=Path(lines[0]) if lines else Path('')
    actual_t=Path(lines[1]) if len(lines)>1 else Path('')
    checks={'env_harness_roundtrip':str(actual_h)==str(want_harness),'tick_repo_roundtrip':str(actual_t)==str(want_repo)}
    print(json.dumps({'case':case,'harness_env':str(actual_h),'tick_repo_env':str(actual_t),'checks':checks,'control':False},ensure_ascii=False))
    raise SystemExit(0 if all(checks.values()) else 1)
if out.rc or envout.rc:
    print(json.dumps({'case':case,'result':'unexpected_refusal_or_error','root_rc':out.rc,'env_rc':envout.rc,'stderr':(out.stderr+envout.stderr)[-1200:]}))
    raise SystemExit(1)
lines=envout.stdout.split('\x00')
ex={'HARNESS':lines[0] if lines else '', 'TICK_REPO_ROOT':lines[1] if len(lines)>1 else ''}
actual_h=Path(out.stdout.rstrip('\n'))
actual_t=Path(ex.get('TICK_REPO_ROOT',''))
# Compare lexical full paths: --root's expected path is the selected locator representation,
# while repo roots preserve the operator's current worktree.
if control: want_h=F/'deliberately wrong root'
checks={'harness_root':os.path.normpath(str(actual_h))==os.path.normpath(str(want_harness)),
        'tick_repo_root':os.path.normpath(str(actual_t))==os.path.normpath(str(want_repo))}
print(json.dumps({'case':case,'cwd':str(cwd),'harness_root':str(actual_h),'tick_repo_root':str(actual_t),'env_harness':ex.get('HARNESS'),'via':next((x.split(' via=',1)[1].split()[0] for x in envout.stderr.splitlines() if ' via=' in x),'unknown'),'checks':checks,'control':control},ensure_ascii=False))
raise SystemExit(0 if all(checks.values()) and not control else 1)
