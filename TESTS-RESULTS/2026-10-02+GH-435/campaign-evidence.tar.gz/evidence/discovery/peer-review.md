# Peer review: linked-worktree false pass in host-containment oracle

**Verdict:** Confirmed. `host_identity()` treats `<worktree>/.git` as though it were a directory. In a linked worktree it is a text gitfile, so the oracle hashes a nonexistent `<worktree>/.git/config` and records an empty config hash. A targeted write to the host's shared Git config then passes containment. The linked-worktree fixture itself is valid and distinct from running a mutation-heavy test gate; this review ran no broad suite.

## Evidence

At `utils/py/domain_oracles.py:236-248`, `host_identity()` constructs `os.path.join(host_root, ".git", "config")`, hashes it only if it is a regular file, then queries a selected set of Git properties. `check_host_containment()` snapshots that identity and `tree_digest(host_root)` before and after the command (`:291-310`). `tree_digest()` walks regular files under the linked checkout but does not follow the `.git` gitfile to the common Git directory. `head_tip` and branch-ref checks still catch the tested HEAD change; that does not close the config gap.

The supervisor's `linked-config` case already demonstrates the symptom: `host_before.config_sha256 == host_after.config_sha256 == ""`, no host paths are reported touched, and `passed` is true despite the case being an expected red. Its `standalone-config` case correctly fails when `.git/config` is directly under the host. The `linked-head` mutation is detected through the changed `head_tip`, and the `linked-noop` control passes.

I reproduced the configuration boundary in fresh, entirely owned `git init` fixtures under `peer-review/fixtures-fresh/`, with separate command-CWD and linked-host roots. The exact bounded command is in `worktree_gitfile_probe_fresh.py`; the outer `utils/py/proc_group.py --timeout 30` command and raw output are preserved in `worktree_gitfile_probe_fresh.log` and `.json`. Results:

- Without `extensions.worktreeConfig`, `git -C <linked> config --local campaign.probe2 changed` changes the primary clone's shared `.git/config` (`common_config_changed=true`, key present). `check_host_containment()` nevertheless returns `passed=true`, with an empty config hash and no touched host files.
- With `extensions.worktreeConfig=true`, `git -C <linked> config --worktree campaign.probe2 changed` changes the linked worktree's `.git/worktrees/linked/config.worktree` (`config_worktree_contains_probe=true`) without changing common `.git/config`. The oracle again returns `passed=true` with an empty config hash. This is an additional blind spot if host containment includes a linked worktree's own config, as the selected host root implies.

Every fixture worktree was removed with `git worktree remove`; each recorded post-run `worktree list` contains only its primary fixture. No linked worktree remains registered by these probes. The probe did not touch the discovery clone's Git config, refs, or working tree.

## Assessment and remediation

This is a real oracle false pass for linked-worktree hosts, independent of the earlier locator matrix. The core issue is not that a worktree’s `.git` file is inherently suspicious; it is that the oracle follows neither that file nor Git's own `--git-dir` / `--git-common-dir` resolution when hashing persistent state. A narrowly scoped repair would identify both the common gitdir and per-worktree gitdir via Git, then include the common config and the host worktree's `config.worktree` when present (along with the relevant HEAD/ref state). Existing expected-red coverage should include one shared-config mutation and, where `extensions.worktreeConfig` is enabled, a worktree-config mutation. Preserve the existing HEAD-change red and no-op green controls.

## Limits and attempt accounting

Only the containment function was exercised, with two bounded local Git-config mutations in disposable `git init` fixtures. No `validate.sh`, `test/*.sh`, or broad ATE gate ran. The initial probe attempt failed before commit creation because its setup expected an existing HEAD. An intermediate rerun reused a config key and therefore did not prove a fresh shared-config delta. Both attempts are preserved in the peer-review directory but excluded from the verdict; the fresh-directory, unique-key run in `worktree_gitfile_probe_fresh.log` is authoritative.
