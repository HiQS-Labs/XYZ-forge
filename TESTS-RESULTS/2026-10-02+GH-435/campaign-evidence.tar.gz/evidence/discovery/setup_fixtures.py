from pathlib import Path
import os, shutil, subprocess
E=Path(__file__).resolve().parent
root=Path('/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/clones/discovery').resolve()
f=E/'fixtures'
# External aliases/topologies; only beneath this owned evidence directory.
for name in ['locator link Ω','vendor stub','consumer inside .xyz','consumer outside .xyz','main repo .xyz','linked worktree Ω','XYZ-forge alias Ω']:
    p=f/name
    if p.exists() or p.is_symlink():
        if p.is_symlink() or p.is_file(): p.unlink()
        else: shutil.rmtree(p)
alias=f/'XYZ-forge alias Ω'
alias.symlink_to(root, target_is_directory=True)
linkdir=f/'locator link Ω'; linkdir.mkdir()
(linkdir/'find-harness.sh').symlink_to(root/'skills/1-hourly/relay-xyz/find-harness.sh')
vendor=f/'vendor stub'; (vendor/'relay-automation').mkdir(parents=True); (vendor/'bin').mkdir()
for p, data, mode in [(vendor/'relay-automation/relay-drive.sh', '#!/bin/sh\nexit 0\n',0o755),(vendor/'bin/tick','# stub\n',0o755)]:
    p.write_text(data); p.chmod(mode)
def git_init(path):
    path.mkdir(parents=True,exist_ok=True)
    subprocess.run(['git','init','-q',str(path)],check=True)
    subprocess.run(['git','-C',str(path),'config','user.name','ATE fixture'],check=True)
    subprocess.run(['git','-C',str(path),'config','user.email','ate-fixture@example.invalid'],check=True)
def commit(path):
    subprocess.run(['git','-C',str(path),'add','-A'],check=True)
    subprocess.run(['git','-C',str(path),'commit','-qm','fixture baseline'],check=True)
for n in ['consumer inside .xyz','consumer outside .xyz','main repo .xyz']:
    p=f/n; git_init(p)
    (p/'marker').write_text(n+'\n')
    if n=='consumer inside .xyz':
        inside=p/'vendor-source'; shutil.copytree(vendor,inside); (p/'.xyz').symlink_to('vendor-source',target_is_directory=True)
    elif n=='consumer outside .xyz': (p/'.xyz').symlink_to(vendor,target_is_directory=True)
    elif n=='main repo .xyz': (p/'.xyz').symlink_to(vendor,target_is_directory=True)
    commit(p)
wt=f/'linked worktree Ω'
subprocess.run(['git','-C',str(f/'main repo .xyz'),'worktree','add','--detach','-q',str(wt)],check=True)
# The ATE runner target is a fresh git-init scratch with unusual path characters.
scratch=f/'ATE scratch repo 空白 Ω'
git_init(scratch); (scratch/'baseline.txt').write_text('scratch fixture\n'); commit(scratch)
print('root='+str(root))
print('alias='+str(alias))
print('vendor='+str(vendor))
print('scratch='+str(scratch))
print('fixtures=consumer_inside,consumer_outside,main_checkout,linked_worktree,locator_file_symlink')
