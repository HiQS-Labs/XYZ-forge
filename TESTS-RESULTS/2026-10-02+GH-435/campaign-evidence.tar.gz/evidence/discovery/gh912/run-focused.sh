#!/usr/bin/env bash
set -u
repo=/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/clones/discovery
evidence=/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/evidence/discovery/gh912
identity() {
  local tag="$1"
  {
    printf 'HEAD='; git -C "$repo" rev-parse HEAD
    printf 'STATUS='; git -C "$repo" status --porcelain=v1 --branch
    printf 'CORE_BARE='; git -C "$repo" config --get core.bare || true
    printf 'REMOTES_BEGIN\n'; git -C "$repo" remote -v; printf 'REMOTES_END\n'
    printf 'LOCAL_EMAIL='; git -C "$repo" config --local --get user.email || true
    printf 'WORKTREES_BEGIN\n'; git -C "$repo" worktree list --porcelain; printf 'WORKTREES_END\n'
  } > "$evidence/$tag.identity"
}
run_one() {
  local suite="$1" envmode="$2" logfile="$evidence/logs/${suite}.${envmode}.log" cmdfile="$evidence/logs/${suite}.${envmode}.command.txt" rc
  identity "${suite}.${envmode}.before"
  if [ "$envmode" = unset ]; then
    printf '%s\n' "env -u XYZ_HARNESS -u XYZ_REPO_ROOT HOME=$evidence/home XDG_CONFIG_HOME=$evidence/xdg python3 utils/py/proc_group.py --timeout 180 -- bash test/$suite" > "$cmdfile"
    (cd "$repo" && env -u XYZ_HARNESS -u XYZ_REPO_ROOT HOME="$evidence/home" XDG_CONFIG_HOME="$evidence/xdg" python3 utils/py/proc_group.py --timeout 180 -- bash "test/$suite") > "$logfile" 2>&1
    rc=$?
  else
    printf '%s\n' "env XYZ_HARNESS=$repo HOME=$evidence/home XDG_CONFIG_HOME=$evidence/xdg python3 utils/py/proc_group.py --timeout 180 -- bash test/$suite" > "$cmdfile"
    (cd "$repo" && env XYZ_HARNESS="$repo" HOME="$evidence/home" XDG_CONFIG_HOME="$evidence/xdg" python3 utils/py/proc_group.py --timeout 180 -- bash "test/$suite") > "$logfile" 2>&1
    rc=$?
  fi
  printf '\nexit=%s\n' "$rc" >> "$logfile"
  identity "${suite}.${envmode}.after"
  printf '%s %s exit=%s\n' "$suite" "$envmode" "$rc"
}
for suite in find-harness.sh gh396-find-harness-roots.sh; do
  for envmode in unset set; do run_one "$suite" "$envmode"; done
done
