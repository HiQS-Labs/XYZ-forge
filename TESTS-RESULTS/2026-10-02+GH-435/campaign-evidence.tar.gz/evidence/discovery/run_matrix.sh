#!/bin/bash
set -u
ROOT='/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/clones/discovery'
E='/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/evidence/discovery'
SCRATCH="$E/fixtures/ATE scratch repo 空白 Ω"
for name in foreign_cwd unicode_space_cwd bare_repo_cwd override_xyz_harness override_xyz_repo_root invalid_then_valid_override valid_precedence local_inside_vendor local_outside_vendor_symlink linked_worktree_vendor override_vendor_keeps_cwd_repo locator_file_symlink home_unset_valid_override home_unset_with_xdg home_empty_valid_override home_missing_valid_override home_symlink_config config_missing_refuses config_empty_refuses config_valid_no_newline xdg_config_space ambiguous_search_refuses quoted_override newline_env_roundtrip red_wrong_expected_root; do
  python3 utils/py/proc_group.py --timeout 30 -- python3 utils/ate/scripts/run_variations.py \
    --repo "$SCRATCH" --variations "$E/grids/$name.yaml" \
    --log "$E/logs-v5/$name.jsonl" --control "$E/control.json" \
    --mock-classifier --minutes 0.001 --per-variation-timeout 8 \
    > "$E/logs-v5/$name.run.log" 2>&1
  rc=$?
  printf '%s runner_rc=%s\n' "$name" "$rc"
done
