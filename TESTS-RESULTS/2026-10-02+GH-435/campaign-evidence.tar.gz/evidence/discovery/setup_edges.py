from pathlib import Path
import shutil, sys, json
root=Path('/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/clones/discovery').resolve()
E=Path(__file__).resolve().parent
F=E/'fixtures'
sys.path.insert(0,str(root/'utils'/'py'))
from proc_group import run_bounded

def git(*args):
    r=run_bounded(['git',*map(str,args)],timeout=5)
    if r.timed_out or r.rc:
        raise RuntimeError(f'git rc={r.rc} timed_out={r.timed_out} stderr={r.stderr[-500:]}')
    return r.stdout.strip()
# Special path aliases, including Bash %q metacharacters and a literal newline.
for name in ["XYZ forge '$HOME' Ω", 'XYZ forge newline\nΩ']:
    p=F/name
    if p.is_symlink(): p.unlink()
    p.symlink_to(root,target_is_directory=True)
# Simulate the installed copied skill: it cannot use the real clone as its sibling fallback.
copied=F/'deployed skill'/'skills'/'relay-xyz'/'find-harness.sh'
copied.parent.mkdir(parents=True,exist_ok=True)
shutil.copy2(root/'skills/1-hourly/relay-xyz/find-harness.sh',copied)
# Canonical-name symlink for config/search fixtures. The clone itself has the canonical remote.
homeclone=F/'home config clone'/'XYZ-forge'
homeclone.parent.mkdir(parents=True,exist_ok=True)
if homeclone.is_symlink(): homeclone.unlink()
homeclone.symlink_to(root,target_is_directory=True)
# XDG_CONFIG_HOME with spaces/Unicode.
xdg=F/'XDG config Ω'; xdgconfig=xdg/'xyz/harness'; xdgconfig.parent.mkdir(parents=True,exist_ok=True); xdgconfig.write_bytes(str(homeclone).encode()+b'\n')
# Config resolved via a symlinked HOME; deliberately omit the trailing newline.
physical=F/'home physical Ω'; config=physical/'.config/xyz/harness'; config.parent.mkdir(parents=True,exist_ok=True)
config.write_bytes(str(homeclone).encode())
linkhome=F/'HOME symlink Ω'
if linkhome.is_symlink(): linkhome.unlink()
linkhome.symlink_to(physical,target_is_directory=True)
# Missing and empty config controls.
missing=F/'home missing config'; missing.mkdir(exist_ok=True)
empty=F/'home empty config'; (empty/'.config/xyz').mkdir(parents=True,exist_ok=True); (empty/'.config/xyz/harness').write_bytes(b'')
# Valid config at HOME with no final newline.
nonl=F/'home no-newline config'; (nonl/'.config/xyz').mkdir(parents=True,exist_ok=True); (nonl/'.config/xyz/harness').write_bytes(str(homeclone).encode())
# Two canonical candidates on the same non-development branch must refuse ambiguity.
amb=F/'home ambiguous candidates'
for rel in ['Documents/GH Repos/XYZ-forge','Documents/GitHub/XYZ-forge']:
    p=amb/rel; (p/'relay-automation').mkdir(parents=True,exist_ok=True)
    script=p/'relay-automation/relay-drive.sh'; script.write_text('#!/bin/sh\nexit 0\n'); script.chmod(0o755)
    if not (p/'.git').exists(): git('init','-q','--initial-branch=main',p)
    rem=run_bounded(['git','-C',str(p),'remote','get-url','origin'],timeout=5)
    if rem.rc==0: git('-C',p,'remote','set-url','origin','https://github.com/HiQS-Labs/XYZ-forge.git')
    else: git('-C',p,'remote','add','origin','https://github.com/HiQS-Labs/XYZ-forge.git')
print(json.dumps({'copied_locator':str(copied),'home_symlink':str(linkhome),'config_home_clone':str(homeclone),'quoted_alias':str(F/"XYZ forge '$HOME' Ω"),'newline_alias':str(F/'XYZ forge newline\nΩ'),'candidate_paths':[str(amb/'Documents/GH Repos/XYZ-forge'),str(amb/'Documents/GitHub/XYZ-forge')]},ensure_ascii=False))
