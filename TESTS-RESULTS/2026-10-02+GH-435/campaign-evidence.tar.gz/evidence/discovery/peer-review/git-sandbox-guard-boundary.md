# GH-50 config and config-lock refusal boundary

**Verdict:** The existing `utils/git-sandbox-guard.sh` behaves as intended for both a read-only config file and a config-lock path the process cannot create. In both cases it exits 2 before invoking the branch-changing command. The writable positive control runs that same command successfully.

## Source contract

`utils/git-sandbox-guard.sh:53-64` resolves the repository's Git common directory and requires its `config` file. At `:66-79`, it attempts a zero-byte append to the config, then a noclobber creation/removal probe for `config.lock`; each failure calls `refuse` with an explicit “was not attempted (GH-50)” message. Only after both probes does it run the supplied command (`:81-82`). Existing `test/gh50-sandboxed-git-guard.sh` independently encodes the same expected red/control shape; it was read, not run as a suite.

## Controlled result

`readonly-config/git_guard_probe.py` uses a new fixture repo under `readonly-config/fixture-repo`, never the campaign clone. The bounded invocation was:

```sh
python3 utils/py/proc_group.py --timeout 45 -- python3 evidence/discovery/peer-review/readonly-config/git_guard_probe.py
```

The fixture has committed `main` and `topic` branches, a tracked `payload.txt` sentinel, and an untracked binary sentinel. Before each negative guard call, the probe captures HEAD, symbolic HEAD, branch refs, index hash, config hash, tracked payload bytes, and untracked bytes.

- **Read-only `.git/config`:** the fixture config file was made read-only and an actual append-open control returned `EACCES` (errno 13). The guard exited 2 with “config … is not writable; 'git switch --track' was not attempted”. HEAD, HEAD ref, branch refs, index, config, tracked payload, and untracked sentinel all matched the pre-call snapshot.
- **Uncreatable `.git/config.lock`:** the config file remained writable (its append-open control succeeded), while the fixture `.git` directory was made non-writable; an actual `config.lock` create control returned `EACCES`. The guard exited 2 with “config lock … cannot be created; 'git switch --track' was not attempted”. The same state fields and sentinels matched the pre-call snapshot.
- **Writable positive control:** after restoring fixture permissions, the same guarded `git switch --track -c tracked topic` exited 0, created `tracked`, moved HEAD to that branch, and changed the tracked payload to `topic payload`. The untracked sentinel remained byte-identical.

Raw output and structured snapshots are in `readonly-config/git_guard_probe_v4.log` and `readonly-config/results.json`. The fixture has only its primary worktree. No suite or gate ran, no production file changed, and the discovery clone remained at the campaign base with clean status, `core.bare=false`, and its original origin.

## Attempt accounting and limits

The first probe attempts had setup mistakes (wrong script location, then a helper-name collision, then the lock-permission control ran before making the fixture directory read-only). Their logs are preserved as `git_guard_probe.log`, `git_guard_probe_v2.log`, and `git_guard_probe_v3.log`; none is counted as evidence. `git_guard_probe_v4.log` is the corrected run where both OS permission controls were observed to fail before interpreting guard outcomes. This was a direct wrapper exercise in one ordinary macOS filesystem fixture; it does not attest behavior on network filesystems, ACL configurations, or every sandbox implementation.
