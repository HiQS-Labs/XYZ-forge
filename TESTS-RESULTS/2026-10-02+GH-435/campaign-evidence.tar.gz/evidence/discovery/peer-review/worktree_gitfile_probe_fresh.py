from pathlib import Path
import json, os, subprocess, sys
root = Path(__file__).resolve().parent
repo_root = Path('/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/clones/discovery')
sys.path.insert(0, str(repo_root / 'utils/py'))
from domain_oracles import check_host_containment
base = root / 'fixtures-fresh'
env = dict(os.environ, HOME=str(root/'home'), GIT_CONFIG_GLOBAL='/dev/null', GIT_CONFIG_NOSYSTEM='1', PYTHONDONTWRITEBYTECODE='1')
(root/'home').mkdir(exist_ok=True)
def git(cwd, *args):
    return subprocess.run(['git','-C',str(cwd),*args], env=env, check=True, capture_output=True, text=True, timeout=10).stdout.strip()
def init_case(name, worktree_config):
    d=base/name; d.mkdir(parents=True, exist_ok=True)
    primary=d/'primary'; primary.mkdir(exist_ok=True)
    git(primary,'init','-q')
    head=subprocess.run(['git','-C',str(primary),'rev-parse','--verify','HEAD'],env=env,capture_output=True,text=True,timeout=10)
    if head.returncode:
        git(primary,'-c','user.name=Probe','-c','user.email=probe@example.invalid','commit','--allow-empty','-qm','fixture')
    if worktree_config: git(primary,'config','extensions.worktreeConfig','true')
    linked=d/'linked'; git(primary,'worktree','add','--detach',str(linked),'HEAD')
    # Gitfile points into the common gitdir; hash field code reads linked/.git/config, which is absent.
    work= d/'command-cwd'; work.mkdir(exist_ok=True)
    cfg=primary/'.git/config'; cfg_before=cfg.read_bytes()
    if worktree_config:
        command=['git','-C',str(linked),'config','--worktree','campaign.probe2','changed']
    else:
        command=['git','-C',str(linked),'config','--local','campaign.probe2','changed']
    oracle=check_host_containment(command,str(work),str(linked),env=env,timeout=4)
    cfg_after=cfg.read_bytes()
    gitfile=(linked/'.git').read_text().strip()
    worktree_config_file=primary/'.git/worktrees'/gitfile.split('/')[-1]/'config.worktree'
    out={
      'case':name,'extensions_worktreeConfig':worktree_config,
      'command':command,'oracle_result':oracle,
      'linked_dot_git_is_file':(linked/'.git').is_file(),'linked_gitfile':gitfile,
      'common_config_changed':cfg_before!=cfg_after,
      'common_config_contains_probe':b'probe2 = changed' in cfg_after,
      'config_worktree_exists':worktree_config_file.exists(),
      'config_worktree_contains_probe':worktree_config_file.exists() and b'probe2 = changed' in worktree_config_file.read_bytes(),
      'common_gitdir':git(primary,'rev-parse','--git-common-dir'),
      'linked_gitdir':git(linked,'rev-parse','--absolute-git-dir'),
    }
    git(primary,'worktree','remove',str(linked))
    out['worktrees_after']=git(primary,'worktree','list','--porcelain')
    return out
results=[init_case('shared-local-config',False),init_case('worktree-config-extension',True)]
(root/'worktree_gitfile_probe_fresh.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
