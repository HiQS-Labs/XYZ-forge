from pathlib import Path
import json, os, subprocess, sys
root=Path(__file__).resolve().parent/'tmp-boundary'
clone=Path('/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/clones/discovery')
helper=clone/'test/lib/runner-envelope.sh'
fixture=root/'fixture-repo'; fixture.mkdir(exist_ok=True)
def run(argv,env): return subprocess.run(argv,env=env,capture_output=True,text=True,timeout=12)
if not (fixture/'.git').is_dir():
    p=run(['git','-C',str(fixture),'init','-q'],dict(os.environ)); assert p.returncode==0,p.stderr
    for k,v in [('user.name','ATE Probe'),('user.email','ate-probe@example.invalid')]:
        p=run(['git','-C',str(fixture),'config',k,v],dict(os.environ)); assert p.returncode==0,p.stderr
    p=run(['git','-C',str(fixture),'-c','user.name=ATE Probe','-c','user.email=ate-probe@example.invalid','commit','--allow-empty','-qm','fixture'],dict(os.environ)); assert p.returncode==0,p.stderr

def identity():
    fields={}
    for key,argv in {'head':['rev-parse','HEAD'],'status':['status','--porcelain=v1','--branch'],'bare':['config','--get','core.bare'],'remotes':['remote','-v'],'local_email':['config','--local','--get','user.email']}.items():
        p=run(['git','-C',str(fixture),*argv],dict(os.environ)); fields[key]={'rc':p.returncode,'stdout':p.stdout.strip(),'stderr':p.stderr.strip()}
    return fields
before=identity()
# Prove the denied TMPDIR is actually unwritable for this process, not merely chmod-marked.
try:
    with (root/'denied'/'permission-control').open('w') as f: f.write('should fail')
    write_control={'denied':False,'error':'open unexpectedly succeeded'}
except OSError as e:
    write_control={'denied':True,'errno':e.errno,'error':str(e)}
assert write_control['denied'],write_control
bash='set +e; . "$1"; runner_envelope_begin "$2" boundary-probe; rc=$?; printf "begin_rc=%s\\n" "$rc"; if [ "$rc" -eq 0 ]; then runner_envelope_assert "$2" boundary-probe; ar=$?; printf "assert_rc=%s\\n" "$ar"; runner_envelope_scrub; fi; exit 0'
results=[]
for label,tmpdir in [('writable-control',root/'writable'),('unwritable',root/'denied'),('missing',root/'missing')]:
    env=dict(os.environ,HOME=str(root/'home'),TMPDIR=str(tmpdir),GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1')
    p=run(['bash','-c',bash,'probe',str(helper),str(fixture)],env)
    results.append({'case':label,'tmpdir':str(tmpdir),'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
after=identity()
out={'base_sha':'4f69865bd04302d160467064f5852d2f8f743af5','fixture':str(fixture),'write_permission_control':write_control,'clone_identity_before':before,'clone_identity_after':after,'identity_unchanged':before==after,'runner_envelope_cases':results,'fixture_head_after':identity()['head'],'fixture_worktrees_after':run(['git','-C',str(fixture),'worktree','list','--porcelain'],dict(os.environ)).stdout.strip()}
(root/'results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
