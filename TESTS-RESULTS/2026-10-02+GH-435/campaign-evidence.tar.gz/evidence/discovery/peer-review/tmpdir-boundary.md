# Runner-envelope temp-path refusal boundary

**Verdict:** The existing runner envelope fails closed for both missing and unwritable `TMPDIR`; no defect was found in this boundary. This was a direct call to the existing `runner_envelope_begin()` path in an owned `git init` fixture, not a `validate.sh`/`ci-local.sh` run or broad test gate.

`test/lib/runner-envelope.sh:63-68` asks `mktemp -d` for the harness-registry scratch directory and returns failure with `runner-envelope: mktemp -d for harness scratch failed — refusing to run ungated` if creation fails. Its next state-snapshot directory has the corresponding fail-closed path at `:73-76`.

The bounded probe in `tmp_boundary_probe.py` uses an owned fixture repo at `tmp-boundary/fixture-repo`. Its `denied/` directory was mode `0555`; an actual Python file-open write control returned `EACCES` (`Permission denied`) before invoking the helper. Results in `tmp_boundary_probe.log` and `tmp-boundary/results.json`:

- Writable `TMPDIR` control: `runner_envelope_begin` returned 0, `runner_envelope_assert` returned 0, then the helper scrubbed its own scratch/state dirs.
- Unwritable `TMPDIR`: `begin_rc=1`, with both the OS `mktemp` permission error and the helper's explicit refusal diagnostic.
- Nonexistent `TMPDIR`: `begin_rc=1`, with the missing-directory error and the same refusal diagnostic.

The outer process was bounded by `python3 utils/py/proc_group.py --timeout 40`. Fixture Git identity fields (HEAD, status, core.bare, remotes, and local email) were byte-for-byte equal in the before/after snapshots; only the fixture repo was queried. No production files changed. This supports the existing refusal contract and does not suggest a follow-up fix.
