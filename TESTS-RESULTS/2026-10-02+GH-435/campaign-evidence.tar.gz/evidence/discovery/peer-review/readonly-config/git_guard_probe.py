from pathlib import Path
import hashlib,json,os,subprocess
root=Path(__file__).resolve().parent
repo=root/'fixture-repo'; gitdir=repo/'.git'
clone=Path('/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/clones/discovery')
guard_path=clone/'utils/git-sandbox-guard.sh'
def run(argv,timeout=10,env=None): return subprocess.run(argv,capture_output=True,text=True,timeout=timeout,env=env)
def git(*args):
 p=run(['git','-C',str(repo),*args]);
 if p.returncode: raise RuntimeError((p.args,p.returncode,p.stderr))
 return p.stdout.strip()
repo.mkdir(exist_ok=True)
if not gitdir.exists():
 git('init','-q')
 git('config','user.name','GH50 probe')
 git('config','user.email','gh50@example.invalid')
 (repo/'payload.txt').write_text('main sentinel\n')
 (repo/'untracked-sentinel.bin').write_bytes(b'untracked sentinel bytes\x00\xff')
 git('add','payload.txt');git('commit','-qm','main');git('branch','-M','main')
 git('switch','-qc','topic');(repo/'payload.txt').write_text('topic payload\n');git('commit','-qam','topic');git('switch','-q','main')

def snap():
 fields={}
 for name,args in {'head':['rev-parse','HEAD'],'head_ref':['symbolic-ref','-q','HEAD'],'refs':['for-each-ref','--format=%(refname) %(objectname)','refs/heads'],'config':['config','--local','--get','user.email']}.items():
  p=run(['git','-C',str(repo),*args]);fields[name]={'rc':p.returncode,'stdout':p.stdout.strip(),'stderr':p.stderr.strip()}
 for name,path in {'payload':repo/'payload.txt','untracked':repo/'untracked-sentinel.bin','index':gitdir/'index','config_bytes':gitdir/'config'}.items():
  fields[name]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'size':path.stat().st_size}
 return fields
command=['git','-C',str(repo),'switch','--track','-c','tracked','topic']
def run_guard(): return run([str(guard_path),'--repo',str(repo),'--operation','git switch --track','--',*command],timeout=10)
initial=snap()
# Deny writes to the config file itself; prove the permission using an actual append open.
config=gitdir/'config';config.chmod(config.stat().st_mode & ~0o222)
try:
 with config.open('ab') as f:f.write(b'')
 config_control={'denied':False,'error':'append unexpectedly opened'}
except OSError as e:config_control={'denied':True,'errno':e.errno,'error':str(e)}
assert config_control['denied'],config_control
readonly=run_guard(); after_readonly=snap(); config.chmod(config.stat().st_mode | 0o200)
# Keep config file writable but deny lock creation by making its parent directory read-only.
gitdir.chmod(gitdir.stat().st_mode & ~0o222)
try:
 with config.open('ab') as f:f.write(b'')
 config_append_control={'writable':True}
except OSError as e:config_append_control={'writable':False,'error':str(e)}
try:
 with (gitdir/'config.lock').open('xb') as f:f.write(b'probe')
 (gitdir/'config.lock').unlink()
 lock_control={'denied':False,'error':'lock create unexpectedly opened'}
except OSError as e:lock_control={'denied':True,'errno':e.errno,'error':str(e)}
assert config_append_control['writable'],config_append_control
assert lock_control['denied'],lock_control
readonly_lock=run_guard(); after_lock=snap(); gitdir.chmod(gitdir.stat().st_mode | 0o200)
# Positive control: same command is allowed after restoring fixture permissions.
positive=run_guard(); after_positive=snap()
out={
 'base_sha':'4f69865bd04302d160467064f5852d2f8f743af5','fixture':str(repo),
 'initial':initial,
 'read_only_config':{'write_denied_control':config_control,'guard_rc':readonly.returncode,'stdout':readonly.stdout,'stderr':readonly.stderr,'after':after_readonly,'state_unchanged':initial==after_readonly},
 'config_lock_unwritable':{'config_append_control':config_append_control,'lock_create_denied_control':lock_control,'guard_rc':readonly_lock.returncode,'stdout':readonly_lock.stdout,'stderr':readonly_lock.stderr,'after':after_lock,'state_unchanged':initial==after_lock},
 'writable_positive_control':{'guard_rc':positive.returncode,'stdout':positive.stdout,'stderr':positive.stderr,'after':after_positive,'head_ref':git('symbolic-ref','--short','HEAD'),'payload':(repo/'payload.txt').read_text()},
 'fixture_head_after':git('rev-parse','HEAD'),'fixture_worktrees_after':git('worktree','list','--porcelain'),
}
(root/'results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
