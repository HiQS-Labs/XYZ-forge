raise ModuleNotFoundError('sqlite3 disabled by installer probe')
