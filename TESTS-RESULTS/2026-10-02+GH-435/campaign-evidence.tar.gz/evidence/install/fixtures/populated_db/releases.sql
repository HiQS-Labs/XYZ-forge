-- releases-app canonical dump (GH-32 grammar: GID-keyed rows, natural keys elsewhere,
-- no integer PKs/FKs as values; rebuild renumbers deterministically)
-- generation: 2
-- table: schema_migrations
INSERT INTO schema_migrations(version, applied_at) VALUES('1', '2026-10-03T06:07:56Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('2', '2026-10-03T06:07:56Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('3', '2026-10-03T06:07:56Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('4', '2026-10-03T06:07:56Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('5', '2026-10-03T06:07:56Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('6', '2026-10-03T06:07:56Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('7', '2026-10-03T06:07:56Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('8', '2026-10-03T06:07:56Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('9', '2026-10-03T06:07:56Z');
-- table: settings
INSERT INTO settings(key, value, updated_at) VALUES('enforcement', 'lenient', '2026-10-03T06:07:56Z');
INSERT INTO settings(key, value, updated_at) VALUES('generation', '2', '2026-10-03T06:07:56Z');
INSERT INTO settings(key, value, updated_at) VALUES('repo_slug', 'populated_db', '2026-10-03T06:07:56Z');
-- table: repos
INSERT INTO repos(global_id, slug, updated_at) VALUES('repo-01M4060NNEXEFG9173P2TWZTCS', 'populated_db', '2026-10-03T06:07:56Z');
-- table: roadmap_items
INSERT INTO roadmap_items(global_id, repo_gid, gh_number, title, section, position, status_marker, complexity, risk, effort, doc_path, issue_url, raw_text, first_seen, updated_at, rating_pri, rating_sev, rating_appeal, rating_effort, rating_ovr, status_label) VALUES('rmi-01M4060NRAJTYKXJR2FPP45D2W', 'repo-01M4060NNEXEFG9173P2TWZTCS', '435', 'installer fixture', 'Queue / parked intake', '1', '🆕', NULL, NULL, NULL, 'PROJECT/1-INBOX/GH-435.md', 'https://github.com/HiQS-Labs/XYZ-forge/issues/435', '- **GH-435 · installer fixture** 🆕 **captured 2026-10-02 via HQ** — [GH-435.md](PROJECT/1-INBOX/GH-435.md) · [#435](https://github.com/HiQS-Labs/XYZ-forge/issues/435)', '2026-10-03T06:07:56Z', '2026-10-03T06:07:56Z', NULL, NULL, NULL, NULL, NULL, NULL);
-- table: op_receipts
INSERT INTO op_receipts(op, target_gid, at, txn_id, session_id, state_digest_before, state_digest_after) VALUES('roadmap-add', 'rmi-01M4060NRAJTYKXJR2FPP45D2W', '2026-10-03T06:07:56Z', '4626f9a22dc346beb5b3463ad7720320', 'default', 'd6dbdd079065bfdce6718507c140dfc9e4a55ca020ac6873f6db4a759578b44c', 'b1d23e067316961dad73ff77ea562e8df1bc62343f462a29039ef4c22ab2489b');
-- table: work_events
INSERT INTO work_events(global_id, repo_gid, gh_number, txn_id, event, payload, at) VALUES('wev-01M4060NRCWBKSEPCRBVDF6VEZ', 'repo-01M4060NNEXEFG9173P2TWZTCS', '435', '4626f9a22dc346beb5b3463ad7720320', 'parked', '{"section": "Queue / parked intake"}', '2026-10-03T06:07:56Z');
