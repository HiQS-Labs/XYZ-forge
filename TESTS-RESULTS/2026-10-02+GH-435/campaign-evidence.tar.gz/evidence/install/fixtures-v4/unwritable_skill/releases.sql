-- releases-app canonical dump (GH-32 grammar: GID-keyed rows, natural keys elsewhere,
-- no integer PKs/FKs as values; rebuild renumbers deterministically)
-- generation: 1
-- table: schema_migrations
INSERT INTO schema_migrations(version, applied_at) VALUES('1', '2026-10-03T06:11:28Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('2', '2026-10-03T06:11:28Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('3', '2026-10-03T06:11:28Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('4', '2026-10-03T06:11:28Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('5', '2026-10-03T06:11:28Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('6', '2026-10-03T06:11:28Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('7', '2026-10-03T06:11:28Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('8', '2026-10-03T06:11:28Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('9', '2026-10-03T06:11:28Z');
-- table: settings
INSERT INTO settings(key, value, updated_at) VALUES('enforcement', 'lenient', '2026-10-03T06:11:28Z');
INSERT INTO settings(key, value, updated_at) VALUES('generation', '1', '2026-10-03T06:11:28Z');
INSERT INTO settings(key, value, updated_at) VALUES('repo_slug', 'unwritable_skill', '2026-10-03T06:11:28Z');
-- table: repos
INSERT INTO repos(global_id, slug, updated_at) VALUES('repo-01M40674QRCYRTT50D8AEFZ42Z', 'unwritable_skill', '2026-10-03T06:11:28Z');
