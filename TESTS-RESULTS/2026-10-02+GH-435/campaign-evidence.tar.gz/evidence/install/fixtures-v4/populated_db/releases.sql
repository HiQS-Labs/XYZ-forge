-- releases-app canonical dump (GH-32 grammar: GID-keyed rows, natural keys elsewhere,
-- no integer PKs/FKs as values; rebuild renumbers deterministically)
-- generation: 2
-- table: schema_migrations
INSERT INTO schema_migrations(version, applied_at) VALUES('1', '2026-10-03T06:11:21Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('2', '2026-10-03T06:11:21Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('3', '2026-10-03T06:11:21Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('4', '2026-10-03T06:11:21Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('5', '2026-10-03T06:11:21Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('6', '2026-10-03T06:11:21Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('7', '2026-10-03T06:11:21Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('8', '2026-10-03T06:11:21Z');
INSERT INTO schema_migrations(version, applied_at) VALUES('9', '2026-10-03T06:11:21Z');
-- table: settings
INSERT INTO settings(key, value, updated_at) VALUES('enforcement', 'lenient', '2026-10-03T06:11:21Z');
INSERT INTO settings(key, value, updated_at) VALUES('generation', '2', '2026-10-03T06:11:21Z');
INSERT INTO settings(key, value, updated_at) VALUES('repo_slug', 'populated_db', '2026-10-03T06:11:21Z');
-- table: repos
INSERT INTO repos(global_id, slug, updated_at) VALUES('repo-01M4066XXQB7CGJRNZP8H2FRHR', 'populated_db', '2026-10-03T06:11:21Z');
-- table: roadmap_items
INSERT INTO roadmap_items(global_id, repo_gid, gh_number, title, section, position, status_marker, complexity, risk, effort, doc_path, issue_url, raw_text, first_seen, updated_at, rating_pri, rating_sev, rating_appeal, rating_effort, rating_ovr, status_label) VALUES('rmi-01M4066Y0QZ7QPM27VT8HYNHTX', 'repo-01M4066XXQB7CGJRNZP8H2FRHR', '435', 'installer fixture', 'Queue / parked intake', '1', '🆕', NULL, NULL, NULL, 'PROJECT/1-INBOX/GH-435.md', 'https://github.com/HiQS-Labs/XYZ-forge/issues/435', '- **GH-435 · installer fixture** 🆕 **captured 2026-10-02 via HQ** — [GH-435.md](PROJECT/1-INBOX/GH-435.md) · [#435](https://github.com/HiQS-Labs/XYZ-forge/issues/435)', '2026-10-03T06:11:21Z', '2026-10-03T06:11:21Z', NULL, NULL, NULL, NULL, NULL, NULL);
-- table: op_receipts
INSERT INTO op_receipts(op, target_gid, at, txn_id, session_id, state_digest_before, state_digest_after) VALUES('roadmap-add', 'rmi-01M4066Y0QZ7QPM27VT8HYNHTX', '2026-10-03T06:11:21Z', '69d5d71e828a40e08d4e7b7fc2b46cc6', 'default', '8e06ce76e62bb48571e835e7768991747136e4449e75114c22c6aa07f656d8d9', '0e5b84dd74386564faee707af29a5855bdd75f844384a84a38a5723b80c14276');
-- table: work_events
INSERT INTO work_events(global_id, repo_gid, gh_number, txn_id, event, payload, at) VALUES('wev-01M4066Y0TACTGM276RDCHXNSV', 'repo-01M4066XXQB7CGJRNZP8H2FRHR', '435', '69d5d71e828a40e08d4e7b7fc2b46cc6', 'parked', '{"section": "Queue / parked intake"}', '2026-10-03T06:11:21Z');
