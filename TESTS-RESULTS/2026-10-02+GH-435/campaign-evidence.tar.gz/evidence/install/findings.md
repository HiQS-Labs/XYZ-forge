# GH-435 ATE installer lane results

## Outcome: no installer defect confirmed in this lane

The installer only runs `releases init` when `releases.db` does not exist ([pinned source](https://github.com/HiQS-Labs/XYZ-forge/blob/4f69865bd04302d160467064f5852d2f8f743af5/utils/pdda/pdda-install.sh#L772-L775)). It preserves existing zero-byte, corrupt, unreadable, or wrong-schema files. In observe mode the follow-up coverage check prints `ERROR [pdda-check-roadmap-coverage] no readable releases.db ledger present; cannot verify working-doc coverage`, then returns 0 by the documented non-blocking adoption contract ([mode contract](https://github.com/HiQS-Labs/XYZ-forge/blob/4f69865bd04302d160467064f5852d2f8f743af5/utils/pdda/pdda-lib.sh#L30-L57), [PDDA install spec](https://github.com/HiQS-Labs/XYZ-forge/blob/4f69865bd04302d160467064f5852d2f8f743af5/utils/pdda/PDDA-INSTALL.md#L23-L34)). The final `PDDA installed` line describes the runtime installation, not a clean ledger validation ([run summary](https://github.com/HiQS-Labs/XYZ-forge/blob/4f69865bd04302d160467064f5852d2f8f743af5/utils/pdda/pdda.sh#L1688-L1707)).

The intended distinction was confirmed by ATE: for zero-byte, corrupt, missing-schema, and unreadable existing files, observe mode reports the coverage error and preserves input bytes; `--mode full` exits 1 and prints `PDDA installed, but the first run reported findings or failed`. No data is overwritten. The existing file is not treated as a healthy ledger, and no evidence here establishes that the installer should replace user-supplied database content. Therefore this is an expected report-only / strict-mode split, not a product finding.

The minimal repro is: create a target Git repo, stage `utils/py/releases_app.py`, create a zero-byte `releases.db`, then run `bash utils/pdda/pdda-install.sh --no-migrate --with-startup-docs --roadmap-source releases <target>`. This returns 0 in default observe mode with the explicit coverage error. Re-run with `--mode full`; it returns nonzero and says the first verification reported findings or failed. This matches the documented adoption modes.

## Confirmed controls and expected outcomes

- Missing `releases.db`: installation creates an openable DB with 16 schema tables.
- Initialized DB with zero roadmap rows (the historical GH-904 empty-ledger condition): success; the DB remains byte-identical and has 0 rows. This state is distinct from a zero-byte file and passes on the campaign SHA.
- Initialized DB with one local fixture row: success; DB remains byte-identical and retains 1 row.
- Unwritable optional skill: mode 0555 was independently confirmed to deny writes (`PermissionError`); install emits its optional-skill warning, installs core PDDA, exits 0. This matches the documented fail-open contract and is not a finding.
- Repeated install: both passes exit 0; runtime SHA-256 is unchanged; the isolated per-target registry has exactly one row after the second pass. No finding.
- Missing Releases CLI: explicit refusal (`vendor XYZ first`) before core runtime is copied. This confirms the install path hint and is not a finding.
- `sqlite3` unavailable through an isolated `PYTHONPATH` import stub: nonzero refusal before core runtime is copied. The captured stderr is a Python `ModuleNotFoundError` traceback rather than a tailored dependency message; no partial install occurred.
- Invalid DB full-mode controls: zero-byte, corrupt, and mode-000 unreadable states all return nonzero from install verification and preserve the original bytes.

## Test artifacts and scope

The initial `v1` attempt had a missing `shutil` import in the external case driver; `v2` used a non-Git target and was refused by the installer’s required Git safety check. Those are harness setup artifacts and are retained separately, not counted as product behavior. In `v4`, the zero-byte DB semantic assertion initially expected initialization; its red record is an invalid test assumption once the preservation and observe/full contracts are read. The other v4 assertions pass. `v5` adds direct full-mode controls. Durable raw installer output is under `raw-v4/` and `raw-v5/`; each ATE log has its SHA in `provenance.jsonl`.

The run used `utils/ate/scripts/run_variations.py --mock-classifier`, one `command_template` variation per ATE call, and `proc_group.py` limits around both the ATE run and installer invocations. No model endpoint, GitHub CLI, network service, production test suite, or source checkout write was used. `PDDA_REGISTRY`, `HOME`, and `XDG_CONFIG_HOME` were set inside each isolated evidence fixture; `PDDA_GITPULSE_DIR` pointed to a nonexistent path. No operator registry or git-pulse target was configured as a write destination.


## Dependency boundary: Node is optional for deterministic install verification

The documented prerequisite list names `node` ([install specification](https://github.com/HiQS-Labs/XYZ-forge/blob/4f69865bd04302d160467064f5852d2f8f743af5/utils/pdda/PDDA-INSTALL.md#L111-L117)). Source tracing shows `pdda-lib.sh` selects Node only when found, then falls back to shell JSON escaping (GH-48; [helper](https://github.com/HiQS-Labs/XYZ-forge/blob/4f69865bd04302d160467064f5852d2f8f743af5/utils/pdda/pdda-lib.sh#L101-L131)). The deterministic `pdda.sh run` path therefore installs and verifies successfully without Node: v7 produced one ATE pass, and its node-free PATH has no `node` entry ([raw stdout](raw-v7/missing_node.install-1.stdout), [ATE record](ate-v7-missing_node.jsonl)). `pdda-doc-ready.sh` directly invokes Node only when that opt-in model-assisted command parses model output ([source](https://github.com/HiQS-Labs/XYZ-forge/blob/4f69865bd04302d160467064f5852d2f8f743af5/utils/pdda/pdda-doc-ready.sh#L88-L112)); that optional capability was not exercised. The prerequisite is reasonable for the full runtime capability set, so this is no product defect. `jq` appears as the `gh --jq` flag and is not a separate executable dependency; no acorn use was found in the PDDA installer/runtime scope.

The initial v6 ATE attempt omitted the `mode` argument expected by the external case driver and yielded repeated `IndexError` command-error rows before setup. It is a test artifact, not product evidence; those rows are excluded from the case count. The corrected v7 case completed and passed.

## Confirmed ATE provenance defect: local time is suffixed with `Z`

This is a harness timestamp issue, separate from the installer findings. In `utils/ate/scripts/run_variations.py`, run IDs use local `time.strftime` at line 422 and record timestamps use `time.strftime("%Y-%m-%dT%H:%M:%SZ")` at line 534. That expression formats local time but appends a UTC marker; the environment did not set `TZ`, and the platform default was America/Los_Angeles (PDT, UTC−07:00). With a single captured epoch, the extracted exact expression produced `2026-10-03T06:35:27Z` under `TZ=UTC` and `2026-10-02T23:35:27Z` under `TZ=America/Los_Angeles` ([controlled probe](timestamp-probe.json)).

Existing run evidence independently matches this error: v7 outer provenance says 06:31:44–06:31:50 UTC while its ATE JSONL row says `2026-10-02T23:31:50Z`; v4 similarly says 06:11:01–06:11:07 UTC while the ATE row says `2026-10-02T23:11:07Z` ([cross-check](ate-timestamp-crosscheck.json)). The wrapper’s `provenance.jsonl` timestamps use `time.gmtime` and remain the UTC source; do not treat ATE `timestamp` as UTC. Minimal correction is to format UTC (`time.gmtime()` or an aware UTC datetime), or emit the actual local offset instead of `Z`. No harness/production file was changed.
