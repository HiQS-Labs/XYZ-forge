import os, stat, sys
from pathlib import Path
sys.path.insert(0, '/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/clones/contracts/utils/py')
from jog_run import load_marathon_invocation, ContractError
p=Path('/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/evidence/contracts/unreadable-contract.json')
original=p.read_bytes(); original_mode=stat.S_IMODE(p.stat().st_mode)
os.chmod(p,0)
try:
    try: load_marathon_invocation(str(p))
    except ContractError as e:
        assert 'unreadable' in str(e).lower() and ('Permission denied' in str(e) or 'permission' in str(e).lower()), str(e)
        print('unreadable_file=EXPECTED_CONTRACTERROR '+str(e))
    else: raise AssertionError('unreadable contract accepted')
finally: os.chmod(p,original_mode)
assert p.read_bytes()==original and stat.S_IMODE(p.stat().st_mode)==original_mode
print(f'fixture_restored=PASS mode={original_mode:04o} bytes_unchanged=true')
