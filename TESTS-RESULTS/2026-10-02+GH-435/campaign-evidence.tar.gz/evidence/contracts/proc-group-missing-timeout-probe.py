import json, os, pathlib, signal, subprocess, sys, time
root = pathlib.Path('/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z')
work = root / 'evidence/contracts/missing-timeout-fixture'
work.mkdir(exist_ok=True)
runner = root / 'clones/contracts/utils/py/proc_group.py'
def invoke(label, capture):
    pgidfile = work / f'{label}.pgid'
    pidfile = work / f'{label}.pid'
    try: pgidfile.unlink()
    except FileNotFoundError: pass
    try: pidfile.unlink()
    except FileNotFoundError: pass
    argv = [sys.executable, str(runner), '--grace', '0.1', '--pgid-file', str(pgidfile), '--', sys.executable, '-c', 'import os,time,pathlib; pathlib.Path(%r).write_text(str(os.getpid())); time.sleep(60)' % str(pidfile)]
    capture_blocked = False
    try:
        result = subprocess.run(argv, stdout=subprocess.PIPE if capture else subprocess.DEVNULL,
                                stderr=subprocess.PIPE if capture else subprocess.DEVNULL,
                                text=True, timeout=0.5 if capture else 5)
        rc = result.returncode
    except subprocess.TimeoutExpired:
        capture_blocked = True
        rc = None
    for _ in range(50):
        if pidfile.exists() and pgidfile.exists(): break
        time.sleep(.02)
    assert pidfile.exists() and pgidfile.exists(), f'{label}: fixture did not prove post-spawn parse error'
    pid, pgid = int(pidfile.read_text()), int(pgidfile.read_text())
    # Both processes are ours; explicitly reap the exact inner session and verify its sentinel.
    try: os.killpg(pgid, signal.SIGTERM)
    except ProcessLookupError: pass
    for _ in range(50):
        try: os.kill(pid, 0)
        except ProcessLookupError: break
        time.sleep(.05)
    else:
        try: os.killpg(pgid, signal.SIGKILL)
        except ProcessLookupError: pass
        raise AssertionError(f'{label}: owned process still visible after cleanup pid={pid} pgid={pgid}')
    return {'case':label,'inner_rc':rc,'capture_wait_timed_out':capture_blocked,'spawned_pid':pid,'published_pgid':pgid,'cleanup':'TERM then confirmed PID absent'}
print(json.dumps([invoke('no-capture', False), invoke('captured-pipes', True)]))
