import json, os, pathlib, signal, subprocess, sys, time
repo = pathlib.Path('/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/clones/contracts')
evidence = pathlib.Path('/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/evidence/contracts')
sys.path.insert(0, str(repo / 'utils/py'))
from domain_oracles import check_zero_state, tree_digest
work = evidence / 'oracle-timeout-owned-work'
work.mkdir(exist_ok=True)
sentinel = work / 'preexisting-sentinel.txt'
sentinel.write_text('owned fixture baseline\n')
marker = work / 'late-write.txt'
pidfile = evidence / 'oracle-timeout-descendant.pid'
for p in (marker, pidfile):
    try: p.unlink()
    except FileNotFoundError: pass
positive = check_zero_state([sys.executable, '-c', 'pass'], str(work), timeout=2)
assert positive['passed'] and positive['run']['rc'] == 0, positive
child_code = "import pathlib,time; time.sleep(2); pathlib.Path(%r).write_text('late mutation\\n')" % str(marker)
# Deliberately no start_new_session: the descendant inherits the command leader's PGID.
parent_code = "import subprocess,sys,time,pathlib,os; c=subprocess.Popen([sys.executable,'-c',%r],cwd=%r,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); pathlib.Path(%r).write_text('%s '+str(c.pid)+' '+str(os.getpgid(c.pid))) if False else None; pathlib.Path(%r).write_text(str(c.pid)+' '+str(os.getpgid(c.pid))); time.sleep(30)" % (child_code, str(work), str(pidfile), str(os.getpgrp()), str(pidfile))
before, _ = tree_digest(str(work))
try:
    result = check_zero_state([sys.executable, '-c', parent_code], str(work), timeout=1)
    after_now, _ = tree_digest(str(work))
    assert pidfile.exists(), 'descendant did not publish PID/PGID'
    pid, pgid = map(int, pidfile.read_text().split())
    assert pgid == os.getpgrp(), f'descendant escaped fixture process group: child={pgid} probe={os.getpgrp()}'
    deadline = time.monotonic() + 4
    while time.monotonic() < deadline and not marker.exists(): time.sleep(.05)
    assert marker.exists(), 'descendant did not complete its delayed write'
    after_late, _ = tree_digest(str(work))
    data = {'positive_control':positive,'timeout_oracle_result':result,'digest_before':before,
            'digest_immediately_after':after_now,'digest_after_descendant_write':after_late,
            'late_marker_exists':marker.exists(),'sentinel_pid':pid,'sentinel_pgid':pgid,'probe_pgid':os.getpgrp()}
finally:
    if pidfile.exists():
        pid, pgid = map(int, pidfile.read_text().split())
        try: os.kill(pid, signal.SIGTERM)
        except ProcessLookupError: pass
        for _ in range(30):
            try: os.kill(pid, 0)
            except ProcessLookupError: break
            time.sleep(.05)
        else:
            try: os.kill(pid, signal.SIGKILL)
            except ProcessLookupError: pass
        try:
            os.kill(pid, 0)
            data['cleanup'] = 'SIGKILL sent; process still visible'
        except ProcessLookupError:
            data['cleanup'] = 'TERM then confirmed PID absent'
    else:
        data = {'cleanup':'no sentinel was published'}
print(json.dumps(data, sort_keys=True))
