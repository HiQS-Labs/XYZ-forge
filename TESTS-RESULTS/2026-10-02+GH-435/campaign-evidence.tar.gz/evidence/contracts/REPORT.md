# GH-435 contracts lane — bounded ATE and Jog boundary probes

**Verdict:** Explicit SIGTERM/SIGINT of the ATE runner leaves its active command group alive and drops the in-flight variation from telemetry. This is a product defect in cancellation cleanup. The normal-success descendant case is a separate observation outside the current timeout-only runner promise; tested Jog refusal boundaries behave as specified.

## Scope and setup

- Clone: `/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/clones/contracts`
- Base and final `HEAD`: `4f69865bd04302d160467064f5852d2f8f743af5` (detached campaign base)
- ATE target: fresh `git init` scratch repo at `clones/contracts/temp/ate-contract-probe`; only this scratch repo was reset by ATE.
- No live model, network, service, or GitHub operation was used. ATE used `--mock-classifier` and an argv `command_template`.
- Every process-bearing probe ran inside an external `proc_group.py --timeout ... --grace ...` group. Sentinel PIDs were recorded and checked; the one normal-exit survivor was reaped through `kill_existing`, and the ATE timeout child was confirmed gone.
- No tracked source was edited. The clone's `core.bare=false`, origin URL and HEAD matched baseline at close; local `user.email` was unset at both reads.

## Findings

1. `proc_group.run_bounded` reaps a timeout process group, including a child that ignores TERM. `test/gh478-runaway-guard.sh` passed **43/43**, including the SIGKILL escalation, leader-less group cleanup, closed publication/ack paths, timeout-off red control, and matcher mutation controls. The real ATE caller was also exercised with a mocked classifier: its single telemetry row recorded `timed_out=true`, `exit_code=null`, `classification.category=timeout`, and `status=fail`; the TERM-resistant descendant PID was no longer alive afterward. The ATE timeout row is the expected negative-control result, not an ATE product defect.

2. **Product defect — cancellation leaks the active engine group.** Two real `run_variations.py` CLI runs used the disposable scratch repo and a deterministic command-template worker that published both its child PID and `os.getpgrp()` PGID before waiting. Sending SIGTERM to the runner produced return code -15; SIGINT produced -2. In both cases the TERM-resistant child and its group were still live after the runner exited. The independent supervisor then called `kill_existing` with the recorded PGID and verified both were gone. Each JSONL retained its pre-existing valid control row byte-for-byte (verified against its exact original encoding), but no record was appended for the interrupted in-flight variation. The cause is visible in the synchronous `run_harness` call and later append: no signal handler/finally cleanup exists around [run_variations.py](https://github.com/HiQS-Labs/XYZ-forge/blob/4f69865bd04302d160467064f5852d2f8f743af5/utils/ate/scripts/run_variations.py#L477), while telemetry is appended only after result/classification at [run_variations.py](https://github.com/HiQS-Labs/XYZ-forge/blob/4f69865bd04302d160467064f5852d2f8f743af5/utils/ate/scripts/run_variations.py#L549). The per-variation timeout is enforced by the ATE parent calling `run_bounded`; killing that parent removes the code that would issue timeout cleanup. The probes already demonstrate the containment seam needed for a fix: preserve the active PGID, reuse `proc_group.kill_existing`, and decide an explicit interrupted-record shape. This calls for extending the existing boundary, not a parallel runner. This is a high-priority fix candidate because interrupted unattended runs can leave engine work running without a timeout supervisor, and their failure is absent from the log. No runtime code was changed in this campaign.

3. Natural leader exit does not itself clean up an otherwise-live descendant. A leader spawned a TERM-resistant child with stdin/stdout/stderr redirected, wrote its PID sentinel, and exited 0. `run_bounded` returned in 31 ms with `rc=0` and `timed_out=false`, while the child remained alive. The probe then called `kill_existing` on the returned process group and verified the child exited. `proc_group.py` describes process-group teardown on expiry and only calls `kill_existing` in its timeout branch ([proc_group.py](https://github.com/HiQS-Labs/XYZ-forge/blob/4f69865bd04302d160467064f5852d2f8f743af5/utils/py/proc_group.py#L80)); therefore this observation is outside the current timeout-only promise. If consumers require no descendants after a successful leader exit, that needs an explicit separate lifecycle contract and caller review.

4. The actual `run_variations.py` timeout path successfully used `command_template`, `--mock-classifier`, and the scratch repo to create a timeout record. The run's top-level exit code was 0 because no `--gh-repo` was given; semantic acceptance therefore came from checking the JSONL row and sentinel PID directly, not from the process exit status.

5. The constrained pairwise specimen (p1/p2/p3/p4, two conflicts and p1→p4 requirement) produced **6 cases, 100% valid-pair coverage, 0 invalid cases, in 10 ms** through the current `generate_pairwise(grid, seed=7)` API. The old three-argument call shape failed quickly with the expected `TypeError` rather than hanging. `adaptive_ate.py --mode suite` also passed **15/15**, including 329/329 valid pairs on its 12-flag control grid, deterministic seed output, and red controls for removed coverage and invalid cases.

6. `test/gh290-ate-variation-grid.sh` passed **37/37** top-level checks. Its matrix included 115 hostile invocation/result loader variations (malformed or empty JSON, non-object roots, stale schema versions, missing fields, path/argv/env type confusion, and bool/string/float `exit_code` confusion); 18 landing-verification mismatch cases refused with exit 2 and left queue state untouched; and 29 receipt-writer variations completed. Unsupported schema `@2` is refused, and `exit_code: true` is refused rather than treated as integer 1. A separate mode-000 contract file produced the expected `ContractError` wrapping `Permission denied`, and its original bytes/mode were restored. No unexpected exception or mutation escaped these tested cases.

7. A first ATE smoke used `--minutes 0.001` (60 ms). Initialization consumed the budget before the first variation, yielding no row; this was detected by the explicit non-empty JSONL assertion. Repeating with `--minutes 0.05` (3 s) yielded the expected row. This is a short-budget test artifact, not evidence that a variation ran or passed.

## Case matrix

| Area | Unique cases / repeats | Result | Classification |
|---|---:|---|---|
| GH-478 timeout/process-group suite | 43 assertions; 1 suite invocation | 43 passed, 0 failed | Pass; timeout/TERM-resistant cases exercised |
| ATE SIGTERM/SIGINT during active variation | 2 cases; 1 each | runner exited (-15/-2); child and PGID alive afterward; prior log row intact; no in-flight row; independent cleanup verified | Product defect: cancellation removes the timeout supervisor but leaves work running |
| Successful leader + detached-stdio child | 1 case; 1 run | leader rc 0; child alive before explicit cleanup, dead after | Observed boundary; outside timeout-only promise |
| ATE actual runner timeout | 1 variation; 1 row | `timed_out=true`, null rc, `fail/high/timeout`; sentinel child gone | Expected refusal/failure classification for timeout control |
| Pairwise known specimen | 1 constrained grid; 1 standard call + 1 legacy-shape call | 6 cases, 100% coverage; legacy arity TypeError promptly | Pass; API mismatch is expected and bounded |
| Adaptive ATE built-in suite | 15 assertions; 1 invocation | 15 passed, 0 failed | Pass; coverage oracle red controls witnessed |
| GH-290 Jog contract grid | 162 unique variations + 2 valid controls; 1 suite invocation | 37/37 top-level checks | Pass; malformed/stale/type-confusion refused |
| Jog unreadable contract file | 1 case; 1 run | mode-000 file refused as `ContractError` (`Permission denied`); fixture restored | Expected refusal |
| Too-short ATE budget | 1 launch; 0 variations / 0 rows | JSONL empty, caught by non-empty assertion | Harness setup-budget edge; no case result claimed |

The GH-290 matrix’s unique variation counts are 115 loader inputs + 18 landing mismatch cases + 29 receipt-writer cases. Its 37/37 summary counts suite-level assertions, not variation count. No repeats were performed.

## Reviewer checklist

- [x] Timeout handling returns the timeout classification and removes the TERM-resistant descendant.
- [x] TERM/INT probes preserve prior JSONL records and use PID+PGID sentinels; owned leaked groups are explicitly reaped after measurement.
- [ ] Fix ATE cancellation through the existing `proc_group` mechanism: SIGTERM/SIGINT must reap the active command group and record an explicit interrupted outcome, or clearly document if interruption can leave work running. Preserve previous JSONL rows; never emit a partial malformed row.
- [x] Pairwise specimen remains bounded and satisfies all valid-pair obligations; the historical three-argument shape fails promptly.
- [x] Jog refuses malformed JSON, schema-version drift, missing keys, and tested JSON type confusion before the tested state mutation/dispatch boundaries.
- [x] ATE evidence is asserted from structured telemetry and sentinel PIDs rather than the runner's exit code or empty output.
- [ ] Decide whether `run_bounded` needs a post-success descendant guarantee. Current API comments/documentation only establish group cleanup on timeout; if stronger cleanup is required, specify behavior for intentionally detached background jobs and audit every caller before changing it.
- [ ] If using very short ATE budgets, require at least one structured row before interpreting the run as a campaign result; this lane caught the zero-row case locally and did not propose runtime changes.

## Limits

These are deterministic, bounded probes on one macOS host at commit `4f69865`. They do not establish cross-platform behavior, long-duration scheduler behavior, all possible shell detachment patterns, future contract-version compatibility, or full ATE classifier quality. The GH-290 receipt writer variations use stubs; no GitHub API or live PR was queried. The GH-478 historical generator incident had its hang in an unmerged variant; this campaign verifies the current merged API and bounded legacy-shape refusal, not that historical binary/branch.

## Evidence files

- `gh478-runaway-guard.log`
- `gh290-ate-variation-grid.log`
- `adaptive-ate-suite.log`
- `ate-timeout-run.log` and `ate-timeout.jsonl`
- `proc-group-normal-exit.log`
- `ate-cancel-probes.log`, per-signal result JSON, runner output logs and JSONL controls
- `pairwise-probe.log`
- `jog-permission-probe.log`
- Fixture scripts and grids in this directory
- `provenance.jsonl` records commands, expected classifications, and output hashes; `provenance.sha256` is its SHA-256.
