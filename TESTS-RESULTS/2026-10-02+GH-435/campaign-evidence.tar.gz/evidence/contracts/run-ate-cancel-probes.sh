#!/bin/bash
set -u
ROOT="/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z"
EV="$ROOT/evidence/contracts"
cleanup() {
  local f pgid
  for f in "$EV/cancel-term-group.pgid" "$EV/cancel-int-group.pgid"; do
    if [ -s "$f" ]; then
      pgid="$(cat "$f")"
      case "$pgid" in (''|*[!0-9]*) echo "unsafe pgid sentinel: $pgid" >&2;; (*) python3 "$ROOT/clones/contracts/utils/py/proc_group.py" --grace 0.1 --kill-pgid "$pgid" || true;; esac
      rm -f "$f"
    fi
  done
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
python3 "$EV/ate_cancel_supervisor.py" term
python3 "$EV/ate_cancel_supervisor.py" int
