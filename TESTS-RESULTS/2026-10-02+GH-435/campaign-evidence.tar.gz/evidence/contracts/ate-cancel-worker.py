import subprocess, sys, time
child_pid_path, pgid_path = sys.argv[1:3]
child_code = "import signal,time; signal.signal(signal.SIGTERM, signal.SIG_IGN); time.sleep(300)"
child = subprocess.Popen([sys.executable, "-c", child_code], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
with open(child_pid_path, "w") as f:
    f.write(str(child.pid))
with open(pgid_path, "w") as f:
    f.write(str(__import__('os').getpgrp()))
child.wait()
