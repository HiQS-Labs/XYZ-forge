import json, os, sys, tempfile
from pathlib import Path
root=Path(tempfile.mkdtemp(prefix='oracle-symlink-peer-',dir='/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/evidence/contracts'))
clone=Path('/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/clones/contracts')
sys.path.insert(0,str(clone/'utils/py'))
from domain_oracles import check_zero_state,tree_digest
# Targets are outside each cwd but inside this unique fixture. Probe commands unlink only owned links.
for name,text in [('target-a','A\n'),('target-b','B\n')]:
    d=root/'targets'/name;d.mkdir(parents=True);(d/'payload.txt').write_text(text)
def run(name,initial_link,code,expected):
    cwd=root/name;cwd.mkdir();(cwd/'sentinel.txt').write_text('stable\n')
    link=cwd/'dirlink'
    if initial_link is not None: link.symlink_to(initial_link,target_is_directory=True)
    before=tree_digest(str(cwd))
    result=check_zero_state([sys.executable,'-c',code],str(cwd),timeout=3)
    after=tree_digest(str(cwd))
    row={'case':name,'passed':result['passed'],'expected_pass':expected,'digest_before':before,'digest_after':after,'files_before':before[1],'files_after':after[1],'dirlink_exists':link.is_symlink(),'dirlink_target':os.readlink(link) if link.is_symlink() else None,'run_rc':result['run']['rc']}
    row['matches_expectation']=bool(result['passed'])==expected
    return row
rows=[]
rows.append(run('noop-control',None,'pass',True))
rows.append(run('add-directory-link',None,"from pathlib import Path; Path('dirlink').symlink_to(%r, target_is_directory=True)" % str(root/'targets'/'target-a'),False))
rows.append(run('remove-directory-link',root/'targets'/'target-a',"from pathlib import Path; Path('dirlink').unlink()",False))
# Control: a directory-symlink retarget is also a tree mutation.
rows.append(run('retarget-directory-link',root/'targets'/'target-a',"from pathlib import Path; p=Path('dirlink'); p.unlink(); p.symlink_to(%r, target_is_directory=True)" % str(root/'targets'/'target-b'),False))
# Control: regular file change must still be detected.
rows.append(run('regular-file-control',None,"from pathlib import Path; Path('sentinel.txt').write_text('changed')",False))
(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
assert all(r['matches_expectation'] for r in rows if r['case'] in ('noop-control','regular-file-control')), rows
assert all(not r['matches_expectation'] and r['passed'] for r in rows if r['case'] in ('add-directory-link','remove-directory-link','retarget-directory-link')), rows
print(json.dumps({'fixture_root':str(root),'rows':rows},indent=2))
