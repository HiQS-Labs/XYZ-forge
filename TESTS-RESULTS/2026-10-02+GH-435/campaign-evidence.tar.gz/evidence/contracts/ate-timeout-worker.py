import subprocess, sys, time
pid_path = sys.argv[1]
child_code = "import signal,time; signal.signal(signal.SIGTERM, signal.SIG_IGN); time.sleep(300)"
child = subprocess.Popen([sys.executable, "-c", child_code], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
with open(pid_path, "w") as f:
    f.write(str(child.pid))
child.wait()
