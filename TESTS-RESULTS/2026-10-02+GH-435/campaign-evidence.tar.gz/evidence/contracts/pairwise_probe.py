import json, sys, time
sys.path.insert(0, "utils/py")
import adaptive_ate as a
grid = a.load_grid("/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/evidence/contracts/pairwise-grid.yaml")
t0=time.monotonic(); cases=a.generate_pairwise(grid, seed=7); elapsed=time.monotonic()-t0
rep=a.coverage_report(cases,grid)
assert rep["complete"] and rep["invalid_cases"] == 0, rep
assert all(not (c["p1"] is True and c["p2"] == "a") for c in cases)
assert all(not (c["p3"] == 10 and c["p4"] == "x") for c in cases)
assert all(c["p4"] == "y" for c in cases if c["p1"] is True)
print(f"standard_api=PASS cases={rep['cases']} coverage={rep['coverage_pct']}% elapsed_s={elapsed:.6f} invalid={rep['invalid_cases']}")
try:
    a.generate_pairwise(grid, grid["conflicts"], grid["requires"])
except TypeError as e:
    print(f"legacy_three_arg_shape=EXPECTED_TYPEERROR message={e}")
else:
    raise AssertionError("legacy three-argument shape unexpectedly accepted")
