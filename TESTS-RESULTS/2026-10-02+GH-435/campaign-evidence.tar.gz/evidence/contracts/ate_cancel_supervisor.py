import json, os, signal, subprocess, sys, time
from pathlib import Path
root=Path('/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/evidence/contracts')
repo=Path('/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/clones/contracts')
sys.path.insert(0,str(repo/'utils'/'py'))
from proc_group import kill_existing
mode=sys.argv[1].lower()
sig={'term':signal.SIGTERM,'int':signal.SIGINT}[mode]
child_file=root/f'cancel-{mode}-child.pid'
group_file=root/f'cancel-{mode}-group.pgid'
run_log=root/f'cancel-{mode}-run.log'
telemetry=root/f'cancel-{mode}.jsonl'
control=root/f'cancel-{mode}-control.json'
# Existing structured evidence must survive an interrupted append-only run.
prior={'run_id':'prior-completed-control','iteration':-1,'status':'pass','classification':{'category':'control'}}
telemetry.write_text(json.dumps(prior)+'\n')
grid=json.loads(json.dumps({})) if False else root/'ate-cancel-grid.yaml'
# Replace fixture paths in a private per-mode grid so each sentinel belongs only to this run.
import yaml
cfg=yaml.safe_load(grid.read_text())
cfg['child_pid_path']=[str(child_file)]; cfg['group_id_path']=[str(group_file)]
mode_grid=root/f'cancel-{mode}-grid.yaml'; mode_grid.write_text(yaml.safe_dump(cfg,sort_keys=False))
cmd=[sys.executable,str(repo/'utils'/'ate'/'scripts'/'run_variations.py'),
     '--repo',str(repo/'temp'/'ate-contract-probe'),'--variations',str(mode_grid),
     '--log',str(telemetry),'--control',str(control),'--minutes','1',
     '--per-variation-timeout','120','--mock-classifier']
p=subprocess.Popen(cmd,cwd=repo,stdout=run_log.open('w'),stderr=subprocess.STDOUT)
try:
    deadline=time.monotonic()+10
    while time.monotonic()<deadline and not (child_file.exists() and group_file.exists()):
        if p.poll() is not None: raise RuntimeError(f'run_variations exited early rc={p.returncode}')
        time.sleep(.02)
    if not (child_file.exists() and group_file.exists()): raise RuntimeError('sentinel PID+PGID not published')
    child=int(child_file.read_text()); pgid=int(group_file.read_text())
    # Verify both identities are live before signaling the parent.
    os.kill(child,0); os.killpg(pgid,0)
    os.kill(p.pid,sig)
    try: run_rc=p.wait(timeout=8)
    except subprocess.TimeoutExpired: raise RuntimeError('run_variations did not stop after requested signal')
    try: os.kill(child,0); child_alive=True
    except ProcessLookupError: child_alive=False
    try: os.killpg(pgid,0); group_alive=True
    except ProcessLookupError: group_alive=False
    records=[json.loads(x) for x in telemetry.read_text().splitlines() if x.strip()]
    result={'mode':mode,'signal':sig.name,'runner_pid':p.pid,'runner_returncode':run_rc,
            'worker_child_pid':child,'worker_pgid':pgid,'child_alive_after_runner_exit':child_alive,
            'group_alive_after_runner_exit':group_alive,'jsonl_rows_after_interrupt':len(records),
            'prior_control_preserved':records[0]==prior,'inflight_row_present':any(r.get('variation',{}).get('case_id')=='cancel-probe' for r in records)}
    # Independent cleanup of the ATE-owned session, before declaring the case done.
    kill_existing(pgid,grace=0.1)
    deadline=time.monotonic()+4
    while time.monotonic()<deadline:
        try: os.killpg(pgid,0)
        except ProcessLookupError: break
        time.sleep(.05)
    try: os.killpg(pgid,0); result['group_gone_after_cleanup']=False
    except ProcessLookupError: result['group_gone_after_cleanup']=True
    try: os.kill(child,0); result['child_gone_after_cleanup']=False
    except ProcessLookupError: result['child_gone_after_cleanup']=True
    if not result['prior_control_preserved'] or result['inflight_row_present'] or not result['group_gone_after_cleanup'] or not result['child_gone_after_cleanup']:
        raise AssertionError(json.dumps(result))
    (root/f'cancel-{mode}-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,sort_keys=True))
finally:
    # Backup failsafe: any PGID file left is still a campaign-owned active inner group.
    if group_file.exists():
        try: kill_existing(int(group_file.read_text()),grace=.1)
        except (ValueError,ProcessLookupError): pass
        group_file.unlink(missing_ok=True)
