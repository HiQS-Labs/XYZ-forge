import os, signal, subprocess, sys, tempfile, time
sys.path.insert(0, os.path.join(os.getcwd(), "utils", "py"))
from proc_group import run_bounded, kill_existing
pid_file = "/Users/noelsaw/ate-campaigns/2026-10-02-gh435-0600Z/evidence/contracts/normal-exit-child.pid"
child_code = "import signal,time; signal.signal(signal.SIGTERM, signal.SIG_IGN); time.sleep(300)"
leader_code = "import os,subprocess,sys; p=subprocess.Popen([sys.executable,'-c',sys.argv[1]],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); open(sys.argv[2],'w').write(str(p.pid))"
started = time.monotonic()
try:
    res = run_bounded([sys.executable, "-c", leader_code, child_code, pid_file], timeout=2, grace=0.1)
    elapsed = time.monotonic() - started
    pid = int(open(pid_file).read())
    try:
        os.kill(pid, 0)
        alive = True
    except ProcessLookupError:
        alive = False
    print(f"leader_rc={res.rc} timed_out={res.timed_out} elapsed_s={elapsed:.3f} pgid={res.pgid} descendant_pid={pid} descendant_alive_after_normal_exit={alive}")
finally:
    if 'res' in locals() and 'pid' in locals():
        kill_existing(res.pgid, grace=0.1)
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                break
            time.sleep(0.05)
        try:
            os.kill(pid, 0)
            print("cleanup=WARNING descendant still has pid entry after group kill")
        except ProcessLookupError:
            print("cleanup=group descendant gone")
