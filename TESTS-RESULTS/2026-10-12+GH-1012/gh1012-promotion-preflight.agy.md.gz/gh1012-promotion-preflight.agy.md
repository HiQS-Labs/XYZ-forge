### ANSWER

The operational plan correctly maps the CI constraints and `AGENTS.md` rules for main promotion, but introduces a critical contradiction in Step 1. The plan acknowledges that `merge-cleanup` unconditionally pushes the primary clone (triggering `validate.sh` via `githooks/pre-push`), but still mandates its use. Running a mutation-heavy gate in a valued primary clone is a direct violation of `AGENTS.md`. Furthermore, you cannot bypass the hook to satisfy the script, as `ROUTER.md` prohibits using gate bypasses for merges or teardowns. The rest of the plan is highly accurate: it correctly anticipates that `.github/workflows/ci.yml` only runs the `boundary-macos` job on a `push` to `main`, meaning the final stable qualification must be bound to the exact post-merge SHA rather than PR checks.

### FINDINGS

- **[Blocker] `merge-cleanup` execution in Step 1**: The plan's "Existing procedure" section admits `merge-cleanup` unconditionally pushes the primary clone, yet Step 1 mandates its use for in-scope landings. This triggers the pre-push gate in a valued clone, violating `AGENTS.md` ("run mutation-heavy gates only in a separate disposable full clone").
- **[Blocker] Gate bypass cannot authorize teardowns**: Suppressing the primary push gate with `XYZ_SKIP_PREPUSH=1` to allow `merge-cleanup` to run is invalid. `ROUTER.md` explicitly states: "A bypassed push never authorises merge, promotion, or teardown."
- **[Pass] CI workflow alignment**: Steps 5 and 6 accurately reflect `.github/workflows/ci.yml`. Because `boundary-macos` only runs on `push` to `main` (and explicitly lacks a `pull_request` trigger), relying on post-merge exact-SHA evidence is the correct mechanism for stable qualification.
- **[Pass] Rollback & Reversibility**: Treating main promotion as Costly and recovering via explicit fix-forward/revert commits without weakening branch protections perfectly adheres to `AGENTS.md`.
- **[Pass] Artifact Provenance**: Step 3 correctly mandates a fresh disposable full clone and committed `provenance.jsonl` telemetry, satisfying `SOP.md` (Full Clone Isolation) and `AGENTS.md` (Verified Beats Plausible).

### RECOMMENDATION

Remove `merge-cleanup` from Step 1 and use the smallest existing safe path—a standard `gh pr merge` (or GitHub UI)—to land the peer's PR once their disposable clone's push gate passes, then execute the rest of the plan as written.
