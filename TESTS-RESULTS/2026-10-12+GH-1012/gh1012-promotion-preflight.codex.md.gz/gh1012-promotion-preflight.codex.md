**NO FIRSTHAND VERIFICATION CITED** — treat conclusions as conditional (codex's answer carries an unsupported [Pass]/verified/confirmed-style claim with no quoted span or file:line citation nearby, despite the consult PREAMBLE asking advisors to cite evidence.)

> **ATTESTATION**
> Model: gpt-6.1-sol
> Provider: openai
> Sandbox: read-only

Reading additional input from stdin...
2026-10-12T18:31:26.189830Z  WARN codex_skills::interface: ignoring interface.icon_small: icon path with '..' must resolve under plugin assets/
2026-10-12T18:31:26.190053Z  WARN codex_skills::interface: ignoring interface.icon_large: icon path with '..' must resolve under plugin assets/
2026-10-12T18:31:26.270842Z  WARN codex_core::agents_md: project doc exceeds remaining budget; truncating path=file:///private/var/folders/69/3l_82qtj7fzglnt_jjg07jh40000gn/T/consult-wt-43891-m8ixsws8/AGENTS.md remaining_bytes=32768
OpenAI Codex v0.159.1
--------
workdir: /private/var/folders/69/3l_82qtj7fzglnt_jjg07jh40000gn/T/consult-wt-43891-m8ixsws8
model: gpt-6.1-sol
provider: openai
approval: never
sandbox: read-only
reasoning effort: medium
reasoning summaries: none
session id: 01a13162-42a9-7f12-9481-ee4c930b3282
--------
user
You are an INDEPENDENT advisor in a one-shot cross-model consult. Another model is answering the SAME question separately and a coordinator will reconcile both answers, so give your own honest, specific read — do not hedge toward a consensus you cannot see. Read any repo files the question references (cite file:line). Respond with: (1) a short direct ANSWER; (2) graded FINDINGS — [Blocker]/[Should]/[Nit]/[Pass] — where applicable; (3) a one-line RECOMMENDATION. You are ADVISORY ONLY: output your analysis as text; do not rely on writing files (you are running in a throwaway copy).

=== CONSULT QUESTION ===
Review the operational GH-1012 stable-promotion plan in PROJECT/1-INBOX/GH-1012-STABLE-PROMOTION.md against current AGENTS.md, ROUTER.md, SOP.md, ci-local.sh and .github/workflows/ci.yml. This is advisory only: no files/refs/config changes, no tests, no remote mutations, no provider calls beyond this advisory worker. A peer is actively refreshing PR1019; do not touch its clones/branch or reset its attempts. The operator authorized workhorse drive to end but the current in-scope held drafts PR954/PR1024 remain prerequisites unless the pending operator scope decision explicitly defers them. Assess whether the ordered plan preserves the full main-to-development promotion range, SHA-bound local/hosted qualification and independent QA, and leaves main protections intact. Note the existing merge-cleanup coordinator always pushes the primary; mutation-heavy push gates must stay in an independent disposable clone. Identify the smallest existing safe publication/landing path, or state the actual blocker; do not invent new gates/drivers or weaken hooks. Main promotion is Costly and requires tested fix-forward/revert recovery, no force push or protection toggle. Name concrete blockers with source citations, disagreements/uncertainties, and necessary plan corrections. Do not mistake historical or skipped CI for the current candidate's promotion proof. Final stable representation must be an evidence-linked designation on exact qualified main SHA, not an unsupported runtime claim. This preflight is not final promotion-range review or approval to merge held drafts.
hook: SessionStart
hook: SessionStart Completed
codex
I’ll check the plan against the current promotion and gate contracts, focusing on concrete blockers and the smallest existing safe path.
exec
/bin/zsh -lc 'cat ROUTER.md' in /private/var/folders/69/3l_82qtj7fzglnt_jjg07jh40000gn/T/consult-wt-43891-m8ixsws8
 succeeded in 0ms:
# ROUTER.md

This file is the first entry point for an AI agent working in this repo: it tells you what to read, what to run, and which files are canonical.

XYZ Forge is three parts: **XYZ Forge**, the harness (this router and `AGENTS.md`); **PDDA**, project-doc governance (`PROJECT/PDDA.md`); and **PRS**, the Product Release System, which is the RELEASES ledger (`RELEASES-DB-FAQS.md`). Definition: [HOW-TO-USE.md → Glossary](HOW-TO-USE.md#glossary--the-five-terms-youll-hit-first).

## Role split

- `ROUTER.md` = startup order and canonical entry points
- `GUIDING-PRINCIPLES.md` = XYZ Forge’s product purpose, scope and *why*, and the canonical North Star: durable, reversible, DRY — extend what exists rather than forking a parallel system
- `AGENTS.md` = behavioral rules, decision quality, reversibility, blast radius, proof
- `README.md` = human-facing repo/product overview
- `ROADMAP.md` = LEGACY pointer ledger, frozen since the `ROADMAP_SOURCE=releases` flip — the RELEASES DB (`releases.db` via `releases.sql`) is the source of truth; write via `releases roadmap add`, never by editing this file
- `CHANGELOG.md` = the end-of-iteration running log (first-class PDDA artifact; governed by `PROJECT/PDDA.md`)
- `RELEASES DB` = the single runtime and release-planning ledger (`releases.db` via `releases.sql`; operated through `releases_app.py`); `RELEASES.md` is retired (GH-568)
- `HARNESS-MODELS-REGISTRY.md` = evaluated agent harnesses, supported model grades (A/B/C), and CLI flags
- `MACHINE-CONTRACTS.md` = the Jog ↔ Preflight ↔ Marathon machine-contract reference (`marathon-invocation@1`, `marathon-drive/result@1`) and their version/deprecation policy
- `PROJECT/**` docs = canonical execution detail for a specific effort
- `PARKED/` = root holding area for incidental agent findings outside the current task; triage may promote an item into issue-first PDDA intake
- `PROJECT/PDDA.md` = shared PDDA document contract maintained in Forge (incl. CHANGELOG); repo-specific adoption policy stays in this router
- `PROJECT/CONSTITUTION.md` = locally maintained PDDA-layer policy of record, with verified-success, reversibility and local-first safeguards adopted by XYZ; advisory-only LLM checking is PDDA-specific and does not replace XYZ relay approval
- `PROJECT/DO-NOT-BUILD.md` = locally maintained PDDA anti-scope; XYZ product scope remains in GUIDING-PRINCIPLES, not a blanket prohibition on coordination or execution
- `PROJECT/PDDA-MODE-GUIDE.md` = XYZ-maintained guidance for selecting PDDA’s enforcement mode
- `PROJECT/PDDA-SYNC-POLICY.md` = binding XYZ-owned review policy for PDDA distribution updates

## Startup sequence

1. Read `ROUTER.md` to understand the repo's operating order and canonical files. -> expect one clear next file, not a repo-wide scavenger hunt.
2. Read `AGENTS.md` before making recommendations or edits. -> expect explicit assumptions, a reversibility read on consequential changes, and verified claims only.
3. Run `python3 utils/py/releases_app.py roadmap list` to find the active effort or parked intake. -> expect links outward to the canonical `PROJECT/**` docs; the roadmap is a pointer ledger, not a plan body. (`ROADMAP.md` is the frozen legacy file — do not read it for current state or edit it.)
4. Read the linked `PROJECT/**` document that owns the work you are touching. -> expect the near-top `## Status` table to tell you what was just completed and what is next.
5. If the task touches project docs, read `PROJECT/PDDA.md` and follow the PDDA contract. -> expect `PROJECT/2-WORKING` docs to have frontmatter, the exact status table, and QA gates when phased.
6. Before reporting success on code or runtime work, check that the same `python3` used by the gate imports `requests`, `yaml` (PyYAML), and `pytest`, then run `./validate.sh`. -> expect the suite to stay green; do not claim completion if it fails or was skipped.
7. Before reporting success on doc-hygiene or roadmap work, run `utils/pdda/pdda.sh run` (or the relevant `utils/pdda/pdda.sh <check>` subcommand). -> expect deterministic findings first, then any LLM review.

## Canonical rules

- Do not put phase checklists, build steps, or deep execution notes in the roadmap ledger.
- Every active doc in `PROJECT/2-WORKING/` must be reflected by a pointer row in the roadmap ledger (the RELEASES DB) that links it. A working doc that should not appear opts out with `roadmap_exempt: true` in its frontmatter. Governance lives in `PROJECT/PDDA.md` → "ROADMAP contract".
- Promoting a capture from `1-INBOX` to `2-WORKING` is a DB-verb procedure (`roadmap repoint` + `roadmap update` / `roadmap move`), never a markdown edit — the exact steps and their two known gate traps (`updated:` frontmatter key, bullet-format `raw_text`) live in `SOP.md` → "Step 1b: Promoting a capture from 1-INBOX to 2-WORKING (releases-mode)".
- Every captured GitHub issue doc in `PROJECT/1-INBOX/GH-*.md` must also be parked as a queue row immediately at intake — `python3 utils/py/releases_app.py roadmap add --issue-num N --issue-url U --title T --created YYYY-MM-DD --doc-path P` (or `hq park`, which routes there automatically in this repo) — then promoted or removed later. Governance lives in `PROJECT/PDDA.md` → "GitHub issue intake" + "ROADMAP contract".
- Incidental findings outside the active task go first to root `PARKED/` under its README contract.
  They need no issue or roadmap row until triage promotes them. “Queue / parked intake” in RELEASES
  names the later, formal issue queue; it is not a replacement for the root folder. Required work
  in the current task remains in its active plan rather than being parked.
- Do not create a second competing plan when a canonical `PROJECT/**` doc already exists.
- Issue-first: any change beyond a **2–3 line** fix opens a GitHub issue first, then a pointer doc **named after the issue** (`GH-<number>-VERY-SHORT-DESC.md`, e.g. `GH-1234-SHOWME-COMMAND.md`), and that capture is **parked in the roadmap ledger immediately** (`releases roadmap add`) before execution begins. The issue is the signal stream; the pointer doc is the execution surface of record. Genuinely trivial edits (≤2–3 line fixes, typos, path repoints, doc-only one-liners) are exempt. Governed by `PROJECT/PDDA.md` → "GitHub issue intake".
- Issue-first applies when a parked observation is promoted into work, not when an agent first
  records an out-of-scope observation in `PARKED/`.
- Runtime triage labels: since the `XYZ_PYTHON` flip the harness is dual-runtime, so any harness-bug issue gets a `runtime:` label — `runtime:python` (default path), `runtime:bash` (`XYZ_PYTHON=0` opt-out), or `runtime:parity` (the twins diverge). `/file-xyz-bug` harvests and applies it; for in-repo intake (`/triage`, hand-filed `gh issue create`) apply it by hand. Omit rather than guess — a wrong runtime tag misroutes triage.
- **`GH-<n>` numbering spans two repos.** This repo succeeded [`Claude-AI-Tools-Ventura-County/xyz-3-agents-swarm`](https://github.com/Claude-AI-Tools-Ventura-County/xyz-3-agents-swarm) and the migration did **not** renumber references, so a `GH-<n>` in a source comment, test name, or CHANGELOG entry may belong to either repo. Upstream ledger entries are preserved verbatim in [`docs/ROADMAP-UPSTREAM-ARCHIVE.md`](docs/ROADMAP-UPSTREAM-ARCHIVE.md), which states its own numbering caveat and is not parsed by anything. Where an upstream number is cited from code that ships here, mirror it as a closed `[upstream archive]` issue so the citation resolves locally (#407, #408 are the pattern) rather than editing the comment. Raised externally as GH-406 §3.1.
- Do not override deterministic PDDA findings with prose.
- Do not report a win you did not verify with the relevant script or test.
- Update `CHANGELOG.md` at the end of each iteration; its governance lives in `PROJECT/PDDA.md` — do not re-specify CHANGELOG rules in `AGENTS.md` or elsewhere.

## PDDA distribution

Forge is canonical for PDDA. `utils/pdda/pdda-install.sh` installs governance into targets;
`utils/pdda/pdda-sync.sh` updates registered targets from the shared manifest.
Read [PDDA migration](docs/PDDA-MIGRATION.md) before switching an existing distributor.
Targets own their startup documents; generic templates live under `utils/pdda/templates/`.

## Command rails

For repo correctness:

```bash
bash githooks/install.sh        # ONCE PER CLONE — wires the pre-push gate (GH-544)
bash githooks/install.sh --check # is this clone gated? exit 1 if not
./validate.sh              # the gate — PARALLEL by default (GH-544), auto-sized to the host (GH-35)
./validate.sh --print-mode # which mode would this host pick, and why — runs nothing
./validate.sh --sequential # force the sequential run (see the hook’s measured GREEN in Ns line)
./validate.sh --tier 2 --subsystem hq   # GH-35: one subsystem's focused suites (pre-push speed, NOT evidence)
./validate.sh --sequential --subsystem small  # GH-831: the Small list — locally a self-check; hosted, the reconcile's qualifying run for docs/ledger/skill landings
./validate.sh --auto       # GH-35: classify the git diff, run the minimal safe tier (fails closed to 3)
./validate.sh --throttle   # GH-35: 2 workers under nice — quiet-machine mode (--burst restores full width)
bash ci-local.sh           # the QUALIFYING run — sequential + writes the gate record (GH-509/GH-536)
```

**Both gate entry points refuse to run from a linked git worktree (GH-45)** — a worktree shares
the parent clone's `.git`, and an observed suite escape corrupted the parent (core.bare, origin,
remote refs, development). Run the gate from a separate disposable full clone; `XYZ_ALLOW_WORKTREE_GATE=1` is the
announced override for disposable runs.

**Local push checks and hosted CI both apply.** This repository is public; the workflow covers
pushes and pull requests to `main` and `development`. Hosted macOS promotion evidence requires an
actual passing run for the exact commit; the Ubuntu canary remains advisory. Install the local
hook with `githooks/install.sh` for each clone — `.git/hooks/` does not travel with a clone. One
installation covers that clone’s branches and linked worktrees. Run mutation-heavy gates and
pushes that invoke them from a separate disposable full clone, as required by AGENTS.md.
Bypasses (`git push --no-verify`, `XYZ_SKIP_PREPUSH=1`) announce that the local gate was skipped.
**Draft-review publication is distinct from merge readiness (GH-487):** an operator-requested WIP
draft may use a bypass only with (a) current focused evidence for the changed area — e.g. the
mapped subsystem's suites run green — (b) the hook's skipped-gate disclosure echoed into the PR
description, and (c) merge readiness still outstanding. A bypassed push never authorises merge,
promotion, or teardown, and a published draft is never approval.

**Parallel became the default on 2026-08-14 (GH-544)** when the local gate was the only gate during
the private phase, and a slow gate risks being skipped; use the hook’s measured `GREEN in Ns` line for current cost. **GH-35 (2026-08-18) rebalanced the width to `cores/2` (floor 2, cap 4) and put every
worker under `nice -n 10`** — the original `cores − 2` (up to 8) saturated developer machines badly
enough to wedge the editor; `--burst` buys the old full-core width back for unattended runs, and
`--throttle`/`--quiet-cpu` pins 2 workers. Ambient levers: `XYZ_VALIDATE_THROTTLE=1`,
`XYZ_VALIDATE_MAX_JOBS=N`, `XYZ_VALIDATE_PARALLEL` (flags > MAX_JOBS > THROTTLE > PARALLEL > host
detection; malformed values exit 2 naming the variable). Below 4 cores, or where `xargs -P` is
unsupported, the run **falls back to sequential and says so** — every run prints the mode it chose
and the reason, so a fallback is never silent.

**GH-35 also added TIERED SELECTION on top, as a separate axis from width.** `utils/ci-route.sh`
owns one fail-closed subsystem registry (hq, releases, telemetry, ate, swe-diagram, pdda,
agent-chorus, standup, skills-army-hq, plus `small`, a gate-only list that claims no paths); a push the classifier rates `tier=2` runs only those focused
suites at the boundary, `--tier 1` runs the docs gate, and everything else — unknown paths, unclaimed
test edits, kernel surfaces — runs the full suite. `--auto` classifies a local diff the same way.
Tiers 1 and 2 are pre-push speed and are labelled NOT promotion evidence; only `ci-local.sh`'s
sequential full run qualifies (GH-509).

**GH-831 (2026-09-25) made these three tiers for what qualifies a landing.** The push hook is unchanged.
After a merge, the hosted reconcile (`wave-reconcile.yml`) qualifies each landing with **one** run,
picked by classifying the landing's changes at the tested commit:

- **Small** — docs, the ledger dumps (`releases.*`, `harnesses.*`) and non-core skill files (tier 1):
  `validate.sh --sequential --subsystem small`, the PDDA, PRS and canary suites plus the PDDA gate
  and the Python layer. The receipt records the list it ran.
- **Medium** — mapped non-core code (tier 2): the full registry at the reconcile, the area's suites at push.
- **Large** — core harness, unmapped code, gate surfaces (tier 3): the full registry.

Promotion always runs the full registry. Eight skill-text suites are off, recorded in
`test/gh306-registry-bidirectional.sh`'s EXEMPT list, and no new suites are added (AGENTS.md). The code of
core skills (`relay`, `relay-xyz`, `relay-automation`, `merge-cleanup`, `express`, `jog`) never routes as
docs. Skill markdown keeps its existing docs routing, except that `relay-xyz` and `relay-automation` stay
full-gate surfaces for every file. merge-cleanup's `SKILL.md` and `WORKTREE-SAFETY.md` are full-gate files too:
they are what `gh436-merge-cleanup` reads, and GH-836 D1 moved that suite from Small to Large.
Plan: [GH-831](PROJECT/2-WORKING/GH-831-THREE-TIER-GATE.md).

`--burst` / `XYZ_VALIDATE_MAX_JOBS` are honoured for tier 2: 2 is the default width, not a pin.
Run one gate at a time on a host: a concurrent relay turn, second gate or pollers lengthen the run
(`nice` protects the editor, not the wall-clock).

**What still qualifies a claim is unchanged.** `./validate.sh` in either mode is a self-check;
`ci-local.sh` is the run that writes the evidence record, it does **not** call `validate.sh`, and it
stays sequential. The macOS promotion boundary in `ci.yml` pins `--sequential` explicitly for the same
reason. GH-528 Phase 2 (multi-width stress evidence) is still **owed** — the flip was an operator
decision taken with that evidence outstanding, mitigated by the announced fallback rather than
discharged. See `PROJECT/2-WORKING/GH-528-TEST-SUITE-RECALIBRATION.md`, #509 and #544.

For document hygiene:

```bash
utils/pdda/pdda.sh run
```

For targeted PDDA debugging (subcommands of the single dispatcher):

```bash
utils/pdda/pdda.sh frontmatter
utils/pdda/pdda.sh status-table
utils/pdda/pdda.sh hardcoded-paths
utils/pdda/pdda.sh roadmap
utils/pdda/pdda.sh roadmap-coverage
utils/pdda/pdda.sh changelog
utils/pdda/pdda.sh stale
utils/pdda/pdda.sh issue-doc-sync   # warn-only: flags 2-WORKING/GH-*.md docs drifted from their GitHub issue state
utils/pdda/pdda.sh releases         # legacy releases check (skips when RELEASES.md is retired)
utils/pdda/pdda.sh releases-current # read-only roll-up: queries releases.db (GH-568)
utils/pdda/pdda.sh quad-concepts    # opt-in: requires a "## Quad Concepts" section of 1-4 bullets (lever: .pdda-quad / PDDA_QUAD)
utils/pdda/pdda.sh glance           # read-only roll-up: title + Quad Concepts for each PROJECT/2-WORKING doc
utils/pdda/pdda.sh governance       # repo-root governance-doc cross-reference + doc/code drift
utils/pdda/pdda.sh marathon-qa      # mechanical marathon Wave QA receipt & checklist gate (GH-784)
utils/pdda/pdda.sh gh-refresh       # refresh the cached GitHub issue-state file issue-doc-sync reads offline (needs gh)
utils/pdda/pdda.sh catchup          # LLM repo triage + ROUTER.md recommendations (delegates to pdda-catchup.sh)
utils/pdda/pdda.sh doc-ready        # LLM readiness review — set PDDA_LLM_BIN (codex/claude/agy) for recommendations, else it self-skips
```

## The RELEASES DB — two subsystems, one ledger (GH-32 / GH-69)

`releases.db` + `releases.sql` hold TWO mirrored subsystems, both operated through ONE CLI,
`utils/py/releases_app.py` (alias: the `/releases` skill). Read
[RELEASES-DB-FAQS.md](RELEASES-DB-FAQS.md) before merging either file — the SQLite binary is
derived; the SQL dump is what git actually merges, and a conflicted merge has a one-command
resolver (`utils/releases-merge-resolve.sh`).

```bash
python3 utils/py/releases_app.py check          # trio consistency, receipt chain, crash recovery
python3 utils/py/releases_app.py next           # the next unshipped release, by target date
python3 utils/py/releases_app.py add|ship ...   # RELEASE writes — never hand-edit releases.sql
python3 utils/py/releases_app.py roadmap add ... # GH-238: park one issue as a roadmap row (the intake write path)
                                                #   GH-249: put `rated N/N/N/N [ovr N]` in --raw-text to score it
python3 utils/py/releases_app.py roadmap rate ...# GH-253: score a row that is ALREADY parked (--force to re-score)
python3 utils/py/releases_app.py roadmap list   # read the roadmap rows (--json for machine consumers)
python3 utils/py/releases_app.py roadmap sync   # LEGACY-mode only (mirrors ROADMAP.md); a guarded no-op in this repo
```

**Subsystem 1 — releases** (GH-32 / GH-568): the release ledger. App-managed writes
only; `releases.db` and the `releases` CLI (`releases list`, `releases show`) are the sole source of truth (`RELEASES.md` is retired per GH-568).
**Subsystem 2 — the roadmap ledger** (GH-69 shadow → GH-238/GH-243 canonical → GH-269 retired ROADMAP.md → GH-567 retired ROADMAP-DASHBOARD.md): since the
`ROADMAP_SOURCE=releases` flip, `roadmap_items` IS the ledger — write rows with
`releases roadmap add` (or `hq park`), read with `roadmap list`.
The legacy markdown roadmap files (ROADMAP and ROADMAP-DASHBOARD) have been retired. `roadmap sync` exists for legacy-mode repos only and
no-ops here by design (it would delete `add`-parked rows). Pinned by `test/gh69-roadmap-shadow.sh`,
`test/gh238-hq-releases-mode.sh`, `test/gh269-roadmap-retired.sh`, and `test/gh567-roadmap-dashboard-retired.sh`.

## Routing hints

- If the task is about current priorities or active work, start with `releases roadmap list`, then follow the linked `PROJECT/**` doc.
- If the task changes the roadmap ledger, write through the CLI (`releases roadmap add` for intake; `hq park` routes there automatically).
- If the task touches `releases.db`, `releases.sql`, or a merge conflict on either, start in [RELEASES-DB-FAQS.md](RELEASES-DB-FAQS.md); writes go through the CLI, never a hand-edit.
- If the task is about fresh GitHub intake or duplicate-prevention, start in the roadmap queue (via `releases roadmap list`), then follow the linked `PROJECT/1-INBOX/GH-*.md` capture doc.
- If the task is about document quality, active-doc lifecycle, roadmap sprawl, or automation policy, start in `PROJECT/PDDA.md`.
- If the task is about the CHANGELOG, provenance, or end-of-iteration logging, the governance is in `PROJECT/PDDA.md` (the "CHANGELOG.md — end-of-iteration record" contract).
- If the task is about release planning, ledger health, cleanup, authoring, or publishing, invoke `/releases`. It operates against `releases.db` via `releases_app.py`; `RELEASES.md` has been retired (GH-568). It conditionally points strategic drift to `/radar` and a frozen path-to-ship to `/finish-line` without duplicating either workflow.
- If the task is about the `tick` runtime, event projection, or multi-agent coordination kernel, start in `README.md`, then `bin/`, `src/`, `test/`, and the active project doc.
- If the task is about the **Aider ↔ OpenRouter** turn-taker lane (`relay-automation/aider-turn.sh` — an OpenAI-standard build lane discrete from Codex; `AIDER_MODEL`/`OPENROUTER_API_KEY`, `--builder aider`), start in `PROJECT/3-COMPLETED/GH-77-AIDER-OPENROUTER-LANE.md`. The shim owns the tick token ops (Aider can't run shell mid-turn), asserts token ownership before launching Aider, and runs Aider `--no-auto-commits` (the harness commits).
- If the task is about running, driving, or reviewing via the relay (`relay-automation/` — `relay-drive.sh`, `poll.sh`, the turn shims, `marathon*.sh`), **invoke the `relay-xyz` skill first — do not improvise the handoff or hand-roll a harness from `ls relay-automation/`.** The skill owns the locator, sandbox rules, exit codes, and the safety boundary; a `PreToolUse` guard (`relay-automation/hooks/relay-xyz-guard.sh`) blocks driving a harness driver before the skill is loaded. For the two live-Claude-windows, same-machine duel recipe (Reporter↔Maintainer with a human go-gate), the copy-paste form is [relay-automation/DUELING-CLAUDES.md](relay-automation/DUELING-CLAUDES.md).
- If the task is about the ATE (Automated Testing Environment) skill — unattended variation-test fuzzing whose implementation lives under `utils/ate/` — start at its canonical interface in `skills/4-occasional/ate/SKILL.md`.
- If the task is about relay session telemetry, the `focus5float` health feed, or extraction scripts under `utils/telemetry/`, start in `PROJECT/1-INBOX/GH-24-RELAY-TELEMETRY-EXTRACTOR.md`.
- If the task is about live per-session completion telemetry — the `XYZ.json` log every relay/marathon/swarm session appends to at the harness repo root (schema: `harness`/`sessionId`/`health`/`title`/`description`/`updatedAt`), the shared writer `utils/telemetry/append-xyz-completion.sh`, or the shared health mapping `utils/telemetry/health-lib.sh` — start in `PROJECT/1-INBOX/GH-75-XYZ-JSON-COMPLETION-TELEMETRY.md`. `XYZ.json` is local + gitignored (machine-specific).
- If the task is about cross-repo HQ tooling (`utils/hq/` — `hq.sh` single-repo actions, `rollup.sh` the Obsidian daily ROADMAP rollup, `marathon-scan.sh` the cross-repo marathon-preflight aggregator, `hq-lib.sh` the shared repo registry), start in `PROJECT/3-COMPLETED/GH-27-ROADMAP-DASHBOARD.md` and `PROJECT/3-COMPLETED/GH-158-HQ-MARATHON-SCAN.md`. The two rollups are deliberately separate today (`rollup.sh` → Obsidian, generic; `marathon-scan.sh` → hub repo, preflight-aware) and are not yet bridged — tracked in `PROJECT/1-INBOX/GH-192-HQ-MARATHON-OBSIDIAN-ROLLUP.md`.
- If the task is about a proposed roadmap-steward agent, start here, then read `PROJECT/PDDA.md` and its `Proposed roadmap steward extension` section.
- If the task is about finding or picking a skill for a job, see `ARCHITECTURE.md` → "Skills Index" for a one-line inventory of every skill in `skills/`.
- If the task is blocked by a failing test, unexpected error, or disputed requirement, invoke the `sanity-check` skill (`skills/1-hourly/sanity-check/SKILL.md`) to establish whether the obstacle must block the goal before spending hours debugging or repairing it.
- If the task is about **managing skills for the system** — adding a skill to the machine-wide collection, deploying/refreshing/removing it across the configured app targets (`targets.json`, machine-local), or asking what is deployed — the mechanism is the `skills-army-hq` skill (`skills/3-weekly/skills-army-hq/SKILL.md`). Forge authors its own skills in `skills/`, Skills Army HQ included; XYZ-skills-army-mini and the other standalone repos are published children (`push-downstream`, GH-955). Intake accepts any local folder. The durable collection lives wherever `XYZ_SKILLS_ROOT` points (machine-local, never committed; falls back to `~/git-pulse-sync/Deployed Skills`), and only `intake.py` / `sync.py` mutate it or the app symlinks. Never hand-copy a skill folder into an app's skills directory.
- Issue-first SOP: any change beyond a 2–3 line fix (and every project plan) opens a GitHub issue *first*, then gets a pointer doc named after the issue at `PROJECT/1-INBOX/GH-<number>-VERY-SHORT-DESC.md` — e.g. `GH-1234-SHOWME-COMMAND.md` — and that capture is parked in the roadmap ledger queue immediately via `releases roadmap add` (format + lifecycle owned by `PROJECT/PDDA.md` → "GitHub issue intake"), following the normal `1-INBOX` → `2-WORKING` flow. Genuinely trivial edits (≤2–3 line fixes, typos, path repoints, doc-only one-liners) are exempt and commit directly.

exec
/bin/zsh -lc 'nl -ba PROJECT/1-INBOX/GH-1012-STABLE-PROMOTION.md' in /private/var/folders/69/3l_82qtj7fzglnt_jjg07jh40000gn/T/consult-wt-43891-m8ixsws8
 succeeded in 0ms:
     1	---
     2	title: "GH-1012: regression verification and stable promotion"
     3	status: Queued
     4	created: 2026-10-12
     5	updated: 2026-10-12
     6	owner: Codex via workhorse
     7	gh_issue: 1012
     8	source: https://github.com/HiQS-Labs/XYZ-forge/issues/1012
     9	doc_type: plan
    10	goal: >
    11	  Complete the agreed integration scope, verify its promotion range with existing regression
    12	  checks and final review-code, prepare a PR into main, and bind a stable designation to the
    13	  exact-main hosted macOS boundary evidence.
    14	related:
    15	  - https://github.com/HiQS-Labs/XYZ-forge/issues/1030
    16	  - https://github.com/HiQS-Labs/XYZ-forge/issues/947
    17	  - https://github.com/HiQS-Labs/XYZ-forge/issues/1022
    18	  - https://github.com/HiQS-Labs/XYZ-forge/issues/1031
    19	---
    20	
    21	# GH-1012 — regression verification and stable promotion
    22	
    23	## Status
    24	
    25	| What was just completed | What's next |
    26	|---|---|
    27	| Operator authorized workhorse execution. Fresh read confirms PR1017 merged; PR954 and PR1024 are drafts. A peer is refreshing PR1019 through a normal full push gate. Disposable task clone provisioned; no product code changed. | Verify the peer's PR1019 refresh/landing. Await the operator's scope decision for the two held drafts, then pin the release candidate; no final qualification or stable claim yet. |
    28	
    29	## Current facts and scope
    30	
    31	The issue is the live signal stream; historical batch receipts remain there. Current integration
    32	base is `d09b8f9dedd436be3e5f883f68deff985719fe1b`; main is
    33	`a076b1b117a68252dc3d9d1c4901b0c31fcb4db3`. At intake main is an ancestor of development;
    34	there are 333 development-only commits and 2,041 changed paths. These counts are a baseline,
    35	not the frozen candidate. The final review must cover the whole promotion range, not just this batch.
    36	
    37	Current scope includes PR954, PR1019 and PR1024; PR930 remains held. No later PR is implicitly added.
    38	PR1019 is also tracked by the active peer's merge record #1030; use its published result rather
    39	than competing with its current repair. PR954 lacks a published Claude advisory route and an
    40	explicitly authorized real advisory pilot. PR1024 remains FAIL/Escalated4/4 with Medium1031 and
    41	unfinished W8–W11; no capped review reset, live dispatch or new test approval is inferred.
    42	An operator scope decision is pending: keep both drafts as prerequisites or defer them from this
    43	stable candidate. A missing answer keeps the current prerequisites.
    44	
    45	## Existing procedure and evidence owners
    46	
    47	This is an operational promotion plan with no runtime redesign. The repository's existing
    48	merge-cleanup coordinator, RELEASES writer, hosted reconciliation, regression registry,
    49	review-code and relay QA remain the owners. Recon for runtime implementation is deferred until
    50	an actual defect demands a code change; review recon covers the pinned promotion range.
    51	
    52	- `ROUTER.md` command rails require disposable full-clone gates and the full registry for promotion.
    53	- `.github/workflows/ci.yml:151-152,196-214` runs the macOS boundary on a push to main,
    54	  explicitly sequential, with a SHA-bound verdict. Skipped PR jobs do not qualify promotion.
    55	- `ci-local.sh` supplies the full local qualifying record; it expressly does not replace hosted
    56	  promotion evidence. Run only in a separate disposable full clone with identity brackets.
    57	- `AGENTS.md` requires an independent peer/Codex QA receipt before promotion; self-review and
    58	  passing tests alone cannot satisfy it.
    59	- `PROJECT/3-COMPLETED/GH-822-PROMOTION.md` is historical precedent. Its branch-protection
    60	  toggle/direct push is not this plan: use the requested ordinary promotion PR and retain protections.
    61	- The current cleanup coordinator unconditionally pushes primary at
    62	  `skills/2-daily/merge-cleanup/scripts/merge_cleanup.py:648`, even when nothing changed.
    63	  Its possible full pre-push gate conflicts with valued-clone isolation. Do not run that path
    64	  until safe publication containment is established; retain the existing #1012/PARKED incident.
    65	
    66	## Ordered execution and acceptance
    67	
    68	1. Complete ready in-scope landings using merge-cleanup prerequisites and the existing peer
    69	   handoff. Preserve original commit ancestry for PR1019's opt-in policy using merge strategy.
    70	   Verify exact published head, independent QA, gates, merge commit and reconciliation receipts.
    71	   Keep drafts held until their actual requirements pass or the operator explicitly defers them.
    72	   -> Acceptance: all agreed prerequisites merged/reconciled, primary clean/equal origin.
    73	2. Pin main base and reconciled development head, enumerate the complete range and map changed
    74	   contracts/cross-PR seams. Obtain independent plan QA and the required workhorse consult on
    75	   promotion/preservation before consequential execution. -> Acceptance: grounded scope and
    76	   agreed stop/rollback conditions; refresh if either remote moves.
    77	3. Run `ci-local.sh --base <main-base>` plus the existing relevant behavior checks in a fresh
    78	   disposable macOS full clone. Inspect non-empty outputs and unchanged Git identity.
    79	   Use existing mutation coverage or recorded manual red controls for material seams; no new
    80	   suites, cases, registry entries or gate machinery. -> Acceptance: full green result and
    81	   committed `TESTS-RESULTS/<date>+GH-1012/provenance.jsonl`, honest retry/unknown disclosures.
    82	4. Perform final review-code and independent relay QA on the exact promotion range. Fix blockers
    83	   through existing task/repair rails and rerun affected checks/QA after candidate changes.
    84	   -> Acceptance: no unresolved promotion blockers, graded review posted to #1012 and rendered
    85	   in chat, independent `relay-system/` receipt bound to the candidate.
    86	5. Open a promotion PR from the approved development head into main. Record base/head, evidence,
    87	   nonblocking findings and fix-forward strategy. -> Acceptance: base intentionally main,
    88	   reviewed head matches published head, required PR checks current and review approved.
    89	6. Complete the authorized promotion through that PR with unchanged branch protections, then
    90	   watch the exact resulting main SHA's hosted macOS boundary. -> Acceptance: full sequential
    91	   boundary SUCCESS and `MACOS-BOUNDARY: green <SHA>`; required checks green, Ubuntu drift disclosed.
    92	7. Record stable qualification tied to that SHA and receipts, update #1012/PRS/PDDA through
    93	   canonical writers and retire only verified complete owned clones with backup/Trash proof.
    94	   -> Acceptance: outcome audit covers every required item; no stable claim on a red or stale SHA.
    95	
    96	## Preservation and rollback
    97	
    98	Intake edits are Easy, confined to this owned task branch. Remote development landings are
    99	recoverable through explicit revert commits with reviewed/gated evidence. Main promotion is
   100	Costly: existing main remains reachable, but consumers can pull the candidate. Revert/fix forward
   101	through an ordinary reviewed PR; never reset/force-push main or weaken branch protection.
   102	A red promotion boundary prevents the stable designation and release publication. No release
   103	version, tag or package publication is selected by this plan. Refresh exact-head evidence before
   104	any merge; an active peer, changed PR head or unknown remote outcome prevents replay.
   105	
   106	## Unknowns and blockers
   107	
   108	- Operator decision for held PR954/PR1024 is pending; prerequisite defaults remain in force.
   109	- PR1019's active refresh has not yet published; no concurrent branch write is permitted.
   110	- Current main branch protections/required checks need fresh review before promotion.
   111	- Full promotion-range recon, behavior probes, local qualification and final review are pending;
   112	  historical 409/409 checks are not evidence for the current candidate.
   113	- Stable metadata representation is not yet selected. Whichever label/designation is used must
   114	  point to qualified SHA/receipts; do not imply a mere GitHub label proves stability.
   115	
   116	## PRS assessment
   117	
   118	Rated 85/55/65/50, no override: operator-requested promotion is high priority; regression exposure
   119	matters to adopters; a stable pin has clear value; full-range review and platform qualification
   120	have material effort. The queued capture is not accepted-start or completion evidence.

exec
/bin/zsh -lc 'cat /Users/noelsaw/.codex/skills/swe/SKILL.md; cat /Users/noelsaw/.codex/skills/debug-mantra/SKILL.md' in /private/var/folders/69/3l_82qtj7fzglnt_jjg07jh40000gn/T/consult-wt-43891-m8ixsws8
 succeeded in 0ms:
---
name: swe
description: Govern software planning, implementation, and code review with surgical changes that balance safety, security, maintainability, and performance. Apply when designing features, editing code, reviewing diffs or build plans, or assessing whether a new subsystem, dependency, test, or CI gate earns its maintenance cost. Scale evidence and ceremony to the change; this is an engineering rubric, not a replacement execution pipeline.
---

# SWE

Deliver the required behavior with the smallest sound change. Minimize total complexity to understand, operate, verify, and maintain, not raw line count. Meet safety and security requirements; balance maintainability and performance against the actual workload. Reuse existing mechanisms when their contracts fit. Every addition must earn its continuing cost.

## Scope and working mode

Use the same standards in three modes:

- **Planning:** establish the current behavior, choose the smallest adequate design, and define observable acceptance before implementation.
- **Implementation:** extend the existing owner and conventions, keep the diff focused, and verify the final behavior. Revisit assumptions when evidence changes.
- **Review:** assess the actual plan or diff and its evidence. Report concrete failures, unjustified complexity, and missing verification; do not manufacture findings or rewrite unrelated code.

This skill does not authorize deployments, issue creation, external messages, new infrastructure, or unrelated cleanup. Follow the project's instruction, permission, documentation, and verification contracts. A stricter repository prohibition on tests or gate machinery takes precedence over the general test policy below.

For a small, reversible change, a short rationale and focused verification are enough. Do not require a new plan, issue, dashboard, phase structure, metric, or checklist unless the task or repository requires it. Scale up for shared contracts, security boundaries, persistent state, concurrency, migrations, and difficult rollback.

## Four axes

| Axis | Decision to establish | Relevant evidence |
| --- | --- | --- |
| Safety | Can ordinary failures, retries, concurrency, or operator mistakes lose data, corrupt state, or cause unintended effects? Can we recover? | Failure paths, invariants, bounded retries, idempotency where needed, rollback |
| Security | Can untrusted input or actors cross a trust boundary, gain authority, expose secrets, or misuse access? | Entry points, authorization and validation at the boundary, least privilege, dependency exposure |
| Maintainability | Does this reduce or contain the number of concepts, owners, write paths, dependencies, and special cases? | Existing mechanisms examined, clear ownership, readable contracts, focused diff |
| Performance | Does this meet the relevant latency, throughput, memory, I/O, or cost constraint at representative scale? | Workload and budget, baseline where relevant, comparable measurements, uncertainty |

These axes are not an arithmetic score. A maintainability win cannot average away an unacceptable security or safety risk. Among acceptable options, prefer the simplest design that meets the performance need. Accept extra mechanism for a material, evidenced benefit; do not optimize on speculation or assume a shorter diff is safer.

For consequential tradeoffs, record the requirement, options considered, selected approach, cost accepted, and evidence that would change the decision. Routine edits need no four-part essay.

## Pillar 0: Recon — ground the change

Current-state evidence establishes what exists today. The Blast section extends that map with the proposed change’s new systems, data, consumers, and failure paths; copying the current radius unchanged is insufficient. For greenfield work, assess the available requirements and boundaries instead of inventing existing-system recon.

### Surgical change and reuse

Before proposing a new mechanism, identify the current owner, entry point, relevant callers and consumers, state reads and writes, and failure paths. Cite the source supporting material claims; name unresolved unknowns. Trace only as far as the risk requires. Quoting a changed file does not establish its callers or downstream contracts.

Choose the smallest adequate option: no change or configuration, reuse an existing path, extend that path, or introduce a new mechanism with a concrete reason. Prefer existing platform, standard-library, and installed capabilities when they meet the requirements safely.

- Do not create a parallel implementation, registry, writer, wrapper, queue, policy engine, or source of truth merely because a local implementation is easier to write.
- Do not force reuse across incompatible responsibilities or security boundaries. Explain the mismatch and keep any necessary separation explicit.
- Do not extract a framework for a hypothetical future use. Abstraction must simplify present responsibilities; a use-count or line-count threshold alone is not justification.
- Keep unrelated refactors out of the diff. Removing obsolete code is useful when its consumers and replacement are verified; fewer lines alone are not evidence of correctness.
- Temporary duplication for migration needs a canonical owner, synchronization strategy, retirement condition, and bounded lifetime.

## Verification without suite proliferation

Verification is required; adding tests is not the default. Test count and coverage percentage are not success criteria by themselves. CI maintenance is part of the product's engineering cost.

Start with existing evidence and the smallest relevant existing check. Reuse or adjust existing coverage when its contract changes and project policy permits. A focused, reproducible manual check can be sufficient for a bounded change when policy permits; record its command or procedure, revision, outcome, and limitations in the existing evidence location.

Before adding a test, establish all of the following, briefly:

- The specific consequential failure it would catch and why recurrence is plausible.
- The existing coverage examined and the actual gap; do not infer a gap merely because there is no test named after this change.
- Why extending an existing check or recording a focused manual check is inadequate.
- How the assertion checks observable behavior rather than mirroring implementation details, mocks, names, or incidental formatting.
- The expected runtime, fixtures, dependencies, flakiness exposure, and ongoing maintenance responsibility.

Then separately justify CI placement: why must it run at that frequency, on that change set, and as a blocking gate? A useful test does not automatically need every-commit execution or a new suite, runner, lane, or telemetry service. A benchmark must meet this same bar; renaming a test does not bypass it.

Do not add a customary batch of tests per feature, regression, or review comment. Do not add tests that enforce this policy. Do not multiply scenarios unless each protects a distinct material contract. Preserve necessary security and data-integrity coverage; restraint is not permission to leave consequential behavior unverified.

Demonstrate that the chosen check can detect its target failure where practical, using the pre-fix behavior or a safe controlled mutation in isolation. Never damage shared state to obtain a red control. If sensitivity or coverage remains unverified, report that limit. Verify nonempty inputs before trusting an extraction-based assertion.

Do not silently disable or delete existing tests to make a change pass. Follow the repository's retirement policy and identify the obsolete contract, duplicate coverage, or other evidence supporting removal.

## Performance evidence without a new subsystem

Capture a baseline before changing behavior likely to affect a material performance constraint: hot paths, data volume, algorithms, queries, I/O, concurrency, startup, or resource use. Reuse existing representative workloads and measurement tools. A prose correction or equivalent rename does not earn a benchmark.

If the baseline was missed, measure a verified base revision in an isolated environment when practical; never invent a before measurement. For a new feature, define the expected workload and acceptable budget, and label the first measurement as its initial baseline rather than claiming an improvement.

Distinguish what is measured:

- **Pipeline performance:** existing CI job or step durations measure developer feedback time and execution cost. Setup, downloads, caches, retries, parallelism, and changes in test selection can alter these independently of product performance.
- **Product performance:** representative operations measured inside CI can reveal regressions. Whole-suite duration alone does not establish application latency, throughput, or resource efficiency.

For a comparison, keep workload, runtime, runner class and architecture, dependencies, cache policy, and concurrency comparable. Prefer paired base/candidate measurements on the same runner allocation when feasible; control ordering and warmup effects and isolate state between runs. Use repetitions proportionate to cost and noise, report a central value and spread, and retain raw evidence. A small noisy sample is inconclusive, not a pass or a claimed improvement.

Start new measurements as advisory observations unless the project already has an established performance gate or explicit requirement. Introduce a blocking threshold only for a meaningful budget or repeatable regression, with demonstrated measurement stability, material absolute and relative deltas, and an owner. Do not choose a universal percentage threshold or automatically refresh a baseline to hide regression. Follow repository limits on new gates.

Record a brief result in the existing task's PDDA document or equivalent and link its durable evidence: base and candidate revisions, command and workload, environment, samples, summary and variability, and interpretation. Respect repository provenance and artifact-retention requirements. If an existing issue tracks the work, link the same evidence there when issue updates are authorized; do not duplicate raw results across documents.

A new performance issue is warranted for actionable work or when repository intake requires it, not for every measurement. Do not add a benchmark suite, dashboard, scheduled workflow, or tracking subsystem without a concrete need that existing tools cannot satisfy. An explicitly requested measurement skill should minimize its mechanism and reuse this governance rather than duplicate it.

Measurement references, when needed: [GitHub runner specifications](https://docs.github.com/en/actions/reference/runners/github-hosted-runners) and [pyperf guidance on reproducible measurements](https://pyperf.readthedocs.io/en/latest/run_benchmark.html). These explain environment and sampling limits; they do not require installing pyperf or changing the host.

## Blast — failure, state, and rollback

Make failures discoverable through the existing error and observability path. Add a log, metric, or alert only when it enables a concrete diagnosis or action. Do not mandate a new logging system or correlation ID for every edit.

Bound retry and repair loops; establish their stop or escalation condition. Investigate intermittent failures as evidence rather than retrying them away. Reproduce, trace, falsify the hypothesis, and cross-check the evidence; use the project's debugging workflow where required.

For consequential changes, name the blast radius and reversibility: **Easy / Costly / One-way door**. Costly changes need a rollback path. For Costly and One-way changes, name the stop/rollback signal and the last safe intervention point. Where rollback is impossible, identify the pre-action checkpoint and require explicit authorization before proceeding. A shield, adapter, or dual-write path must itself earn its complexity.

Keep mutation ownership coherent; multiple legitimate callers may share a mutation path. Where multiple writers are necessary, state how consistency and conflicts are handled. Use explicit state models when transitions and invariants require them, not at an arbitrary state count. Use append-only history when audit or recovery requirements justify it. Background jobs should tolerate the retries and interruption their execution model permits. Store instants unambiguously; retain timezone semantics for local calendar rules.

For online schema or persistent-state migrations across mixed versions, establish compatibility, bounded backfill, concurrent-update ordering, convergence evidence, read cutover, and rollback before retirement. Use the simplest synchronization method that preserves those contracts; bidirectional synchronization and fallback reads are not universal requirements. If used, fallback must not silently return stale or unsafe data. Retire legacy storage only after old readers, writers, queued/delayed consumers, and the rollback window are accounted for. A safe offline migration need not inherit a rolling-deployment protocol.

## Planning and reporting

Follow the repository's document format and lifecycle. For substantial work without an established format, use a short status, intended outcome, current-state evidence, one ordered implementation sequence with acceptance checks, material tradeoffs, and verification/rollback provisions. Add phases and navigation only when their size warrants it. Every step must serve an acceptance criterion; every criterion needs a delivery and verification path. Backend work must reach its intended consumer.

Separate predicted effects from observed results. A plan is not verification, a green check without executed evidence is not proof, and the author asserting completion is not independent review. Follow applicable independent-review requirements; do not create a new review pipeline for a trivial edit.

In implementation reports, state the behavior changed, why it is the smallest sound approach, what ran and its result, and material limits. Mention omitted new tests or benchmarks only when that decision matters.

In reviews, lead with **Ship / Ship with conditions / Block**, scoped to the evidence and review authority. Give concrete findings by severity with location, consequence, and cheapest sound correction. Distinguish required fixes from optional preferences. Do not claim all four axes are proven when one was not examined; explain relevant unknowns without inventing work.
---
name: debug-mantra
description: "Four-mantra debugging discipline — reproduce, trace the fail path, falsify the hypothesis, cross-reference every breadcrumb. Recite the mantra block verbatim at the start of any debugging session, then apply the four steps in order before proposing any fix. Trigger on /debug-mantra and proactively whenever debugging starts — user reports a bug, says something is broken/throwing/failing, asks to debug/diagnose/investigate an issue, pastes a stack trace or error log, or asks an attribution question ('where is this coming from?', 'what posts/triggers/generates this?', 'why is X appearing?') where the answer is an unknown source to find, not just a crash to fix. Also trigger on /debug-mantra plan, and proactively when writing or reviewing the acceptance criteria of a plan, capture doc, or marathon plan — apply the same four mantras through the pivots in 'When the target is a plan, not a bug'. Adapted from: https://github.com/thananon/9arm-skills"
---

# Debug Mantra

Four-step discipline for any debug session. Recite verbatim, then apply in order. When the target is a plan rather than a bug, the same four steps apply read through the pivots in [When the target is a plan, not a bug](#when-the-target-is-a-plan-not-a-bug).

## Recite this — verbatim, as the first thing in your first response

> **Mantra:**
> 1. **First is reproducibility.** Can the issue — or the artifact — be reproduced or observed reliably?
> 2. **Know the fail path.** Debugger first; then source trace + knob enumeration; then in-code instrumentation.
> 3. **Question your hypothesis.** What would disprove it?
> 4. **Every run is a breadcrumb.** Cross-reference all of them.

Then begin work.

---

## 1. Reproduce reliably

> **Pre-flight check:** Before sinking significant effort into reproducing an incidental failure or flaky check, run [sanity-check](../sanity-check/SKILL.md) to verify whether the failure actually blocks the user's goal or can be deferred. A real failure is not automatically an urgent blocker. In a flat installed collection, resolve `sanity-check` by name.

Establish ground truth before anything else — a runnable repro for a failure, a direct look at the real artifact for an attribution question.

**Reproduce = observe the primitive ground truth, not your impression of it.** For a crash that's a failing test; for an *attribution* question ("what posts this?", "where does X come from?") it's inspecting the actual artifact — the real message, record, or raw bytes — **before** theorising about its origin. A screenshot, a rendered view, or a remembered detail is an **observation to verify, not an axiom to build on**: name it as assumption-zero and check it first. The cheapest disproof is usually looking straight at the thing — one query against the real object beats a sweep of the code that *might* have produced it. Beware visual grouping and other rendering artifacts: what looks like "one consolidated thing" may be many separate ones (or vice versa) — confirm against the raw object before any hypothesis inherits the shape.

- **Reliable repro** → capture the exact steps, inputs, and environment as a runnable artifact: failing test, curl script, CLI invocation, replay harness.
- **Flaky repro** → the bug is not yet debuggable. Raise the rate first: loop the trigger, parallelise, add stress, narrow timing windows, inject sleeps. 50% flake is debuggable; 1% is not.
- **No repro at all** → stop. Say so explicitly. Ask the user for env access, captured artifacts (HAR, log dump, core), or permission to instrument. Do **not** proceed to hypothesise.

Target: a fast (1–5 s), deterministic pass/fail signal. Pin time, seed the RNG, freeze network, isolate filesystem.

## 2. Know the fail path

Once reproducible, find *where* the code breaks and *what stops it from breaking*. The differential narrows the search. Try in this order — escalate only when the prior tactic fails.

1. **Attach a debugger.** If the env supports it, attach and step to the failure site. One breakpoint beats ten logs. Do this **before** turning any knobs.
2. **Source trace + knob enumeration.** If no debugger (or it can't reach the bug), trace the code path end-to-end and list every knob that can influence the outcome:
   - config flags, env vars, feature toggles
   - branch conditions, input shape
   - timing, concurrency, build options
   Each knob is a candidate axis to flip in the differential. Flip one at a time.
3. **In-code instrumentation.** If outside knobs can't move the failure, go inside: `printf` / log statements at the suspected fail site, dump the relevant internal state. Tag every probe with a unique prefix (e.g. `[DBG-a4f2]`) so cleanup is a single grep. Let the trace show where reality diverges from your model.

## 3. Falsify the hypothesis

When a candidate root cause surfaces, scrutinise it **before** testing it.

- Does it actually explain the symptom end-to-end? Walk it through.
- What is the simplest **proof**? What is the cleanest **disproof**?
- Run the **disproof first**. If the hypothesis survives, it's real. If it dies, you saved yourself from chasing a phantom.
- Generate 3–5 ranked hypotheses, not one. Single-hypothesis thinking anchors on the first plausible idea.

**Root cause or proximate cause?** A hypothesis that survives disproof explains *this* failure; it does not yet prove you are standing at the origin. Before accepting it, run the class-vs-instance test: *if I fix here, does the whole class of failure go away, or only this instance?* If only the instance, keep asking **"what let that happen?"** — one hop upstream at a time — until the answer is a design decision, a contract violation, or the place the bad state was first *produced*, not the line where it was first *noticed*. Record each hop; the chain is evidence, not narrative.

- **The symptom-fix trap** (named anti-pattern): guarding, try/catching, null-defaulting, retrying, or widening a type at the crash site when the bad state was produced upstream. The crash site is where the invariant was *checked*; the bug is where it was *broken*. A fix that makes the checker tolerant hides the next occurrence instead of preventing it — and without the root-vs-proximate gate above, a green repro makes the session *look* fixed. The tell: the fix adds a defensive branch and cannot say what upstream change would make that branch dead code.
- A fix at the proximate site is sometimes right (the origin is external, out of contract, or a separate issue) — but that is a *decision* to record with its reason, never a default.

## 4. Every run is a breadcrumb

Maintain a running **ledger** of every experiment in this session. Each entry: what changed, what happened, what it ruled in or out.

- When a new hypothesis surfaces, walk the ledger. Does it hold for **every** prior observation, not just the most recent?
- If any past run contradicts it, the hypothesis is wrong or incomplete — refine or discard.
- When in doubt, design the **single experiment** whose outcome makes it certain. Run that next, instead of churning on adjacent runs.
- Update the ledger after every run. It is your memory across the session.
- **Close the ledger with one RC statement** before proposing the fix: `Root cause: <origin> ; Fix site: <where> ; Why not upstream/downstream: <reason>`. If the fix site is not the origin, the third field must justify it. If you cannot fill the first field, you are not done with mantra 3.

---

## When the target is a plan, not a bug

Invoked as `/debug-mantra plan`, or proactively when writing or reviewing the acceptance criteria of a plan, capture doc, or marathon plan. The four mantras apply unchanged and the recital stands verbatim — "the issue — or the artifact" includes the plan's own evidence. Each step is read through its pivot:

| Step | Debug reading | Plan pivot |
|---|---|---|
| 1. Reproduce | Runnable repro of the failure. | **Measured ground truth at plan time.** Every count, `file:line`, and live-state claim in the plan is re-run now, not remembered — a "measured, not assumed" evidence table (claim · command run · observed value) is the shape. A recalled repo state is hypothesis-zero. |
| 2. Fail path | Trace the code that breaks. | **Trace the real path the plan changes**, before proposing: walk it and enumerate every caller and surface it touches. A criterion about a path nobody traced is a guess wearing a checkbox. |
| 3. Falsify | Disprove the root-cause hypothesis. | **Falsify the acceptance criteria.** Each criterion must name how it fails — a criterion that cannot fail is decorative, and one an empty input satisfies passes vacuously. Specify the red control *and where its evidence will land* (`test/baselines/` negative-control pattern; where the repo forbids new tests, XYZ-forge: `AGENTS.md` *No new tests*, GH-831, it runs on an existing suite or is recorded under `TESTS-RESULTS/`). Rank 3–5 alternatives for the load-bearing design choice and name the strongest counterargument (an explicit "Open question for the reviewers" block is the pattern). **Root vs proximate, at plan time:** name the origin the plan fixes and state whether the change removes the failure class or one instance; a plan whose fix site is downstream of the origin must say why (the RC statement from mantra 4 is the shape). |
| 4. Breadcrumbs | Session experiment ledger. | **Recon ledger.** Record the greps, counts, and probes that grounded the plan, citable from the plan or its capture doc. Before finalizing, walk the ledger against what is already shipped — a plan resting on a stale claim (feature already exists, path already changed) inherits the stale claim. |

**The plan-only rule, and why pivot 3 is the strictest:** at plan time falsification is *specified*, not *performed* — strictly weaker evidence than a red control you have watched fire. That gap is why each criterion must name a destination for its red evidence: a planned red control that is not witnessed when implemented is a promise, not a control. Plan reviews have caught criteria "satisfiable by an empty pre-created file" and "satisfiable by a print statement while the defect persisted" — both passed review as written.

Scale rigor as ever: a one-line fix's plan needs a confirming observation, not the full table; a marathon or large-refactor plan needs every pivot. For large refactors this is the SOP "Arc planning" discipline applied debug-mantra-first.

## Operating rules

- Recite the mantra block **once** per debug session, in your first response. Do not re-recite mid-session.
- Recite **verbatim**. Never paraphrase or abridge the recital.
- If the user says "skip the mantra" → skip the recital but still apply the four steps silently.
- Apply the four steps **in order**:
  - Do not propose a fix before #1 is satisfied (reliable repro exists).
  - Do not start testing hypotheses before #2 has narrowed the fail path.
  - Do not commit to a hypothesis before #3 has tried to disprove it.
  - Do not declare a hypothesis correct until #4 confirms it against every prior breadcrumb.
  - Do not propose a fix until the RC statement names the origin, the fix site, and — if they differ — why.
- **Scale rigor to the bug.** The gate is on *evidence*, not ceremony: a trivially obvious defect — a typo, a stack trace pointing straight at the line — needs a confirming **observation**, not necessarily a runnable harness or a written ledger. The burden stays on a direct look, never on assumption.
- If you catch yourself proposing a fix without a reliable repro, stop and return to step 1.
- If you catch yourself building on an unverified observation ("it's obviously X", "that's clearly one Y") — especially one drawn from a screenshot, a rendered view, or memory — stop and inspect the raw artifact first. The impression is hypothesis-zero, not ground truth, and a single direct look at the real object usually settles it faster than any search of the code that might explain it.
- The mantra is a constraint **you** carry through the session — not advice to deliver back to the user.

codex
I’m applying the SWE and debug-mantra plan-review skills. No graph tools are available in this worker, so I’ll use read-only source inspection; remote PR and protection state will remain unverified.

> **Mantra:**
> 1. **First is reproducibility.** Can the issue — or the artifact — be reproduced or observed reliably?
> 2. **Know the fail path.** Debugger first; then source trace + knob enumeration; then in-code instrumentation.
> 3. **Question your hypothesis.** What would disprove it?
> 4. **Every run is a breadcrumb.** Cross-reference all of them.
exec
/bin/zsh -lc 'nl -ba .github/workflows/ci.yml' in /private/var/folders/69/3l_82qtj7fzglnt_jjg07jh40000gn/T/consult-wt-43891-m8ixsws8
 succeeded in 0ms:
     1	name: CI
     2	
     3	# ── READ THIS BEFORE CONCLUDING "CI IS GREEN" (GH-123, 2026-08-21) ──────────────────────────────
     4	#
     5	# Two things about this file have now been re-litigated more than once. Both are recorded here so
     6	# the next person does not rediscover them from scratch.
     7	#
     8	# 1. THE AUTOMATIC TRIGGERS WERE DEAD FROM 2026-08-17 TO 2026-08-21 (GH-59). This is HISTORY, not a
     9	#    live warning — they work now — but it is written down because it silently voided four days of
    10	#    merges and will be misread later if it isn't.
    11	#
    12	#    From the 2026-08-17 re-arm until 17:09 UTC on 2026-08-21, the ENTIRE run history of this
    13	#    repository was `workflow_dispatch` runs. PRs #116, #121 and #122 all merged with ZERO checks.
    14	#    Then, with no change to this file's triggers, both automatic events began firing normally:
    15	#    run 32506672733 (`pull_request`, branch `docs/gh123-ci-canary-codify`) and run 32506697196
    16	#    (`push`, `development`), minutes apart.
    17	#
    18	#    WHY IT STARTED WORKING IS NOT ESTABLISHED. The only honest statement available from a normal
    19	#    token is that it changed between 16:45 and 17:09 UTC on 2026-08-21. If a repository setting was
    20	#    flipped in that window, say so on #59 — the answer is cheap to record now and expensive to
    21	#    reconstruct later. The audit log needs `admin:org`.
    22	#
    23	#    Ruled out during the outage, with evidence, so nobody re-tests them: billing/spending limit (a
    24	#    dispatch on the same branch ran fine — this was the leading theory and it was wrong), workflow
    25	#    disabled (`state=active`), repo is a fork (it is not), Actions disabled (`enabled: true,
    26	#    allowed_actions: all`), the base-branch filter (#116 targeted `development`, which is listed),
    27	#    the workflow missing from the PR head (`d09bdb6` is an ancestor of every branch tested), and
    28	#    fork-PR approval (zero runs ever sat in `action_required`, so nothing was being created).
    29	#
    30	#    A CONFLICTING PR STILL GETS NO RUN, AND THAT IS NORMAL GITHUB BEHAVIOUR — NOT A RELAPSE.
    31	#    `pull_request` workflows are built against the merge ref (`refs/pull/N/merge`), which GitHub
    32	#    does not create while a PR has conflicts, so a conflicted PR shows ZERO checks — visually
    33	#    identical to the outage above. Measured directly on #126: no run for the 9 minutes it was
    34	#    CONFLICTING, then a `pull_request` run within seconds of a rebase clearing it. It is also why
    35	#    #116 got no checks. Before concluding the triggers have broken again, check
    36	#    `gh pr view <n> --json mergeable` — if it says CONFLICTING, rebase and the run appears.
    37	#
    38	#    THE READING RULE THAT OUTLIVES ALL OF THIS: a clean `mergeStateStatus` means "no *failing
    39	#    required* checks", which is also what it says when no checks exist at all. Confirm a run
    40	#    actually exists before treating a green PR page as evidence — `gh pr view <n> --json
    41	#    statusCheckRollup` names the jobs, and an empty array is the tell. To fire this workflow by
    42	#    hand at any time:
    43	#
    44	#        gh workflow run ci.yml --ref <branch>
    45	#        gh run watch <run-id>
    46	#
    47	# 2. AN ADVISORY JOB THAT DIES EARLY STILL REPORTS THE RUN GREEN. The ubuntu canary below is
    48	#    advisory by design ("never breakage") and ends in a verdict step that always passes. That
    49	#    means a FAILING canary is invisible at the run level. It happened: from the 2026-08-17 re-arm
    50	#    until 2026-08-21, `utils/fuzzing/fuzz-loop.sh` had no shebang, shellcheck raised SC2148 at
    51	#    severity=error, the FIRST step of the job exited 1, and every later step — the PDDA gate, the
    52	#    frozen-twin guard, acorn-extract, Fast Gate, validate.sh — silently never ran, for four days,
    53	#    under a green ✓. Fixed in #121 (e9b9b07).
    54	#
    55	#    The lesson is structural, not about that one file: when this job is red, open the JOB and look
    56	#    for steps marked `-`. A short green run is the symptom to distrust. Steps here are ordered
    57	#    cheapest-first, so an early failure hides the most.
    58	#
    59	#    Run 32504570094 (2026-08-21, against 02ce229) is the first end-to-end execution. Baseline:
    60	#    shellcheck / bash+node syntax / settings JSON / PDDA gate / acorn-extract all PASS on Linux;
    61	#    7 assertions across 5 suites fail. Tracked in GH-123 — read it before assuming any of them is
    62	#    environment noise, and see the GH-232 note further down for why that assumption is expensive.
    63	#
    64	#    THIS IS STILL TRUE NOW THAT THE AUTOMATIC TRIGGERS WORK, and that is the point. Runs
    65	#    32506672733 (`pull_request`) and 32506697196 (`push` on `development`) both concluded
    66	#    **success** while this job concluded **failure** on the same 7 assertions. So the trap did not
    67	#    end with the outage in note 1 — restoring the triggers restored a green checkmark on every PR
    68	#    that is reporting a red canary underneath it. Until GH-123 is cleared, treat this job's own
    69	#    conclusion as the signal and the run's conclusion as decoration.
    70	#
    71	# GH-216 cut `development` as the WIP branch that all work targets, but these
    72	# triggers stayed pinned to `main` — so no PR into `development` ran CI at all.
    73	# Both branches are gated here; add any future long-lived integration branch too.
    74	# ── HOSTED CI RE-ARMED FOR THE PUBLIC REPOSITORY (XYZ-forge #16, 2026-08-17) ─────────────────────
    75	#
    76	# GH-544 deliberately removed `push:` and `pull_request:` while the source repository was private.
    77	# That bridge had one explicit end condition: the repository becomes public. HiQS-Labs/XYZ-forge
    78	# is public, so automatic triggers are restored here. The local pre-push gate remains useful as the
    79	# earliest signal; hosted CI restores independent attestation and the Linux portability canary.
    80	#
    81	# WHY: measured in #509/#528 — Aug 1-14 cost $21.99 gross / $10.00 billed, exhausting the 2,000
    82	# included minutes on Aug 11 and hitting the $10 spending limit on Aug 14, which blocked Actions
    83	# outright. Projection at that cadence was ~$47/mo gross. We do not pay that for an internal tool.
    84	#
    85	# THE BRIDGE HAS ENDED. The re-arm keeps the constraints the private-phase analysis established:
    86	#   1. `push:` and `pull_request:` cover main and development. The macOS job itself remains guarded
    87	#      to a push on main; GH-347 moved the Ubuntu portability canary to push-on-development plus
    88	#      deliberate dispatch, so pull requests complete without paying for an advisory full suite.
    89	#   2. Expect a BATCH of accumulated Linux portability drift on the first green-field run. The local
    90	#      gate is macOS, so the platform we ship to stayed covered — the ubuntu canary did not, and drift
    91	#      has been accumulating unreported since this date. That backlog is the known, accepted cost of
    92	#      this decision, not a surprise.
    93	#   3. The GH-509 macOS boundary is again the promotion witness for an exact main commit.
    94	#
    95	# EVERYTHING BELOW IS DELIBERATELY PRESERVED — jobs, routing, and especially the GH-509 Phase 4 cost
    96	# analysis in the macOS job's header. That reasoning is what you will want when re-arming; deleting it
    97	# and rediscovering it on an invoice is the failure this comment exists to prevent.
    98	on:
    99	  push:
   100	    branches: [main, development]
   101	  pull_request:
   102	    branches: [main, development]
   103	  workflow_dispatch:
   104	
   105	concurrency:
   106	  # Cancel superseded runs within the same event lane. Keep manual integration runs
   107	  # independent so a branch push cannot cancel an operator-requested full gate.
   108	  group: ${{ github.workflow }}-${{ github.event_name }}-${{ github.event.pull_request.number || github.ref }}
   109	  cancel-in-progress: true
   110	
   111	permissions:
   112	  contents: read
   113	
   114	jobs:
   115	  # GH-509 Phase 4 — THE PROMOTION BOUNDARY. This is the only job whose green means anything about
   116	  # what we ship, because it is the only one running the platform we ship to.
   117	  #
   118	  # WHY IT IS RARE, AND MUST STAY RARE: hosted macOS runners bill at roughly 10x Linux. At the volume
   119	  # this repo generates (37 pushes to `development` in one 24h sample) macOS-everywhere would cost
   120	  # thousands a month. Do NOT add `pull_request` here.
   121	  #
   122	  # WHY `workflow_dispatch` WAS REMOVED (2026-08-13, measured — this was the original design and it
   123	  # did not survive contact with the invoice). The theory was that a dispatch costs "well under a
   124	  # dollar a handful of times a month". The org's actual August usage says otherwise: macOS 3-core
   125	  # 75 minutes = **$4.65 net**, against Ubuntu's 2,740 minutes = $4.44 net. Seventy-five macOS minutes
   126	  # cost more than 2,740 Linux minutes, because macOS bills ~10x AND draws no included-minute discount
   127	  # on a private repo. Three dispatches on one branch in one day consumed roughly half a $10 monthly
   128	  # budget. The gating was correct; what was missing was any brake on how often the deliberate trigger
   129	  # gets pulled — and "deliberate" is not a rate limit when the same person can dispatch it while
   130	  # iterating on the workflow itself.
   131	  #
   132	  # WHAT THIS COSTS US, STATED PLAINLY: the original argument for `workflow_dispatch` was real —
   133	  # work lands on `development` and `main` sees almost nothing, so a main-only boundary arrives AFTER
   134	  # the promotion decision rather than before it. That gap is now open. The substitute is the LOCAL
   135	  # gate on the platform we ship to: `./validate.sh` (and, per GH-528, `--parallel N` for a ~3-minute
   136	  # run) plus `utils/gate-record.sh`, which is self-reported and does NOT qualify a promotion. If a
   137	  # pre-merge macOS witness is needed for a specific commit, re-enable this trigger deliberately,
   138	  # spend the ~$1.25-1.50, and turn it back off — rather than leaving it armed by default.
   139	  #
   140	  # HONEST LIMIT ON "EXACT COMMIT" (retained; applies to any re-enabled dispatch): `workflow_dispatch`
   141	  # targets a REF, not an arbitrary SHA — GitHub resolves the ref's current HEAD. So this job cannot
   142	  # be pointed at an old commit; it qualifies whatever that ref points to when dispatched. The resolved
   143	  # SHA is printed into the job summary for exactly this reason: the promotion rule compares against a
   144	  # recorded SHA, not against "the run I remember starting".
   145	  #
   146	  # NO SKIP LIST, deliberately. It invokes the authoritative validator directly rather than scraping
   147	  # `TESTS` out of it — the scrape can only see `.sh` entries, which is how the 20-test Python layer
   148	  # (the AUTHORITATIVE implementation since GH-264) went unexercised in CI for months. A second list
   149	  # is a second thing to keep honest; there is no second list here.
   150	  boundary-macos:
   151	    name: promotion boundary (macOS — the platform we ship to)
   152	    if: github.event_name == 'push' && github.ref == 'refs/heads/main'
   153	    runs-on: macos-latest
   154	    # A bound, not an estimate: an unbounded hang is the expensive failure mode, so cap it rather than
   155	    # discover the cost afterwards. The cap tracks MEASURED hosted runtime, not the August "~13-15 min
   156	    # locally" (GH-823): wave-reconcile.yml runs this same `validate.sh --sequential` on this same runner
   157	    # in 60-92 min per job (2026-09-21..25) for every non-docs landing (GH-831: docs, ledger and skill
   158	    # landings run the Small list there instead), so the old 45-min cap would fail every promotion. Keep it >=
   159	    # that workflow's cap; test/ci-workflow.sh fails if it drops below.
   160	    timeout-minutes: 120
   161	    steps:
   162	      - name: Check out repo
   163	        uses: actions/checkout@v7
   164	        with:
   165	          # Same reason as the canary job: fixtures synthesize an "older" ancestor with
   166	          # `git rev-list --max-parents=0 HEAD`, which a shallow clone silently defeats.
   167	          fetch-depth: 0
   168	
   169	      - name: Prepare git environment for fixture-driven tests
   170	        run: |
   171	          set -euo pipefail
   172	          git config --global init.defaultBranch main
   173	          git config --global user.email "ci@runner.invalid"
   174	          git config --global user.name "CI Runner"
   175	
   176	      - name: Install npm dependencies
   177	        run: npm ci
   178	
   179	      # The hosted runner's Python has no pytest, and validate.sh's python lane needs it — the
   180	      # first boundary dispatch (run 31661285957) failed exactly here. Ironic and instructive:
   181	      # GH-509's own headline defect was "the hosted route never ran the 20 python tests"; the
   182	      # first time they ran on hosted macOS, the environment couldn't run them.
   183	      - name: Install Python dependencies for the full suite
   184	        run: python3 -m pip install --quiet --break-system-packages pytest requests PyYAML
   185	
   186	      - name: Verify automatic wave reconciliation (GH-421)
   187	        run: bash test/gh421-auto-wave-reconcile.sh
   188	
   189	      - name: Run the authoritative validator (no skips)
   190	        env:
   191	          # The one documented exclusion, and it is not a coverage skip: this test makes a real
   192	          # billed API call to a live agent. It self-skips off-PATH anyway; the env var makes the
   193	          # intent explicit rather than incidental.
   194	          RELAY_SELF_SUFFICIENCY_SKIP: "1"
   195	        # `--sequential` is PINNED here and must stay pinned. GH-544 made parallel the default for the
   196	        # local gate, which is correct there — but this job is the promotion boundary, and the whole
   197	        # point of it is that its green means something the local run's cannot. Promotion evidence
   198	        # stays sequential (GH-528 Phase 2 has not been met), so the flag is explicit rather than
   199	        # inherited: a future change to validate.sh's default must not be able to silently change what
   200	        # this job attests. test/ci-workflow.sh asserts the flag is present. It runs the FULL registry
   201	        # whatever the classifier would say about the promotion range: the three-tier routing (GH-831)
   202	        # stops at the hosted reconcile, and this is the last full check before a release (O8).
   203	        run: ./validate.sh --sequential
   204	
   205	      - name: Promotion evidence
   206	        if: always()
   207	        run: |
   208	          set -euo pipefail
   209	          if [ "${{ job.status }}" = "success" ]; then
   210	            line="MACOS-BOUNDARY: green ${GITHUB_SHA}"
   211	            note="This commit is promotion-qualified (GH-509 §6). Cite this SHA, not this run."
   212	          else
   213	            line="MACOS-BOUNDARY: red ${GITHUB_SHA}"
   214	            note="NOT promotable. Unlike the ubuntu canary, this ran on the platform we ship to — a failure here is a real defect for real users."
   215	          fi
   216	          echo "$line"
   217	          echo "$note"
   218	          { echo "### $line"; echo; echo "$note"; } >> "$GITHUB_STEP_SUMMARY"
   219	
   220	  # GH-509 Phase 2 — this job is a PORTABILITY CANARY, not a gate.
   221	  #
   222	  # XYZ ships to macOS developers. Linux and Windows are on the roadmap and are not here yet, so a
   223	  # failure on ubuntu is portability DRIFT, not breakage: it says "this would not work on the platform
   224	  # we do not support yet." Every one of the three CI failures on 2026-08-12 was of exactly that shape
   225	  # (agent CLIs absent from the runner), and treating them as breakage is what produced five hours of
   226	  # unread red across eight commits — which is worse than no signal at all, because it trains everyone
   227	  # to ignore the one channel that might have said something real.
   228	  #
   229	  # `continue-on-error: true` at JOB level lets the workflow run pass while this job's own conclusion
   230	  # still records `failure`, so drift stays queryable through the jobs API without marking the commit
   231	  # broken.
   232	  #
   233	  # HONEST LIMIT, stated because this file is exactly the kind of place GH-419 gets violated: the
   234	  # workflow-contract test can assert this key is PRESENT. It cannot assert GitHub's runtime semantics.
   235	  # The acceptance criterion in PROJECT/2-WORKING/GH-509-CI-MINUTE-BURN.md is therefore a witnessed
   236	  # hosted run, not a green grep.
   237	  #
   238	  # Advisory does NOT mean ignorable, and making it non-blocking supplies no reason for anyone to read
   239	  # it — that critique came from the agy review and it is correct. The mechanism that makes it read is
   240	  # elsewhere: the canary's status is a line in the promotion output, consulted at the moment a human
   241	  # is already deciding something. If two consecutive promotions ship with drift named and unresolved,
   242	  # this job has proven it is not being actioned and should be deleted rather than kept as decoration.
   243	  canary-ubuntu:
   244	    name: portability canary (ubuntu — advisory, never breakage)
   245	    # GH-347: integration-time signal, not PR feedback. A development push is the last recurring
   246	    # point before promotion where this drift can be acted on; workflow_dispatch is the deliberate
   247	    # fallback. Push-to-main is after the promotion decision, and pull_request was the 8m54s long pole.
   248	    if: >-
   249	      (github.event_name == 'push' && github.ref == 'refs/heads/development') ||
   250	      github.event_name == 'workflow_dispatch'
   251	    runs-on: ubuntu-latest
   252	    continue-on-error: true
   253	    steps:
   254	      - name: Check out repo
   255	        uses: actions/checkout@v7
   256	        with:
   257	          # GH-232: several tests (e.g. xyz-vendor.sh's staleness check) use `git rev-list
   258	          # --max-parents=0 HEAD` to synthesize an "older" ancestor commit for a fixture. The
   259	          # default shallow clone (depth 1) makes the boundary commit look parentless, so it
   260	          # resolves to the SAME commit as HEAD — silently defeating the fixture, not a real bug.
   261	          fetch-depth: 0
   262	
   263	      - name: Classify CI route
   264	        id: route
   265	        env:
   266	          EVENT_NAME: ${{ github.event_name }}
   267	          BASE_SHA: ${{ github.event.pull_request.base.sha }}
   268	          BEFORE_SHA: ${{ github.event.before }}
   269	        run: |
   270	          set -euo pipefail
   271	
   272	          # GH-509 Phase 3 — pushes classify from their pushed range, like PRs classify from a diff.
   273	          base=""
   274	          case "$EVENT_NAME" in
   275	            pull_request) base="$BASE_SHA" ;;
   276	            push)         base="$BEFORE_SHA" ;;
   277	          esac
   278	
   279	          # FAIL CLOSED, three ways, all reachable in practice:
   280	          #   * a NEW branch's first push sets `before` to all-zeros — there is no range;
   281	          #   * a FORCE-PUSH leaves a `before` that is no longer reachable in this clone;
   282	          #   * an event with no range concept at all (workflow_dispatch handles itself downstream).
   283	          # Any of these emits an empty path list, and ci-route.sh's zero-path branch routes to full.
   284	          # Reusing that already-tested path beats inventing a second fail-closed rule that would
   285	          # need its own proof.
   286	          usable=1
   287	          if [ -z "$base" ] || [ -z "${base//0/}" ]; then
   288	            usable=0
   289	          elif ! git cat-file -e "${base}^{commit}" 2>/dev/null; then
   290	            usable=0
   291	          fi
   292	
   293	          if [ "$usable" -eq 1 ]; then
   294	            # `--no-renames` is load-bearing, not tidiness. With rename detection ON (git's default)
   295	            # `--name-only` prints ONLY the destination path for a rename, so a renamed regression
   296	            # test looks like an ordinary changed file that still exists — and ci-route.sh's
   297	            # fail-closed branch for a vanished test is never reached. That branch's own comment
   298	            # says "deleted/renamed"; without this flag it only ever saw deletions.
   299	            git diff --no-renames --name-only "$base" HEAD \
   300	              | utils/ci-route.sh "$EVENT_NAME" | tee -a "$GITHUB_OUTPUT"
   301	          else
   302	            echo "ci-route: no usable range for $EVENT_NAME (base='${base:-<empty>}') — failing closed to full" >&2
   303	            : | utils/ci-route.sh "$EVENT_NAME" | tee -a "$GITHUB_OUTPUT"
   304	          fi
   305	
   306	      - name: Install shellcheck
   307	        if: steps.route.outputs.docs_only != 'true'
   308	        run: |
   309	          set -euo pipefail
   310	          if command -v shellcheck >/dev/null 2>&1; then
   311	            shellcheck --version
   312	          else
   313	            sudo apt-get update
   314	            sudo apt-get install -y shellcheck
   315	          fi
   316	
   317	      - name: Shellcheck tracked shell scripts
   318	        if: steps.route.outputs.docs_only != 'true'
   319	        run: |
   320	          set -euo pipefail
   321	          # Start at severity=error so Tier 1 lands green; tighten later once the backlog is burned down.
   322	          git ls-files -- '*.sh' | while IFS= read -r file; do
   323	            [ -n "$file" ] || continue
   324	            shellcheck -S error "$file"
   325	          done
   326	
   327	      - name: Bash syntax check tracked shell scripts
   328	        if: steps.route.outputs.docs_only != 'true'
   329	        run: |
   330	          set -euo pipefail
   331	          git ls-files -- '*.sh' | while IFS= read -r file; do
   332	            [ -n "$file" ] || continue
   333	            bash -n "$file"
   334	          done
   335	
   336	      - name: Node syntax check tracked JavaScript
   337	        if: steps.route.outputs.docs_only != 'true'
   338	        run: |
   339	          set -euo pipefail
   340	          git ls-files -- 'src/*.js' 'bin/*.js' | while IFS= read -r file; do
   341	            [ -n "$file" ] || continue
   342	            node --check "$file"
   343	          done
   344	
   345	      - name: Validate .claude/settings JSON
   346	        if: steps.route.outputs.docs_only != 'true'
   347	        run: |
   348	          set -euo pipefail
   349	          git ls-files -- '.claude/settings*.json' | while IFS= read -r file; do
   350	            [ -n "$file" ] || continue
   351	            python3 -m json.tool "$file" >/dev/null
   352	          done
   353	
   354	      - name: Run PDDA deterministic gate
   355	        # PDDA owns documentation state. Run it when that state changes and at every full boundary,
   356	        # but keep its ~2.5-minute scan out of code-only fast PRs.
   357	        if: steps.route.outputs.pdda_needed == 'true'
   358	        run: |
   359	          set -euo pipefail
   360	          utils/pdda/pdda.sh run
   361	          # Checks this repo owns, kept OUTSIDE the sync-managed utils/pdda/ tree because the
   362	          # 2026-08-03 sync (cfd56b0) deleted three of them from upstream's script without a word.
   363	          # Warn-only by contract — it reports, it never gates.
   364	          utils/pdda-local-checks.sh run
   365	
   366	      # GH-308 froze the eleven Tier-A Bash twins and AGENTS.md told readers "CI supplies
   367	      # GH308_FROZEN_TWIN_BASE to reject a committed twin edit". Nothing did — the agy review of
   368	      # PR #318 caught the claim as false ([Blocker]). This is that wiring.
   369	      #
   370	      # Escape hatch: a safety defect in a frozen fallback can legitimately warrant an edit (GH-319
   371	      # left a silently-fake pre-advance gate in marathon-drive.sh under XYZ_PYTHON=0). Such a commit
   372	      # must carry a trailer naming the twin it covers, which makes the exception auditable in
   373	      # `git log` instead of invisible:
   374	
   375	      # GH-230: prove the README Quickstart's npm-dependency path works from a fresh
   376	      # clone, so a missing-install-step regression fails here instead of on a
   377	      # newcomer's machine.
   378	      - name: Install npm dependencies and run acorn-extract test
   379	        if: steps.route.outputs.docs_only != 'true'
   380	        run: |
   381	          set -euo pipefail
   382	          npm ci
   383	          bash test/acorn-extract.sh
   384	
   385	      # GH-232: the acting-agent's user/keychain config and default `git init` branch name are
   386	      # macOS-dev-machine assumptions baked into several fixture-driven tests (e.g. archive-writers.sh,
   387	      # xyz-vendor.sh do a bare `git init` and expect the resulting branch to be "main"). ubuntu-latest's
   388	      # git has no global identity and may default new repos to a non-"main" branch, so prepare both
   389	      # here rather than touch the tests themselves (out of scope for this lane).
   390	      - name: Prepare git environment for fixture-driven tests
   391	        if: steps.route.outputs.docs_only != 'true'
   392	        run: |
   393	          set -euo pipefail
   394	          git config --global init.defaultBranch main
   395	          git config --global user.email "ci@runner.invalid"
   396	          git config --global user.name "CI Runner"
   397	
   398	      # Same install as the promotion-boundary job: without pytest, wave_reconcile's qualification
   399	      # refuses by design (#750), so gh425 went red here and the python lane was skipped (#886).
   400	      - name: Install Python dependencies for the full suite
   401	        if: steps.route.outputs.docs_only != 'true'
   402	        run: python3 -m pip install --quiet --break-system-packages pytest requests PyYAML
   403	
   404	      - name: Run Fast Gate tests (Pull Request)
   405	        # Whole-job budget target: < 3 minutes for a code-only fast PR.
   406	        if: github.event_name == 'pull_request' && steps.route.outputs.route == 'fast'
   407	        env:
   408	          RELAY_SELF_SUFFICIENCY_SKIP: "1"
   409	          CHANGED_TESTS: ${{ steps.route.outputs.changed_tests }}
   410	        run: |
   411	          set -euo pipefail
   412	          FAST_TESTS=(
   413	            "worktree-isolation.sh"
   414	            "shim-worktree.sh"
   415	            "gh292-worktree-vendored-discovery.sh"
   416	            "relay-target-root.sh"
   417	            "relay-target-root-paths.sh"
   418	            "relay-target-root-relayfile.sh"
   419	            "relay-target-root-newfile.sh"
   420	            "gh289-target-root-build-turn.sh"
   421	            "gh410-containment-advisory.sh"
   422	            "tick-foreign-cwd.sh"
   423	            "mktemp-trap-guard.sh"
   424	          )
   425	          if [[ -n "$CHANGED_TESTS" ]]; then
   426	            IFS=',' read -r -a routed_tests <<<"$CHANGED_TESTS"
   427	            for t in "${routed_tests[@]}"; do
   428	              already_listed=0
   429	              for existing in "${FAST_TESTS[@]}"; do
   430	                [[ "$existing" == "$t" ]] && { already_listed=1; break; }
   431	              done
   432	              [[ "$already_listed" -eq 1 ]] || FAST_TESTS+=("$t")
   433	            done
   434	          fi
   435	          FAILED=0
   436	          for t in "${FAST_TESTS[@]}"; do
   437	            echo "=== $t ==="
   438	            bash "test/$t" || FAILED=1
   439	          done
   440	          exit "$FAILED"
   441	
   442	      # GH-232: PR #231 ran the full ./validate.sh suite on ubuntu-latest for the first time and
   443	      # found ~12 failures, assumed to be Ubuntu-environment-only and scoped out of CI. Re-diagnosed
   444	      # directly against a real ubuntu:latest container (not guessed at from macOS): almost all were
   445	      # masked by two things, now both fixed — (1) marathon.sh/marathon-drive.sh (and dependents
   446	      # debug-mantra.sh/driver-lock.sh) used a BSD-only `sed -i ''` invocation that mis-parses under
   447	      # GNU sed; (2) driver-lock.sh/xyz-harness-hooks.sh stubbed CLAUDE_BIN/AGY_BIN but not
   448	      # CODEX_BIN — the actual default builder — so they only "passed" locally because a real `codex`
   449	      # binary happened to be on the developer's own PATH, masking the gap; ubuntu CI has no such
   450	      # binary. path-integrity.sh/archive-writers.sh/relay-file-seeding-visibility.sh/xyz-vendor.sh/
   451	      # hq.sh/relay-pkg-freshness.sh all passed cleanly once re-tested for real — no ubuntu-specific
   452	      # bug in any of them. Registry concurrency is now unregistered by operator disposition
   453	      # (GH-854/GH-917); its retained manual suite must not appear in --skip.
   454	      # GH-379: this step CALLS validate.sh. It must never go back to iterating suites itself.
   455	      #
   456	      # It used to scrape the TESTS array out of validate.sh with sed/grep and run a serial
   457	      # for-loop, in order to carry the then-current skips. That cost three things at once:
   458	      #   * PARALLELISM — GH-528 measured 946.0s -> 184.3s at --parallel 8 with byte-identical
   459	      #     pass/fail sets. The serial loop threw all of it away; the step measured 13m 14s, 88%
   460	      #     of this job's wall and 100% of the repo's sampled runner-minute bill.
   461	      #   * THE CONTENTION-RETRY — validate.sh re-runs a pooled failure alone before believing it,
   462	      #     which is what separates a real red from contention. The loop had no such filter.
   463	      #   * THREE NON-SHELL LANES — python:test_python_layer.py, clone-identity-invariant and
   464	      #     gamma-poison-staleness-probe live OUTSIDE the TESTS array, so a '.sh'-only scrape
   465	      #     could not see them. They had never run on Linux.
   466	      #
   467	      # The skips are now validate.sh's own --skip, which refuses an unregistered name, announces
   468	      # every skip in the header and the summary, and marks the run as not-promotion-evidence.
   469	      # A quarantine that cannot be typo'd into a no-op is the whole point.
   470	      #
   471	      # --parallel is PINNED explicitly, for the same reason boundary-macos pins --sequential: a
   472	      # future change to validate.sh's default must not silently change what this job runs.
   473	      #
   474	      # On the width, stated honestly because the first version of this comment was not: 6 is the
   475	      # POOL width, and validate.sh runs the serialized driver-lock lane as a concurrent background
   476	      # subshell alongside the pool (GH-42/GH-528), so peak concurrency is 6 + 1 = 7 suite processes
   477	      # on an 8-core runner, not 6. That still fits, but it is one core of headroom rather than two.
   478	      # 6 is a REASONED GUESS, not a measurement: GH-528's 5.1x came from a 10-core Mac and nothing
   479	      # has been timed on this runner. Revisit with an A/B of 4 vs 6 once the step has run a few
   480	      # times — the numbers will be in the job log, which is the whole reason for pinning a value
   481	      # that can be compared across runs. (Codex review, 2026-09-02.)
   482	      #
   483	      # No tier or path selector may be added here: the three non-shell lanes are tier-3 lanes, so
   484	      # narrowing the run set would silently retract this issue's headline coverage claim.
   485	      # test/gh379-canary-uses-validate.sh asserts all of this, selector by selector.
   486	      - name: Run validate.sh suite (with documented skips)
   487	        if: steps.route.outputs.route == 'full'
   488	        env:
   489	          RELAY_SELF_SUFFICIENCY_SKIP: "1"
   490	        run: |
   491	          set -euo pipefail
   492	          ./validate.sh --parallel 6 \
   493	            --skip acorn-extract.sh \
   494	            --skip pdda-repo-contract.sh
   495	
   496	      # GH-509 Phase 2 — the canary's verdict, written where a human and a script can both find it.
   497	      #
   498	      # `if: always()` because the whole point is to report when an EARLIER step failed; without it
   499	      # this step is skipped in exactly the case it exists for. `job.status` is the aggregate of the
   500	      # steps above, so this reads the outcome rather than re-deriving it.
   501	      #
   502	      # The line is deliberately greppable and deliberately does NOT say "failed" or "error": on this
   503	      # platform those words are wrong. This job reports on an operating system we do not ship to yet.
   504	      - name: Portability canary verdict
   505	        if: always()
   506	        run: |
   507	          set -euo pipefail
   508	          if [ "${{ job.status }}" = "success" ]; then
   509	            verdict="PORTABILITY-CANARY: green"
   510	            detail="No Linux portability drift detected. This says nothing about macOS, which is what we ship."
   511	          else
   512	            verdict="PORTABILITY-CANARY: drift"
   513	            detail="Linux portability drift on ${GITHUB_SHA}. This is NOT breakage: XYZ ships to macOS and Linux support is not here yet. Do not treat this commit as broken. Carry the drift into the promotion output and resolve it before Linux support ships."
   514	          fi
   515	          echo "$verdict"
   516	          echo "$detail"
   517	          { echo "### $verdict"; echo; echo "$detail"; } >> "$GITHUB_STEP_SUMMARY"
   518	
   519	  # GH-396 Phase 4 — Vendored smoke gate: verifies the vendored .xyz/ layout end-to-end in CI.
   520	  # Blocking on development and main (continue-on-error: false).
   521	  # GitHub-hosted on purpose: this is the only merge-blocking job. A third-party runner pool that
   522	  # silently stopped claiming jobs (2026-09-12: no runner for 20h, 5 runs queued, two PRs landed on
   523	  # local evidence) stalled the trunk once; every job in this workflow is GitHub-hosted since then.
   524	  vendored-smoke:
   525	    name: vendored smoke gate (blocking on development + main)
   526	    runs-on: ubuntu-latest
   527	    continue-on-error: false
   528	    timeout-minutes: 15
   529	    steps:
   530	      - name: Check out repo
   531	        uses: actions/checkout@v7
   532	        with:
   533	          fetch-depth: 0
   534	
   535	      - name: Prepare git environment
   536	        run: |
   537	          set -euo pipefail
   538	          git config --global init.defaultBranch main
   539	          git config --global user.email "ci@runner.invalid"
   540	          git config --global user.name "CI Runner"
   541	
   542	      - name: Verify automatic wave reconciliation (GH-421)
   543	        run: bash test/gh421-auto-wave-reconcile.sh
   544	      # GH-308 / GH-459: Frozen Bash twin guard runs on PRs against the PR base SHA.
   545	      # Sited in vendored-smoke because this job triggers on pull_request with fetch-depth: 0.
   546	      - name: Frozen Bash twin guard (GH-308)
   547	        if: github.event_name == 'pull_request'
   548	        env:
   549	          BASE_SHA: ${{ github.event.pull_request.base.sha }}
   550	        run: |
   551	          set -euo pipefail
   552	          bash test/gh308-frozen-twin-guard.sh --check --base "$BASE_SHA" --allow-exceptions
   553	
   554	      - name: Vendor harness into scratch repo and run vendored suites
   555	        run: |
   556	          set -euo pipefail
   557	          HARNESS_DIR="$(pwd)"
   558	          SCRATCH="$(mktemp -d)"
   559	          git -C "$SCRATCH" init -q -b main
   560	          git -C "$SCRATCH" config user.email "ci@runner.invalid"
   561	          git -C "$SCRATCH" config user.name "CI Runner"
   562	          touch "$SCRATCH/README.md"
   563	          git -C "$SCRATCH" add README.md
   564	          git -C "$SCRATCH" commit -qm "init scratch repo"
   565	
   566	          # Materialize vendored harness without touching global ~/.xyz registries
   567	          bash "$HARNESS_DIR/relay-automation/xyz-vendor.sh" --no-register "$SCRATCH"
   568	
   569	          # Run vendored suites from inside scratch repo against .xyz/
   570	          (
   571	            cd "$SCRATCH"
   572	            bash .xyz/test/gh396-find-harness-roots.sh
   573	            bash .xyz/test/gh393-deepseek-readiness.sh
   574	            bash .xyz/test/gh358-wave-reconcile-vendored-paths.sh
   575	            bash .xyz/test/gh292-worktree-vendored-discovery.sh
   576	          )
   577	

exec
/bin/zsh -lc 'nl -ba ci-local.sh' in /private/var/folders/69/3l_82qtj7fzglnt_jjg07jh40000gn/T/consult-wt-43891-m8ixsws8
 succeeded in 0ms:
     1	#!/usr/bin/env bash
     2	# ci-local.sh — run the tier1 CI job on this machine, step for step.
     3	#
     4	# WHY THIS EXISTS: GitHub Actions is metered. Every push burned budget to learn things a laptop can
     5	# tell you for free, and when the budget ran out `gh pr checks` started reporting `fail` in 2 seconds
     6	# on every commit — not a test failure, but "the job was not started because recent account payments
     7	# have failed". A red check that means nothing is worse than no check, because a real break looks
     8	# identical. This runs the same steps locally so the signal keeps existing.
     9	#
    10	# It follows .github/workflows/ci.yml's job in ORDER and CONTENT, but NOT in coverage — see the
    11	# section below. test/ci-workflow.sh pins the parts that must not drift.
    12	#
    13	# ─────────────────────────────────────────────────────────────────────────────────────────────────
    14	# THIS RUNS ON THE PLATFORM WE SHIP TO. THE HOSTED UBUNTU JOB DOES NOT. (GH-509)
    15	# ─────────────────────────────────────────────────────────────────────────────────────────────────
    16	# XYZ is a local developer toolkit for macOS developers. Linux and Windows support are on the roadmap
    17	# and are not here yet. So the direction of the old caveat here — "a green local run does not mean a
    18	# green ubuntu run" — was true but pointed at the less useful risk. Reversed and stated properly:
    19	#
    20	#   * A green run HERE is the best evidence we have about what users experience, because your machine
    21	#     is the shipping platform with the real toolchain.
    22	#   * A green run on hosted UBUNTU says little. That job is an advisory portability canary; its red
    23	#     means "would not work on a platform we do not support yet", not "broken".
    24	#
    25	# This script runs the current registry with only the already-run npm suite skipped.
    26	# Operator-retired suites are recorded in gh306 EXEMPT (GH-854); local runs do not restore them.
    27	#
    28	# THE HONEST LIMIT IS NOW ELSEWHERE, and it is not about platform. This run is SELF-REPORTED: it
    29	# proves someone ran the suite, not that they ran it on the code they are shipping. That is what the
    30	# hosted macOS boundary job buys — a clean machine, and evidence not produced by the claimant.
    31	# ─────────────────────────────────────────────────────────────────────────────────────────────────
    32	#
    33	# Usage:
    34	#   ./ci-local.sh              # every step (~15-20 min; the suite dominates)
    35	#   ./ci-local.sh --fast       # everything EXCEPT the full validate.sh suite (~1 min)
    36	#   ./ci-local.sh --base REF   # also run the frozen-twin guard against REF (CI does this on PRs only)
    37	#   ./ci-local.sh --probe      # GH-509: the UNCONFIGURED-MAC probe (see below)
    38	#
    39	# ── --probe: what a new adopter's machine actually looks like (GH-509 / GH-520) ──────────────────
    40	# Runs with `codex`, `agy` and `aider` stripped from PATH, simulating a Mac where XYZ has just been
    41	# installed and none of the agent CLIs are set up yet. That is a real audience, not a hypothetical:
    42	# GH-380 describes someone installing Claude Code specifically to run the swarm, with nothing else on
    43	# the box.
    44	#
    45	# It is also the only cheap way to catch a whole defect class. On 2026-08-12 three suites passed here
    46	# and failed in CI purely because those binaries exist on this machine and not on a runner (#520).
    47	# This probe reproduced all three in ~90 seconds. It is NOT a Linux check — it is a
    48	# "does-this-work-before-the-operator-has-installed-everything" check, and it belongs on the same
    49	# platform we ship to.
    50	#
    51	# ── The per-commit record, and what it is NOT (GH-509) ───────────────────────────────────────────
    52	# A successful full run writes `.gate-evidence/<sha>.txt`. That answers exactly one question — "has
    53	# anyone run the whole suite against THIS commit?" — so an agent or operator can tell a verified HEAD
    54	# from an unverified one without re-running 15 minutes of tests on a hunch.
    55	#
    56	# It is deliberately NOT promotion evidence. An earlier draft of the GH-509 plan let a local record
    57	# qualify a commit for promotion; the agy review called that circular and was right — if a
    58	# self-reported record satisfies the boundary, the boundary is optional and buys nothing. Promotion
    59	# needs the hosted macOS run. This record is for the day-to-day question, not the release question.
    60	#
    61	# Refused from a dirty tree, and that refusal is the whole integrity story: a record keyed to a
    62	# commit hash while uncommitted edits sit in the tree would name a state that was never tested.
    63	
    64	set -uo pipefail
    65	
    66	HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    67	cd "$HERE" || exit 1
    68	
    69	# The same gate-environment prologue validate.sh sources (GH-441 scrub of ambient marathon exports;
    70	# GH-730 no-bytecode rule). This runner launches suites and pytest directly below, so it must source
    71	# it itself — a `validate.sh --list` child cannot export back into this shell.
    72	. "$HERE/relay-automation/gate-env.sh"
    73	
    74	# ── GH-45: REFUSE to run from a linked git worktree ─────────────────────────────────────────────
    75	# Same guard, same reason, same override as validate.sh's (kept inline in both rather than a new
    76	# shared .sh — GH-551; both copies are pinned by test/gh35-test-tiers.sh): this script runs the
    77	# SAME suite validate.sh does, so running it from a worktree exposes the parent clone's shared
    78	# .git to exactly the fixture-escape damage validate.sh refuses (2026-08-19 incident, GH-564).
    79	if [ "${XYZ_ALLOW_WORKTREE_GATE:-0}" != "1" ]; then
    80	  _wt_abs_git="$(git rev-parse --absolute-git-dir 2>/dev/null || true)"
    81	  _wt_common="$(git rev-parse --git-common-dir 2>/dev/null || true)"
    82	  _wt_common_abs=""
    83	  [ -n "$_wt_common" ] && _wt_common_abs="$(cd "$_wt_common" 2>/dev/null && pwd -P || true)"
    84	  if [ -n "$_wt_abs_git" ] && [ -n "$_wt_common_abs" ] && [ "$_wt_abs_git" != "$_wt_common_abs" ]; then
    85	    cat >&2 <<'WTREFUSE'
    86	ci-local: REFUSING — this is a linked git worktree, which shares the parent clone's
    87	  .git (config, refs, objects). The suite this script runs can reach the PARENT clone,
    88	  not a fixture: an observed run set core.bare=true, repointed origin at a deleted temp
    89	  path, deleted every refs/remotes/origin/*, and overwrote development with fixture
    90	  commits. Run the qualifying gate from a normal clone. Override with
    91	  XYZ_ALLOW_WORKTREE_GATE=1 only if you accept that blast radius.
    92	WTREFUSE
    93	    exit 2
    94	  fi
    95	else
    96	  echo "ci-local: XYZ_ALLOW_WORKTREE_GATE=1 — running from a linked worktree at the operator's explicit request; the parent clone's .git is exposed (GH-45)." >&2
    97	fi
    98	unset _wt_abs_git _wt_common _wt_common_abs
    99	
   100	FAST=0
   101	BASE=""
   102	PROBE=0
   103	while (($#)); do
   104	  case "$1" in
   105	    --fast) FAST=1; shift ;;
   106	    --probe) PROBE=1; shift ;;
   107	    --base) BASE="${2:-}"; shift 2 ;;
   108	    -h|--help) sed -n '1,60p' "$0"; exit 0 ;;
   109	    *) echo "ci-local: unknown argument: $1" >&2; exit 2 ;;
   110	  esac
   111	done
   112	
   113	# GH-509/GH-520 — strip the agent CLIs from PATH for the probe. Done by rebuilding PATH without the
   114	# directories that hold them, rather than by unsetting *_BIN vars: the failure being reproduced is a
   115	# binary that is not on PATH at all, and a shim that falls back to a PATH lookup would defeat a
   116	# variable-only approach.
   117	if [ "$PROBE" -eq 1 ]; then
   118	  probe_dirs=""
   119	  for c in codex agy aider; do
   120	    p="$(command -v "$c" 2>/dev/null || true)"
   121	    [ -n "$p" ] && probe_dirs="$probe_dirs $(dirname "$p")"
   122	  done
   123	  if [ -n "$probe_dirs" ]; then
   124	    new_path=""
   125	    while IFS= read -r d; do
   126	      [ -n "$d" ] || continue
   127	      skip=0
   128	      for pd in $probe_dirs; do [ "$d" = "$pd" ] && { skip=1; break; }; done
   129	      [ "$skip" -eq 1 ] && continue
   130	      new_path="${new_path:+$new_path:}$d"
   131	    done < <(printf '%s\n' "${PATH//:/$'\n'}")
   132	    PATH="$new_path"; export PATH
   133	  fi
   134	  # Assert the condition rather than assume it. A probe that silently ran with the binaries still
   135	  # present would report green and mean nothing — the exact shape of failure this repo keeps paying
   136	  # for, and the reason GH-520's control aborts on the same check.
   137	  still=""
   138	  for c in codex agy aider; do command -v "$c" >/dev/null 2>&1 && still="$still $c"; done
   139	  if [ -n "$still" ]; then
   140	    echo "ci-local --probe: ABORT — still on PATH:$still (the probe would be meaningless)" >&2
   141	    exit 2
   142	  fi
   143	  printf '\033[33mmode: --probe (codex/agy/aider stripped from PATH — simulating a fresh Mac)\033[0m\n'
   144	fi
   145	
   146	PASSED=(); FAILED=()
   147	
   148	# GH-536: where the suite transcript and per-suite verdicts land, so gate-record.sh can hash the
   149	# first and embed the second. Per-PID so two concurrent runs on one machine cannot cross-write.
   150	GATE_SUITE_LOG="${TMPDIR:-/tmp}/ci-local-suite-$$.log"
   151	GATE_VERDICTS="${TMPDIR:-/tmp}/ci-local-verdicts-$$.txt"
   152	trap 'rm -f "$GATE_SUITE_LOG" "$GATE_VERDICTS"' EXIT
   153	# GH-365 step 2: retained JSONL telemetry, same lib and schema validate.sh uses. rt_begin is
   154	# deferred to the run section (mode is known there); stage timing is wired once, here, so every
   155	# step() below is timed uniformly without per-step ceremony.
   156	. "$HERE/test/lib/runner-telemetry.sh"
   157	step() {  # <name> — everything after is the step body, run in a subshell
   158	  local name="$1" _s; shift
   159	  _s="$(rt_now_ms)"
   160	  printf '\n\033[1m=== %s\033[0m\n' "$name"
   161	  if "$@"; then PASSED+=("$name"); rt_emit stage stage "$name" "$_s" "$(rt_now_ms)" 0
   162	  else FAILED+=("$name"); rt_emit stage stage "$name" "$_s" "$(rt_now_ms)" 1; printf '\033[31mFAILED: %s\033[0m\n' "$name" >&2; fi
   163	}
   164	
   165	# ── 1. prerequisites ─────────────────────────────────────────────────────────────────────────────
   166	# CI apt-installs shellcheck; locally it is the operator's to provide. Checked up front so the run
   167	# does not get 15 minutes in before discovering a missing binary.
   168	check_prereqs() {
   169	  local missing=0 c
   170	  for c in shellcheck bash node python3 npm git; do
   171	    if command -v "$c" >/dev/null 2>&1; then
   172	      printf '  ok       %s\n' "$c"
   173	    else
   174	      printf '  MISSING  %s\n' "$c" >&2; missing=1
   175	    fi
   176	  done
   177	  [ "$missing" -eq 0 ] || {
   178	    echo "  shellcheck: brew install shellcheck   (CI apt-installs it; this is the only extra dep)" >&2
   179	    return 1
   180	  }
   181	  return 0
   182	}
   183	
   184	# ── 2-5. the cheap static checks, verbatim from the workflow ─────────────────────────────────────
   185	# GH-365 step 5 census: THIS is the one local scan site for the shellcheck BINARY (the hosted
   186	# job in ci.yml is the other); no registered suite executes it — everything else in test/ is
   187	# directives. Parallel at the balanced four-worker width (the same policy validate.sh's pool
   188	# uses): one process per file, so per-file diagnostics are IDENTICAL to the serial shape — only
   189	# their interleaving in the aggregate stream can differ. (A comment here must never START with
   190	# the word "shellcheck" — the scanner parses that prefix as a directive and the scan itself goes
   191	# red on SC1072/SC1073; observed on the first qualifying run at 76174765.) XYZ_SHELLCHECK_JOBS=1
   192	# restores the exact serial shape (xargs -P 1); xargs aggregates per-file failures nonzero.
   193	shellcheck_tracked() {
   194	  # severity=error, matching the workflow's deliberate choice to land green before tightening.
   195	  git ls-files -z -- '*.sh' | xargs -0 -P "${XYZ_SHELLCHECK_JOBS:-4}" -n 1 shellcheck -S error
   196	}
   197	
   198	bash_syntax_tracked() {
   199	  local rc=0 file
   200	  while IFS= read -r file; do
   201	    [ -n "$file" ] || continue
   202	    bash -n "$file" || rc=1
   203	  done < <(git ls-files -- '*.sh')
   204	  return $rc
   205	}
   206	
   207	node_syntax_tracked() {
   208	  local rc=0 file
   209	  while IFS= read -r file; do
   210	    [ -n "$file" ] || continue
   211	    node --check "$file" || rc=1
   212	  done < <(git ls-files -- 'src/*.js' 'bin/*.js')
   213	  return $rc
   214	}
   215	
   216	settings_json_valid() {
   217	  local rc=0 file
   218	  while IFS= read -r file; do
   219	    [ -n "$file" ] || continue
   220	    python3 -m json.tool "$file" >/dev/null || rc=1
   221	  done < <(git ls-files -- '.claude/settings*.json')
   222	  return $rc
   223	}
   224	
   225	# ── 6. PDDA ──────────────────────────────────────────────────────────────────────────────────────
   226	pdda_gate() {
   227	  utils/pdda/pdda.sh run || return 1
   228	  # Warn-only by contract — it reports, it never gates. Kept outside the sync-managed utils/pdda/
   229	  # tree because a 2026-08-03 upstream sync silently deleted three of these checks.
   230	  utils/pdda-local-checks.sh run || true
   231	  return 0
   232	}
   233	
   234	# ── 7. frozen twin guard — PR-only in CI, so opt-in here ─────────────────────────────────────────
   235	frozen_twin_guard() {
   236	  bash test/gh308-frozen-twin-guard.sh --check --base "$BASE" --allow-exceptions
   237	}
   238	
   239	# ── 8. npm + acorn-extract ───────────────────────────────────────────────────────────────────────
   240	# A fresh clone has no node_modules, so acorn-extract dies with MODULE_NOT_FOUND. CI proves the
   241	# README Quickstart path from scratch (GH-230); the same install is what makes a fresh checkout
   242	# gate-ready at all — a marathon has already halted on exactly this.
   243	npm_and_acorn() {
   244	  npm ci || return 1
   245	  bash test/acorn-extract.sh
   246	}
   247	
   248	# ── 9. the suite ─────────────────────────────────────────────────────────────────────────────────
   249	# TESTS is parsed out of validate.sh exactly the way the workflow parses it, so the two cannot drift
   250	# on WHICH tests run — only on the environment they run in.
   251	#
   252	# NOTE: `git config --global` is what CI does before this step, to supply the user identity and
   253	# init.defaultBranch that fixture-driven tests assume. That is deliberately NOT done here: a dev
   254	# machine already has both, and silently rewriting an operator's global git config is not something
   255	# a test runner should do. If a fixture test fails on a bare machine, set them yourself.
   256	validate_suite() {
   257	  # GH-509: THIS SKIP LIST IS DELIBERATELY SHORTER THAN THE WORKFLOW'S, and that is the point.
   258	  #
   259	  # Registry membership comes from validate.sh; operator-retired manual suites stay out
   260	  # of both runners (GH-854/GH-917/GH-918). Ubuntu also skips its repo-contract check.
   261	  #
   262	  # Only ONE skip survives, and it is not a platform concession: acorn-extract.sh already ran in the
   263	  # npm step above, so running it again would be duplicated work rather than dropped coverage.
   264	  local skip_tests=(
   265	    "acorn-extract.sh"                # already run above (needs npm ci first) — duplicate, not dropped
   266	  )
   267	  local all_tests=() line t s skip rc=0
   268	  while IFS= read -r line; do
   269	    [ -n "$line" ] && all_tests+=("$line")
   270	  done < <(sed -n '/^TESTS=(/,/^)/p' validate.sh | grep -oE '"[^"]+\.sh"' | tr -d '"')
   271	
   272	  [ "${#all_tests[@]}" -gt 0 ] || { echo "  could not parse TESTS from validate.sh" >&2; return 1; }
   273	  echo "  ${#all_tests[@]} suites declared in validate.sh"
   274	
   275	  # GH-536: capture the transcript and a per-suite verdict list so the evidence record can carry an
   276	  # output hash and individual verdicts instead of a bare `result: green`.
   277	  #
   278	  # `tee -a` keeps the operator's live output intact — a 15-minute run that goes silent to build a
   279	  # log would be a bad trade. `${PIPESTATUS[0]}` is load-bearing: with a pipe, `$?` is tee's status,
   280	  # so a failing suite would look green. `set -o pipefail` is already on, but reading PIPESTATUS
   281	  # directly says which element is being tested rather than relying on a shell option set 150 lines
   282	  # away.
   283	  : > "$GATE_SUITE_LOG"
   284	  : > "$GATE_VERDICTS"
   285	  _one="${TMPDIR:-/tmp}/ci-local-onesuite-$$.log"   # GH-365: per-suite capture for telemetry bytes/hash
   286	  for t in "${all_tests[@]}"; do
   287	    skip=0
   288	    for s in "${skip_tests[@]}"; do [ "$t" = "$s" ] && { skip=1; break; }; done
   289	    [ "$skip" -eq 1 ] && { echo "SKIP (already run above): $t"; printf '%s\tskip\n' "$t" >> "$GATE_VERDICTS"; rt_emit suite stage "$t" "$(rt_now_ms)" "$(rt_now_ms)" 0 "verdict=skip-duplicate"; continue; }
   290	    echo "=== $t ===" | tee -a "$GATE_SUITE_LOG"
   291	    _s="$(rt_now_ms)"
   292	    # Two tees: the first APPENDS the shared transcript, the second writes the per-suite capture
   293	    # (truncated fresh). BSD tee does NOT permute options — the earlier single
   294	    # `tee "$_one" -a "$GATE_SUITE_LOG"` treated -a as a FILENAME (empirically confirmed:
   295	    # `printf hi | tee ./one -a ./two` leaves a file named '-a' in CWD), creating that stray file
   296	    # in the repo root on every suite. The GH-365 envelope's tree bracket caught it and refused
   297	    # to attest two qualifying runs before the shape was pinned.
   298	    bash "test/$t" 2>&1 | tee -a "$GATE_SUITE_LOG" | tee "$_one"
   299	    _rc="${PIPESTATUS[0]}"
   300	    if [ "$_rc" -eq 0 ]; then
   301	      printf '%s\tpass\n' "$t" >> "$GATE_VERDICTS"
   302	    else
   303	      rc=1
   304	      printf '%s\tFAIL\n' "$t" >> "$GATE_VERDICTS"
   305	      echo "  ^^ FAILED: $t" >&2
   306	    fi
   307	    rt_suite sequential "$t" "$_s" "$(rt_now_ms)" "$_rc" "$_one"
   308	  done
   309	  rm -f "$_one"
   310	
   311	  # GH-377 review blocker 1: the qualifying run must execute the AUTHORITATIVE tier-3 set, not a
   312	  # .sh-only subset. validate.sh owns three non-TESTS lanes; this runner supplies its own envelope
   313	  # bracket (the identity half of lane two), but Python and gamma-poison were historically omitted
   314	  # while the output said "full suite" and the record claimed qualifying evidence. They are part of
   315	  # the loop now, recorded in the verdicts under validate.sh's own PASSED labels so the record and
   316	  # the summary agree on the denominator.
   317	  _s="$(rt_now_ms)"
   318	  _rc=0
   319	  if python3 -m pytest "$HERE/test/test_python_layer.py"; then
   320	    printf '%s\tpass\n' "python:test_python_layer.py" >> "$GATE_VERDICTS"
   321	  else
   322	    _rc=$?   # before any other statement — the printf/echo and the rt_now_ms substitutions reset $?
   323	    rc=1
   324	    printf '%s\tFAIL\n' "python:test_python_layer.py" >> "$GATE_VERDICTS"
   325	    echo "  ^^ FAILED: python:test_python_layer.py" >&2
   326	  fi
   327	  rt_emit suite sequential "python:test_python_layer.py" "$_s" "$(rt_now_ms)" "$_rc"
   328	
   329	  _s="$(rt_now_ms)"
   330	  _rc=0
   331	  if git apply --check "$HERE/test/fixtures/gamma-poison/poison.patch" 2>/dev/null; then
   332	    printf '%s\tpass\n' "gamma-poison-staleness-probe" >> "$GATE_VERDICTS"
   333	  else
   334	    _rc=$?   # before any other statement — same ordering rule
   335	    rc=1
   336	    printf '%s\tFAIL\n' "gamma-poison-staleness-probe" >> "$GATE_VERDICTS"
   337	    echo "  ^^ FAILED: gamma-poison-staleness-probe" >&2
   338	  fi
   339	  rt_emit suite sequential "gamma-poison-staleness-probe" "$_s" "$(rt_now_ms)" "$_rc"
   340	  return $rc
   341	}
   342	
   343	# ── 10. GH-10/GH-365: the shared envelope bracket — assert half ─────────────────────────────────
   344	# The qualifying run writes the gate-evidence record, so it carries the same clone-identity
   345	# bracket validate.sh has, from the SAME shared helper (GH-365 step 1): identity drift fails the
   346	# run (the GH-564 incident), and envelope drift (tracked tree / worktrees / driver lock changed
   347	# under the run) is named and also fails — a qualifying run that cannot retain attributable
   348	# evidence must not exit green (the failure mode #365 exists to prevent).
   349	ci_local_envelope_assert() {
   350	  runner_envelope_assert "$HERE" "ci-local.sh"
   351	  local rc=$?
   352	  RT_ENVELOPE_RC="$rc"; RT_ENVELOPE_DRIFT="${RUNNER_ENVELOPE_DRIFT_FACETS:-none}"
   353	  return "$rc"
   354	}
   355	
   356	# ── run ──────────────────────────────────────────────────────────────────────────────────────────
   357	printf '\033[1mci-local — mirroring .github/workflows/ci.yml tier1\033[0m\n'
   358	printf 'repo: %s\n' "$HERE"
   359	printf 'HEAD: %s\n' "$(git log --oneline -1 2>/dev/null)"
   360	[ "$FAST" -eq 1 ] && printf '\033[33mmode: --fast (full validate.sh suite SKIPPED)\033[0m\n'
   361	# GH-365 step 2: open the retained telemetry record for THIS run (same schema as validate.sh).
   362	# The registered denominator is parsed here, once, exactly the way validate_suite parses TESTS —
   363	# so run.start carries the explicit denominator instead of inheriting a stale section count.
   364	# The denominator comes from validate.sh --list — the READ-ONLY registry surface #141 built for
   365	# exactly this (secondary selectors share one source of truth) — not a second TESTS scrape.
   366	# This is not "invoking validate.sh" in the sense gh544 pins: the gate never runs, no suites, no
   367	# envelope; it prints the manifest and exits.
   368	_declared="$(bash "$HERE/validate.sh" --list | wc -l | tr -d ' ')"
   369	if [ "$FAST" -eq 1 ]; then
   370	  rt_begin "$HERE" "ci-local" "fast" 1 3 "$_declared"
   371	else
   372	  rt_begin "$HERE" "ci-local" "sequential" 1 3 "$_declared"
   373	fi
   374	
   375	step "prerequisites"                check_prereqs
   376	step "shellcheck tracked scripts"   shellcheck_tracked
   377	step "bash syntax"                  bash_syntax_tracked
   378	step "node syntax"                  node_syntax_tracked
   379	step "settings JSON"                settings_json_valid
   380	step "PDDA deterministic gate"      pdda_gate
   381	if [ -n "$BASE" ]; then
   382	  step "frozen twin guard"          frozen_twin_guard
   383	else
   384	  printf '\n\033[33mSKIP: frozen twin guard — CI runs it on pull_request only. Pass --base <ref> to run it.\033[0m\n'
   385	fi
   386	step "npm ci + acorn-extract"       npm_and_acorn
   387	# GH-10/GH-1 + GH-365 step 1: the qualifying run gets the SAME envelope validate.sh uses, from
   388	# the ONE shared helper — harness-registry scratch (XYZ_HARNESS_DB) AND the identity bracket AND
   389	# the tree/worktree/lock bracket. Before GH-365, this run executed the registered suites with no
   390	# scratch envelope at all: harness_app.py writes landed in the TRACKED harnesses.db, the tree
   391	# went dirty, and gate-record.sh then refused to retain the record for exactly the run that
   392	# needed it. Fail closed if the helper is missing — never a second inline envelope.
   393	if [ "$FAST" -eq 0 ]; then
   394	  if [ ! -f "$HERE/test/lib/runner-envelope.sh" ]; then
   395	    echo "ci-local: test/lib/runner-envelope.sh is missing — the shared GH-365 runner envelope cannot be set up; refusing." >&2
   396	    exit 1
   397	  fi
   398	  . "$HERE/test/lib/runner-envelope.sh"
   399	  runner_envelope_begin "$HERE" "ci-local.sh" || exit 1
   400	  RELAY_SELF_SUFFICIENCY_SKIP=1 step "validate.sh suite" validate_suite
   401	  step "clone-identity invariant (GH-1)" ci_local_envelope_assert
   402	  runner_envelope_scrub
   403	fi
   404	
   405	# ── report ───────────────────────────────────────────────────────────────────────────────────────
   406	printf '\n\033[1m─── ci-local summary ───\033[0m\n'
   407	for s in "${PASSED[@]}"; do printf '  \033[32m+\033[0m %s\n' "$s"; done
   408	if [ "${#FAILED[@]}" -gt 0 ]; then
   409	  for s in "${FAILED[@]}"; do printf '  \033[31m-\033[0m %s\n' "$s"; done
   410	  printf '\n\033[31mci-local: %d step(s) failed\033[0m\n' "${#FAILED[@]}"
   411	  printf 'This ran on macOS — the platform XYZ ships to — so a failure here is a real defect for\n'
   412	  printf 'real users. Do not wait for hosted CI to confirm it; the ubuntu job is advisory (GH-509).\n'
   413	  rt_summary "${#PASSED[@]}" "${#FAILED[@]}" "$(( ${#PASSED[@]} + ${#FAILED[@]} ))" "declared=$_declared" "recorded=no"
   414	  exit 1
   415	fi
   416	printf '\n\033[32mci-local: all steps passed\033[0m\n'
   417	printf 'Green on the shipping platform, with the full suite — including the one hosted ubuntu skips.\n'
   418	printf 'NOT a promotion qualification: this run is self-reported. Promotion needs a hosted macOS run\n'
   419	printf 'for this exact commit (GH-509 §6) — a clean machine, and evidence you did not produce.\n'
   420	
   421	# ── GH-509: record that THIS COMMIT was verified here ────────────────────────────────────────────
   422	# Only a full run earns a record. A --fast or --probe run deliberately does not exercise the suite,
   423	# so recording one would make a partial run indistinguishable from a complete one — which is the
   424	# whole failure mode this file keeps warning about in other contexts.
   425	#
   426	# GH-365 step 1: a REFUSED record now fails the qualifying run instead of passing silently
   427	# (`|| true` used to swallow it). The record is the product of this run: a green exit with no
   428	# retained evidence is precisely the "cannot retain its evidence" failure #365 exists to prevent.
   429	# gate-record's own refusal names what made the tree dirty (exit 3) or why no commit was found
   430	# (exit 4); the envelope assert above has already named any drift that explains it.
   431	if [ "$FAST" -eq 0 ] && [ "$PROBE" -eq 0 ]; then
   432	  printf '\n'
   433	  # Delegated rather than inlined, so the REFUSAL has a test that does not cost a 15-minute suite run.
   434	  _gr_rc=0
   435	  bash utils/gate-record.sh --suite-log "$GATE_SUITE_LOG" --verdicts "$GATE_VERDICTS" || _gr_rc=$?
   436	  rt_emit stage stage "gate-record" "$(rt_now_ms)" "$(rt_now_ms)" "$_gr_rc"
   437	  if [ "$_gr_rc" -ne 0 ]; then
   438	    printf '\033[31mci-local: gate-record refused (exit %d) — this qualifying run leaves NO evidence record, so it cannot exit green (GH-365).\033[0m\n' "$_gr_rc" >&2
   439	    rt_summary "${#PASSED[@]}" "${#FAILED[@]}" "$(( ${#PASSED[@]} + ${#FAILED[@]} ))" "declared=$_declared" "recorded=refused-$_gr_rc"
   440	    exit 1
   441	  fi
   442	fi
   443	[ -n "${RT_FILE:-}" ] && echo "telemetry: $RT_FILE"
   444	rt_summary "${#PASSED[@]}" "${#FAILED[@]}" "$(( ${#PASSED[@]} + ${#FAILED[@]} ))" "declared=$_declared" "recorded=yes"
   445	exit 0

exec
/bin/zsh -lc "nl -ba skills/2-daily/merge-cleanup/scripts/merge_cleanup.py | sed -n '540,700p'; rg -n 'push|publish|primary|reconcile|merge|dry-run' skills/2-daily/merge-cleanup/SKILL.md" in /private/var/folders/69/3l_82qtj7fzglnt_jjg07jh40000gn/T/consult-wt-43891-m8ixsws8
 succeeded in 0ms:
   540	                f"{wait_s:g}s; refusing to start the local reconciler while it is in flight"
   541	            )
   542	            return "active_timeout"
   543	        log(f"Hosted wave-reconcile run #{run_id} is {status or 'active'}; waiting")
   544	        time.sleep(min(poll_s, remaining))
   545	
   546	
   547	def run_local_wave_reconcile(pr_num: int, repo_path: Path) -> bool:
   548	    """Run the local writer after hosted reconciliation is known absent or completed red."""
   549	    reconcile_script = tool_path(repo_path, "wave_reconcile.py")
   550	    if not reconcile_script.exists():
   551	        return True
   552	    r_cmd = [sys.executable, str(reconcile_script), "--root", str(repo_path), "--pr", str(pr_num)]
   553	    r_res = subprocess.run(r_cmd, cwd=str(repo_path), capture_output=True, text=True, check=False)
   554	    if r_res.returncode == 0:
   555	        log(f"✅ local wave_reconcile for PR #{pr_num} passed")
   556	        return True
   557	    log_err(
   558	        f"wave_reconcile FAILED for PR #{pr_num} (exit {r_res.returncode}): "
   559	        f"{(r_res.stderr.strip() or r_res.stdout.strip())[-600:]}"
   560	    )
   561	    return False
   562	
   563	
   564	def run_post_merge_reconcile(pr_num: int, repo_path: Path,
   565	                             integration_branch: str = "development",
   566	                             dry_run: bool = True,
   567	                             pr_head: Optional[str] = None,
   568	                             merged_head: Optional[str] = None) -> bool:
   569	    """Wait for hosted reconciliation (or fall back locally), then run governance checks.
   570	
   571	    `merged_head`, when given, is the PR's merge commit as GitHub reports it (--reconcile-pr);
   572	    otherwise the primary's HEAD, which the Phase-5 fast-forward has just moved to the merge."""
   573	    if dry_run:
   574	        log(f"[DRY RUN] Would wait for hosted reconciliation or run wave_reconcile.py --pr {pr_num}")
   575	        return True
   576	
   577	    log(f"Running post-merge reconciliation for PR #{pr_num} in {repo_path}...")
   578	
   579	    # E: "Governed Landing" is enforced, not advisory. Every step here is gating; a failure
   580	    # returns False and the orchestrator stops all downstream mutation.
   581	    ok = True
   582	
   583	    # 1. The merge fast-forward immediately before this call pins the workflow lookup to the
   584	    # exact triggering head. Hosted success is authoritative; only an absent/completed-red run
   585	    # selects the local writer. An active timeout stops instead of racing that writer.
   586	    if not merged_head:
   587	        head = run_git(repo_path, ["rev-parse", "HEAD"])
   588	        if head.returncode != 0 or not head.stdout.strip():
   589	            log_err(f"Cannot identify the merged head before reconciliation: {head.stderr.strip()}")
   590	            return False
   591	        merged_head = head.stdout.strip()
   592	    hosted = wait_for_hosted_reconcile(
   593	        merged_head, repo_path, integration_branch, pr_head=pr_head)
   594	    if hosted == "active_timeout":
   595	        return False
   596	    if hosted == "success":
   597	        fetched = _net_git(repo_path, ["fetch", "origin", integration_branch])
   598	        if fetched.returncode != 0:
   599	            log_err(f"Hosted reconciliation succeeded but fetch of origin/{integration_branch} failed: {fetched.stderr.strip()}")
   600	            return False
   601	        ff = run_git(repo_path, ["merge", "--ff-only", f"origin/{integration_branch}"])
   602	        if ff.returncode != 0:
   603	            log_err(f"Fast-forward onto hosted reconciliation commit failed: {ff.stderr.strip() or 'git refused'}")
   604	            return False
   605	    elif not run_local_wave_reconcile(pr_num, repo_path):
   606	        ok = False
   607	
   608	    # 2. releases_app.py check
   609	    releases_app = tool_path(repo_path, "releases_app.py")
   610	    if releases_app.exists():
   611	        c_res = subprocess.run([sys.executable, str(releases_app), "check"], cwd=str(repo_path), capture_output=True, text=True, check=False)
   612	        if c_res.returncode == 0:
   613	            log("✅ RELEASES DB check passed")
   614	        else:
   615	            log_err(f"RELEASES DB check FAILED (exit {c_res.returncode}): {(c_res.stdout.strip() or c_res.stderr.strip())[-400:]}")
   616	            ok = False
   617	
   618	    # 3. pdda.sh issue-doc-sync
   619	    pdda_sh = repo_path / "utils" / "pdda" / "pdda.sh"
   620	    if pdda_sh.exists():
   621	        p_res = subprocess.run(["bash", str(pdda_sh), "issue-doc-sync"], cwd=str(repo_path), capture_output=True, text=True, check=False)
   622	        if p_res.returncode == 0:
   623	            log("✅ pdda issue-doc-sync clean")
   624	        else:
   625	            log_err(f"pdda issue-doc-sync FAILED (exit {p_res.returncode}): {(p_res.stdout.strip() or p_res.stderr.strip())[-400:]}")
   626	            ok = False
   627	
   628	    return ok
   629	
   630	
   631	def commit_and_push_phase5_writes(pr_num: int, repo_path: Path, integration_branch: str) -> bool:
   632	    """Commit, push, and verify every primary-side write made after a PR lands."""
   633	    status = run_git(repo_path, ["status", "--porcelain", "--untracked-files=all"])
   634	    if status.returncode != 0:
   635	        log_err(f"PR #{pr_num}: cannot inspect post-merge writes: {status.stderr.strip()}")
   636	        return False
   637	
   638	    if status.stdout.strip():
   639	        added = run_git(repo_path, ["add", "-A"])
   640	        if added.returncode != 0:
   641	            log_err(f"PR #{pr_num}: could not stage post-merge writes: {added.stderr.strip()}")
   642	            return False
   643	        committed = run_git(repo_path, ["commit", "-m", f"chore: reconcile after PR #{pr_num}"])
   644	        if committed.returncode != 0:
   645	            log_err(f"PR #{pr_num}: could not commit post-merge writes: {committed.stderr.strip()}")
   646	            return False
   647	
   648	    pushed = _net_git(repo_path, ["push", "origin", f"HEAD:{integration_branch}"], timeout=PUSH_GATE_TIMEOUT_S)
   649	    if pushed.returncode != 0:
   650	        log_err(f"PR #{pr_num}: could not push post-merge writes: {pushed.stderr.strip()}")
   651	        return False
   652	    fetched = _net_git(repo_path, ["fetch", "origin", integration_branch])
   653	    if fetched.returncode != 0:
   654	        log_err(f"PR #{pr_num}: could not verify pushed integration head: {fetched.stderr.strip()}")
   655	        return False
   656	
   657	    clean = run_git(repo_path, ["status", "--porcelain", "--untracked-files=all"])
   658	    local = run_git(repo_path, ["rev-parse", "HEAD"])
   659	    remote = run_git(repo_path, ["rev-parse", f"origin/{integration_branch}"])
   660	    if (clean.returncode != 0 or clean.stdout.strip() or
   661	            local.returncode != 0 or remote.returncode != 0 or
   662	            local.stdout.strip() != remote.stdout.strip()):
   663	        log_err(f"PR #{pr_num}: post-merge durability check failed — primary must be clean and match origin/{integration_branch}")
   664	        return False
   665	    log(f"✅ PR #{pr_num} post-merge writes committed; primary is clean at origin/{integration_branch}")
   666	    return True
   667	
   668	
   669	# Dispositions that are never re-inspected for teardown: the operator's own tree, an explicit
   670	# exclusion, and wiki clones. Everything else — including a scan-time PRESERVE_* — is
   671	# re-inspected fresh in Phase 6, because a PR landing in Phase 5 can turn PRESERVE_UNPUSHED into
   672	# eligible, and anything that changed since the scan can turn eligible into preserved (A.5).
   673	TEARDOWN_EXEMPT = ("PRIMARY_CHECKOUT", "PRESERVED_USER_EXCLUDE", "PRESERVE_WIKI")
   674	
   675	
   676	def refresh_for_teardown(checkouts: List[Dict[str, Any]], primary_repo: Path,
   677	                         excludes: Optional[List[str]] = None,
   678	                         integration_branch: str = "development") -> List[Dict[str, Any]]:
   679	    """Re-run inspect_checkout on EVERY non-exempt checkout; the fresh verdict is the only one
   680	    teardown may act on. The scan-time disposition is kept under `scan_disposition` for display."""
   681	    fresh: List[Dict[str, Any]] = []
   682	    for c in checkouts:
   683	        if c["disposition"] in TEARDOWN_EXEMPT:
   684	            continue
   685	        info = inspect_checkout(Path(c["path"]), primary_repo_path=primary_repo, exclude_patterns=excludes,
   686	                                integration_branch=integration_branch)
   687	        info["scan_disposition"] = c["disposition"]
   688	        if info["disposition"] != c["disposition"]:
   689	            log(f"{info['name']}: {c['disposition']} at scan time -> {info['disposition']} now ({info['disposition_reason']})")
   690	        fresh.append(info)
   691	    return fresh
   692	
   693	
   694	def teardown_checkout(checkout: Dict[str, Any], dry_run: bool = True) -> bool:
   695	    """Safely tears down a worktree or standalone clone in strict compliance with WORKTREE-SAFETY.md.
   696	
   697	    `checkout` must be a FRESH inspection from refresh_for_teardown(); a scan-time record is
   698	    refused so a stale SAFE_REMOVE_* can never be acted on (A.5).
   699	    """
   700	    path = Path(checkout["path"]).resolve()
2:name: merge-cleanup
3:description: Consolidate multiple Git worktrees and clones of a repository into a single clean checkout, safely merge associated PRs in topological dependency order, document landing batches of three or more PRs as a GitHub issue (merge sequence, problems, ad-hoc fixes, regression sweep, post-deployment carry-overs — also echoed in chat), reconcile post-merge governance state (PDDA and RELEASES DB), and safely remove leftover worktrees/clones without data loss or interrupting active sessions. Strictly complies with WORKTREE-SAFETY.md.
6:# /merge-cleanup — Worktree Consolidation, PR Sequencing, and Safe Teardown
8:`merge-cleanup` consolidates multiple active Git worktrees and clones of a repository into a single clean primary checkout, determines optimal topological PR merge sequences, executes GitHub PR merges, triggers post-merge PDDA & RELEASES DB reconciliations (the RELEASES DB is the Product Release System, PRS; [definition](https://github.com/HiQS-Labs/XYZ-forge/blob/development/HOW-TO-USE.md#glossary--the-five-terms-youll-hit-first)), and safely tears down disposable worktrees/clones without data loss or active process disruption.
17:> 1. **Verify primary landing readiness (Phase 0).** Confirm the primary on-disk checkout is clean, on the integration branch (`development`), and ready to fast-forward before any remote action.
20:> 4. **Merge & reconcile governance (Phase 5).** Remote squash-merge in dependency order, fast-forward primary checkout (`git merge --ff-only`), and execute post-merge reconciliation (`wave_reconcile`, `releases_app check`, `pdda.sh`).
22:> 6. **Document qualifying batches (GH-944).** When the sequenced queue holds **three or more PRs**, open a `merge-batch` GitHub issue **before the first merge** and keep it current as the run progresses — merge sequence, problems, ad-hoc fixes/pivots, findings. After the batch, run the `/debug-mantra` regression sweep (findings become issue checklist items) and transcribe each merged PR/issue's **post-deployment carry-over items** into the issue **and** the end-of-run chat summary, verbatim and unchecked.
24:> **Overall Goal:** All ready-to-merge PRs processed, qualifying batches documented and swept for regressions, and local disk clones and git worktree folders safely torn down when appropriate.
33:- `"Run merge-cleanup on this repo"`: Reviews the primary on-disk checkout first (Phase 0), then audits the other checkouts, reports the sequence, and proceeds within the session's authorized PR and cleanup scope. Discovery does not add unrelated PRs to that scope; an explicit audit/dry-run request remains read-only.
35:- `"Sequence and merge open PRs"`: Reports Phase 0 for the primary checkout first — a PR sequence is not actionable until the tree it lands in can receive it — then determines topological order of open PRs, detects file collisions, and executes remote squash merges followed by wave reconciliation.
63:PR lands in, the tree `git merge --ff-only` runs in, and the tree `wave_reconcile.py`,
67:- Inspect the primary **by identity**, not by discovery. It is listed because it is the primary —
68:  never because a `SAFE_ROOTS` walk reached it or its directory name matched `--prefix`. A primary
72:  default `development`), working-tree cleanliness, an unfinished merge/rebase/cherry-pick, local
80:- **Unpushed commits on the integration branch are a blocker, not a note.** A squash-merge landing
84:  It covers zero-PR cleanup, teardown-only cleanup, and `--reconcile-pr`; none may silently defer
85:  the primary checkout to the operator after reporting success.
87:  `--allow-unready-primary` overrides the refusal deliberately and records the blockers.
88:- The verdict is **re-established against the live remote** immediately before the first merge, so
95:- Uncommitted intake docs or captures in the primary are their own commit or a park — they do not
99:python3 skills/2-daily/merge-cleanup/scripts/merge_cleanup.py --primary . --scan-only   # Phase 0 + audit
103:(`scan_clones.py`, `toposort_prs.py`) do **not** perform it — reach for `merge_cleanup.py` when
108:For an executing merge-cleanup request, handle documentation-only unpushed commits before
109:invoking the strict CLI readiness gate. Audit/dry-run requests only report this option.
112:1. Inspect the primary first and refresh `origin/<integration>` successfully. Enumerate the
120:2. Preserve the exact tip under a unique local `temp-merge-cleanup-<date>-<short-sha>` branch
121:   and publish it to the same `origin` under that name. An existing name is reusable only at
127:   `<primary>/.tick/merge-cleanup/<owner>-<repo>/temp-docs.md` (append on resume). Include the
130:   not `git stash`; no PR is opened or merged for it automatically.
137:5. After the merge sequence, revisit every unchecked temp item, including resumed runs.
140:   reviewed PR, or discard for the operator to decide. Never auto-merge, auto-delete branches,
141:   mark disposal complete, or tear down source checkouts merely because the backup is pushed.
145:- Always includes the primary checkout from Phase 0, then locates further candidate repositories under `SAFE_ROOTS` — `~/Documents/GH Repos`, `~/agent-workspaces`, `~/Documents/agent-workspaces`, `~/marathon-clones` (where `/jog`, marathon flows and older `/start-task` runs create task clones; task clones that follow the GH-970 location decision are siblings of the primary, found with `--root "$(dirname <primary>)"`). The list in `scan_clones.py` is the list in `WORKTREE-SAFETY.md` §16.1; a test pins the parity (GH-534 A.1).
164:- **Landed vs unlanded refs, by provenance (A.2):** after a verified `git fetch origin <integration-branch>`, every local ref tip — all `refs/heads/*`, detached `HEAD`, any local-only ref — must be either (1) reachable from `origin/<integration-branch>`, or (2) the exact `headRefOid` of a **MERGED** PR (base = integration branch, `gh pr list --state merged`, remote identity bound to the clone's `origin`) whose merge commit is reachable **and** whose landed content equals the branch's — per-path blob ids and modes from `git diff --raw --full-index`, so whitespace and binaries count. Anything else is `PRESERVE_UNPUSHED` naming the ref, the commit and the reason (no merged PR; content differs from PR #N; lookup unavailable). Squash merges no longer read as "unpushed forever"; a changed conflict resolution or a commit after the PR head still preserves. `git cherry` is never an authorization input.
167:  - **Deep Scan Escalation:** If unlanded commits exist without QA attestation, marks confidence as `MEDIUM` and recommends a deeper scan. The deeper scan is [`/merge-cleanup-deep`](https://github.com/HiQS-Labs/XYZ-forge/blob/development/skills/3-weekly/merge-cleanup-deep/SKILL.md) (GH-728): it consumes this skill's `scan_clones.py --json` audit, zips every preserved checkout to a dated backup, fans out ≤3 read-only sub-agents by branch family, and returns PR-WORTHY / SUPERSEDED / NEEDS-OWNER / ABANDON-CANDIDATE verdicts with the deciding evidence; disposable checkouts come back here for Phase 6 teardown. `/recon` or `/debug-mantra` remain the tools for a single clone's conflict.
175:- Runs only after Phase 0 has reported. The PR sequence is advice until the primary can receive it.
179:- Builds a Directed Acyclic Graph (DAG) and computes topological merge order.
182:- **Refuses every executing cleanup when Phase 0 says the primary is not landing-ready**, unless the operator explicitly passes `--allow-unready-primary` to defer that cleanup. This gate applies before any Phase 5 or Phase 6 mutation, including zero-PR and `--teardown-only` runs; the skill never silently chooses to leave the primary dirty or otherwise unready.
184:- **Every PR is re-fetched before every decision (E).** `gh pr view` is read fresh per PR; a `mergeable` of `UNKNOWN` is polled first — GitHub recomputes mergeability for every open PR after each landing on the base, so the next PR reads `UNKNOWN` for a few seconds — up to 6 × 15s (`MERGEABLE_POLL_ATTEMPTS` / `MERGEABLE_POLL_S`, GH-736), re-reading with the transient-retry wrapper; a read that fails mid-poll ends the poll and follows the same rules as the first read (transient → deferred, anything else → stop naming the error); still undecided after that stops the run, and so does any non-transient `gh` failure (a PR whose state is unknown is never merged). A TRANSIENT network failure (DNS, refused/timed-out connection, TLS, rate limit) is retried three times first (2s, 4s between calls, GH-623); one that survives the retries DEFERS that PR — named in the end-of-run summary — and the queue continues. A hold label (`hold`, `do not merge`, `blocked`, `wip`) skips the PR (#444). A PR whose base is not the checked integration branch stops the run.
185:- **Pre-merge ledger gate (E.6):** the landing is simulated in a disposable full clone — PR head, then `git merge --no-ff --no-commit origin/<integration-branch>` against the integration head fetched *now* (the three-way merge keeps `MERGE_HEAD`, which the ledger resolver's generation floor reads). On a clean merge: a three-way ledger classification (a clean textual merge can still be a semantic conflict), then `releases_app.py check` and `roadmap reconcile-state --dry-run`. Any non-zero exit or `FAIL:` line is **red** and the PR is not merged; `warn:` lines, per-row identity skips and `would move` lines are diagnostics, not red.
186:- **Ledger and additive changelog conflicts, disjoint changes only (B1):** a conflicted landing whose unmerged set (from `git diff --diff-filter=U` + `git ls-files -u`, required non-empty with a zero-exit extraction) is within `{releases.db, releases.sql, LEADERBOARD.md, RELEASES-PREVIEW.html, LEADERBOARD.html, CHANGELOG.md}` is classified three-way against the merge base, per table, per key. Only when the two sides' changes are mechanically disjoint — no same-key change on both sides, no reference to a row the other side deleted, no duplicate `gh_number`, nothing outside `roadmap_items` on the replayed side — is it resolved: the side with the higher generation is kept, the other side's roadmap changes are replayed **through the writer** (`roadmap add` / `update` / `rate` / `repoint`; receipts are regenerated, gids are re-minted), then `utils/releases-merge-resolve.sh` rebuilds the DB and views, `releases check` must be clean, `git ls-files -u` must be empty, the merge commit is validated in a **second** disposable clone, and it is pushed to the PR branch only if the remote head is still the SHA that was resolved. Then the PR is re-fetched and re-gated. `harnesses.*` conflicts, code conflicts, same-key edits, deletes, inexpressible tables, a resolver refusal (generation rewind), an extraction error → **handoff** (exit 3) naming the keys; the landing clone is kept for inspection. Never an SQL union.
187:- **Additive changelog boundary (GH-789):** B1 accepts complete dated sections prepended to unchanged preamble/history, proven against one merge base. Distinct same-date headings survive; exact identical new blocks deduplicate. Edited/deleted history, divergent same-heading additions, malformed sections, fenced/HTML additions and conflict markers hand off before writes. The repository still needs its existing RELEASES ledger and gates.
188:- **Drafts (GH-789):** live `isDraft` is checked before repair, after polling/repair refreshes, before a repaired-head push and immediately before merge. Drafts are skipped; hard dependents wait, independent PRs continue. Soft collision preferences cannot create dependency cycles; unresolved hard prerequisites block even under numerical fallback.
189:- **Orphan rebase marker (GH-789):** inspection stays read-only. Execute landing/reconcile may compare-and-delete a valid stale REBASE_HEAD only when all other readiness checks pass and no active rebase/sequencer/other operation exists, then re-inspects. Dry-run, scan-only, prs-only and teardown-only never prune.
190:- **One durable attempt record per PR, at the pinned coordinator (C):** before B1 runs, the script reserves a repair slot in `<primary>/.tick/merge-cleanup/<owner>-<repo>/pr-<N>.json` — `<primary>` is the explicit `--primary` path the run started with, never a disposable clone's CWD. Every writer (this script, and each caller repair rung via `attempt_record.py`) holds `fcntl.flock` on `<record>.lock` for the whole read → reserve → write; that lock is independent of the driver's mkdir lock, so a worker under a running driver still reserves. A lock timeout **stops** the attempt (never "skipped"). Only repairs count (`B1`, `ponytail`, `start-task`); `debug-mantra`/`recon` are notes. **Two repairs per PR, whatever the head**: at the ceiling the PR is **parked** with the record path, and B1 does not run. Any handoff or park prints `export MERGE_CLEANUP_RECORD=<record>` for the caller ladder below.
191:- **Only HARD dependencies block on a failed predecessor (C + GH-623):** Phase 4 orders; Phase 5 keeps a runtime map of predecessor outcomes and skips a PR whose declared dependency (`depends on #N`) was handed off, parked or deferred, naming it. File-collision edges are SOFT: a collision-adjacent PR is attempted anyway and its own landing simulation decides — a genuinely conflicting successor hands off on its own merits instead of never being tried (the incident's S3 cascade: one handoff removed most of the queue). Independent PRs still land. A run with any non-landed outcome (handoff / park / defer) exits 3 after the sequence; a stop (unknown state, gate red, merge/reconcile failure, unreadable record) exits 2 immediately.
192:- **`--resume` continues a previous run (GH-623):** the live refresh stays first and authoritative. Only when a PR's landing actually conflicts — a repair would be needed — does the attempt record decide: at the ceiling with `--resume`, the PR is skipped as `previously parked` without re-running the B1 machinery (and without consuming a slot). A PR whose last recorded repair finished `resolved` and whose head now merges cleanly LANDS — a resume run completes a successful repair's work, never strands it. Without `--resume`, `reserve()` is the under-lock authority and the behavior is unchanged. Resume mode announces itself (`Resume mode: ...`) and the end-of-run summary breaks out parked-on-resume counts.
193:- Executes remote merges in topological sequence (`gh pr merge <PR_NUM> --squash --delete-branch`) — and a zero exit is not a landing: the PR is re-queried until it reads `MERGED` with a merge commit (#510 class), else the run fails. A non-zero or killed `gh pr merge` is re-queried once too, and a PR that reads `MERGED` with a merge commit continues to the post-merge sequence (GH-852). After a B1 push, the re-gate first waits (up to 6 × 15s) until GitHub reports the pushed head, because the old head's `CONFLICTING` is still showing (GH-851). `--reconcile-pr` refuses (exit 2) unless the PR reads `MERGED`, and looks up the hosted run by that PR's head and merge commit (GH-852).
194:- After each verified remote merge, performs one ordered durability sequence before looking at the next PR: **fast-forward primary → reconcile → emit `pr_merged` → commit all resulting primary-side ledger/governance writes → push `origin/<integration-branch>` → assert the primary is clean and `HEAD == origin/<integration-branch>`**. The emitter therefore runs only after both the landing fast-forward and any fast-forward performed by reconciliation; a failure at any step stops the run.
195:- Executes post-merge reconciliation, **gating** (a failure stops the run before emission, commit, push, the next PR, teardown, and symlink pruning; `--reconcile-pr` propagates the same exit):
196:  - Query the hosted `wave-reconcile.yml` runs (`gh run list --workflow wave-reconcile.yml`) and match the PR head or the merge commit. If the run is queued or in progress, poll until completion for at most `MERGE_CLEANUP_HOSTED_WAIT_S` seconds (default 5400, #854 D5: full-registry reconciles take 53–66 min); timing out while it remains active stops the landing rather than racing it locally.
197:  - On hosted success, fetch and fast-forward the primary onto `origin/<integration>`'s reconciliation commit.
198:  - An empty answer inside the first `MERGE_CLEANUP_HOSTED_GRACE_S` seconds (default 60) is "not listed yet", not "no workflow" — the run for a just-pushed head can lag `gh run list` by a few seconds, and reconciling locally in that gap would race the hosted writer. After the grace window, if no hosted run/workflow/`gh` exists, or the hosted run completed unsuccessfully, fall back to `python3 utils/py/wave_reconcile.py --pr <PR_NUM>`. Never invoke that local writer while the observed hosted run is queued or in progress (`--force-local-reconcile` remains a manual recovery tool only).
213:`/merge-cleanup` is a driven workflow, not a one-shot report. Follow the loop; do not stop at the
218:   `python3 skills/2-daily/merge-cleanup/scripts/merge_cleanup.py --primary "$PRIMARY" --prefix <name>`
219:2. **Fix the primary** so Phase 0 reports landing-ready (commit or park the dirty intake files per
220:   the Phase 0 rules). A dirty primary is a blocker to FIX, not a reason to silently switch to
236:A merge-cleanup run fails the operator as surely by stopping to ask about a reversible step as by
239:- **What the request already authorizes.** "Run merge-cleanup", "merge the open PRs", "land these",
241:  primary, `--execute`, the batch issue, caller repair rungs within the two-repair budget,
242:  `--resume --execute` re-runs, reconciliation commits and pushes to the integration branch, and
243:  Phase 6 teardown of `SAFE_REMOVE_*` checkouts to Trash. An explicit audit, scan, or dry-run
248:  merges are squash commits on a remote branch, ledger writes are reconciled and pushed, teardown
252:  queue; `--allow-unready-primary` or any other override flag; a `PRESERVE_*` checkout the operator
254:  a Costly or One-way-door action under `AGENTS.md` (force push, deleting a branch or clone that
257:  the PRs that do not depend on the blocked one, reconcile them, tear down what is safe — and then
259:- **Evidence before Done.** "Landed" means the PR reads `MERGED` with a merge commit and the primary
261:  acted on it. A dry-run table, a planned sequence, or an attempted command is not a landing.
262:- **Continuation never widens authorization.** It grants no override flags, no force pushes, no
291:- **Created before the first merge, kept current.** The issue is opened after sequencing and
292:  before the first `gh pr merge` of the batch, so problems and pivots are appended as they happen
295:  `merge-batch` for this integration branch whose PR list overlaps the run's queue; that
300:- **Label bootstrap.** Run `gh label create merge-batch --force` before the first create, so the
304:- **Named data sources — mine, do not freelance.** The merge sequence and per-PR outcomes come
306:  (`<primary>/.tick/merge-cleanup/<owner>-<repo>/pr-<N>.json`) and B1 ledger-resolution lines;
307:  findings from the reconciliation gates (`wave-reconcile`, `releases_app check`,
309:- **Regression sweep (after the batch).** Apply `/debug-mantra` over the merged range (first
310:  through last merge commit of the batch on the integration branch): cross-reference the merged
314:  the primary (GH-564). Every regression or bug found becomes a `- [ ]` checklist item in the
317:- **Post-deployment carry-overs (dual sink).** Scan each merged PR body and its closing-linked
320:  them at the end of the run's chat summary**, after the merge sequence, so the operator sees
321:  them in-band rather than only on GitHub. Transcribe only: merge-cleanup never executes
323:- **Lifecycle.** The issue stays open; the operator works the checklists. merge-cleanup never
330:Labels: merge-batch
334:| # | PR | outcome | reconcile |
375:| landing-refetch-and-gate | 5 | script | TestE6Gate.test_gate_red_prevents_the_merge |
378:| coordinator-pinned-to-primary | 5 | script | TestCScript.test_omitted_primary_is_refused_and_no_record_root_is_minted |
388:| mergeable-unknown-poll | 5 | script | TestPhase5EndToEnd.test_unknown_mergeable_settles_and_the_pr_lands |
395:CLI options this document describes and the guard asserts exist: `--primary`, `--root`, `--prefix`, `--exclude`, `--strategy`, `--scan-only`, `--prs-only`, `--teardown-only`, `--reconcile-pr`, `--integration-branch`, `--allow-unready-primary`, `--execute`, `--backup-first`, `--resume`.
403:python3 skills/2-daily/merge-cleanup/scripts/merge_cleanup.py --primary "$HOME/Documents/GH Repos/XYZ-forge" --prefix XYZ-forge
406:python3 skills/2-daily/merge-cleanup/scripts/scan_clones.py --prefix XYZ-forge
409:python3 skills/2-daily/merge-cleanup/scripts/toposort_prs.py
412:python3 skills/2-daily/merge-cleanup/scripts/merge_cleanup.py --primary "$HOME/Documents/GH Repos/XYZ-forge" --prefix XYZ-forge --execute
415:python3 skills/2-daily/merge-cleanup/scripts/merge_cleanup.py --primary "$HOME/Documents/GH Repos/XYZ-forge" --prefix XYZ-forge --teardown-only --backup-first --execute
418:python3 skills/2-daily/merge-cleanup/scripts/merge_cleanup.py --primary "$HOME/Documents/GH Repos/XYZ-forge" --prefix XYZ-forge --exclude 427 --execute
421:export MERGE_CLEANUP_RECORD=/abs/primary/.tick/merge-cleanup/HiQS-Labs-XYZ-forge/pr-538.json
422:python3 skills/2-daily/merge-cleanup/scripts/attempt_record.py note --kind diagnosis --text "same-key update on gh_number 100"
423:python3 skills/2-daily/merge-cleanup/scripts/attempt_record.py reserve --rung ponytail --head <sha> --clone "$PWD"   # exit 3 → /unstuck
424:python3 skills/2-daily/merge-cleanup/scripts/attempt_record.py finish --index 0 --outcome resolved
427:python3 skills/2-daily/merge-cleanup/scripts/merge_cleanup.py --primary "$HOME/Documents/GH Repos/XYZ-forge" --prefix XYZ-forge --resume --execute
434:1. **Zero Data Loss:** Any dirty working tree, unpopped stash, or unlanded commit automatically stops deletion and marks the checkout `PRESERVE_*`, naming the files or refs. The primary checkout is inspected first and by identity, so it can never be skipped by a scan filter. Anything the scanner cannot prove is preserved, naming the failed query.
435:2. **No Silent Primary Deferral:** every executing run refuses before merge, teardown, or symlink mutation while the primary is unready; only the operator can defer primary cleanup with `--allow-unready-primary`.
438:5. **Governed Landing:** Every PR is gated on the ledger against the current integration head before it merges, verified `MERGED` after, then fast-forwarded, reconciled, emitted, committed, pushed, and verified clean/equal to the remote integration head before the next PR is looked at; any failure stops the run.

exec
/bin/zsh -lc "rg -n 'promotion|main|stable|fix.forward|revert|primary|disposable|qualif|QA|gate|Opinionated|Step 3' SOP.md AGENTS.md GUIDING-PRINCIPLES.md" in /private/var/folders/69/3l_82qtj7fzglnt_jjg07jh40000gn/T/consult-wt-43891-m8ixsws8
 succeeded in 0ms:
GUIDING-PRINCIPLES.md:37:capture → rate → plan → preflight → execute → gate → land → record. Its `tick` kernel coordinates
GUIDING-PRINCIPLES.md:41:coordination, recoverability and verifiable outcomes. The operator remains the decision authority.
GUIDING-PRINCIPLES.md:75:8. **Honest; the operator decides.** Surface what failed and why — never mask a stall as success or an escalation as a stall. A headless turn self-repairs within a bounded exit-code menu (`exit 3` stall, `exit 4` escalated-by-design, `exit 6` containment revert), then stops; it never loops forever or silently swallows an error. Destructive actions require explicit authorization.
GUIDING-PRINCIPLES.md:83:12. **Independent Verification (Separated Grading)** — The agent that produces a turn must not be the sole grader of its own quality. Verification must be performed by an independent deterministic check or a separate reviewing agent before the lock releases. Applies to: the relay's structural block validator (`bin/validate-relay-block` — Phase 1 of GH-21), consult-verify diversity (Phase 3), and any other post-generation quality gate.
GUIDING-PRINCIPLES.md:85:13. **A green gate without a witnessed red control is not evidence.** Every new or materially changed decision gate needs a recorded demonstration that it fails for the right reason: a pre-fix replay, deliberate mutation, or controlled bad input. Witness it on an existing suite, or record it as a manual check under `TESTS-RESULTS/`. Never add a new test suite to do it (GH-831: no new tests). Do not mistake a check that validates the artifact it just generated (#351) or a parity check that compares a lane to itself (#348) for evidence; both shapes are structurally unable to falsify their claim.
GUIDING-PRINCIPLES.md:98:bodies are compatibility fallbacks selected with `XYZ_PYTHON=0`; their strict-mode choices remain
GUIDING-PRINCIPLES.md:128:warning, deliberately **not** a gate — a false positive that blocks a relay is worse than the papercut it
GUIDING-PRINCIPLES.md:137:  another supported builder. Choosing Claude remains an explicit, cost-acknowledged operator
GUIDING-PRINCIPLES.md:160:4. **Done verifiable?** Names runnable gates (`validate.sh`, specific tests, `utils/pdda/pdda.sh run`). None = low-quality signal.
SOP.md:5:> - **`AGENTS.md`** owns repo-wide behavioral governance, core principles (*Verified Beats Plausible*, blast radius sizing, reversibility scale), marathon load rails, role splits, and push boundary gates.
SOP.md:7:> - **Overlap (~25%)**: This SOP references and enforces `AGENTS.md` invariants (standalone clone isolation GH-564, githooks/pre-push gates, and committed `.jsonl` telemetry GH-430) within its step-by-step campaign workflow rather than redefining general repository policy.
SOP.md:8:> - **Exception to this file's scope**: §4 "Opinionated SOPs" is a general **maintainer-workflow
SOP.md:10:>   maintainer development work, not just testing campaigns, and is optional for downstream users.
SOP.md:22:- **Full Clone Isolation (GH-564):** Never run destructive suites, resets, or multi-hour variation runs in the primary working tree or a linked worktree. Always provision a standalone clone (e.g. `../XYZ-forge-<topic>`).
SOP.md:37:[3. Local Gate Preflight (non-qualifying)] ──> (./validate.sh)
SOP.md:71:The promotion procedure is four DB/file steps on the RELEASES DB:
SOP.md:75:   (`pdda-check-frontmatter` hard-fails without it — this is what actually turned the push gate
SOP.md:76:   red, not any missing ROADMAP pointer), the exact two-column `## Status` table, and QA gates
SOP.md:92:> **This is a disposable CAMPAIGN clone** (destructive-suite isolation, GH-564) — cloning from
SOP.md:95:> `origin/development` per §4 "Opinionated SOPs", so its `origin` points at GitHub.
SOP.md:97:### Step 3: Local Gate Preflight (non-qualifying)
SOP.md:104:qualifying run that writes the evidence record is `bash ci-local.sh` (see `AGENTS.md`), which
SOP.md:105:remains outstanding until run.
SOP.md:114:Provision a disposable scratch repository outside the codebase:
SOP.md:149:4. Verify pre-push gates (`test/gh308-frozen-twin-guard.sh --check --staged`).
SOP.md:176:`gh139-pipe-grep-guard.sh` locally **before** pushing new guard-adjacent shell. The full gate takes
SOP.md:194:## 4. Opinionated SOPs (XYZ-maintainer defaults — optional downstream)
SOP.md:196:> **Who these are for:** These conventions exist to help the **XYZ maintainers** with our own
SOP.md:199:> maintainers to ignore them, or write a script that strips this section on pull from upstream.
SOP.md:202:- **CI churn recovery.** When CI churn is suspected, follow [`docs/CI-CHURN-RECOVERY-SOP.md`](docs/CI-CHURN-RECOVERY-SOP.md) (#857). It covers the entry gate for declaring an episode, the phased strategy checklist, and the exit gates for closing it. It grants no standing exception to `AGENTS.md`.
SOP.md:203:- **The primary clone stays on `development`.** Each device has exactly one
SOP.md:204:  **operator-designated primary clone** — the long-lived checkout the operator opens by default
SOP.md:206:  applies **only** to the primary clone by role; task clones provisioned under the next rule are
SOP.md:207:  exempt (they live on their own task branch and are disposable).
SOP.md:212:  the GitHub remote so `origin` points at GitHub, wired with the gate, and branched off
SOP.md:216:  # Name = <repo-name>-gh<issue>-<very-short-desc>-<yyyy-mm-dd>, a sibling of the primary clone (GH-970)
SOP.md:220:  bash githooks/install.sh                       # per-clone; the gate does not travel (GH-549)
SOP.md:224:  The full naming rule (multi-issue groups, `-gate`/`-verify` helper clones, resume before
SOP.md:231:  path above remains user-request-only).
SOP.md:249:   gate + merge + reconcile cycles for what is really one unit of review. GH-291 shipped
SOP.md:251:3. **Reconciliation ownership and batching.** Hosted `wave-reconcile.yml` is the primary landing
SOP.md:261:5. **Delegate in this shape when lanes are independent:** each lane gets its own fresh
SOP.md:263:   (the push gate is the boundary); it never merges its own PR. A single
SOP.md:265:   diff size vs logical scope, gate evidence on the final SHA), merges pinned to the
SOP.md:266:   reviewed head — and **independently verifies any claim the gate cannot prove** (the
SOP.md:267:   gate-invisible example: a suite exempted from the registry as "pre-existing red").
SOP.md:306:**Deploy ("upload"):** commit and push to `development` (or `main`). The workflow
SOP.md:312:cancels superseded runs, so only one deploy lands at a time. The normal pre-push gate
AGENTS.md:16:  run mutation-heavy gates only in a separate disposable full clone.
AGENTS.md:22:> the intended harness workflow. XYZ Forge cannot guarantee model behavior or data integrity; maintain
AGENTS.md:61:live in `SOP.md` → "Opinionated SOPs" — optional for downstream users, binding for us. That section
AGENTS.md:144:  - Do not add new gate machinery: guards, lanes, runners or telemetry stages.
AGENTS.md:152:  The gate is being cut to Small/Medium/Large tiers under [#831](https://github.com/HiQS-Labs/XYZ-forge/issues/831).
AGENTS.md:189:- **The local gate runs at the push boundary; hosted CI independently attests public-repo changes
AGENTS.md:191:  2026-08-15. `.github/workflows/ci.yml` now covers `push`/`pull_request` on `main` and `development`;
AGENTS.md:192:  the macOS promotion boundary remains restricted to a push on `main`, while the Ubuntu job is an
AGENTS.md:193:  advisory portability canary. Local commits are ungated on purpose; pushes are still gated by
AGENTS.md:199:    still per clone and does not travel** — a fresh clone or second machine has NO gate until this
AGENTS.md:203:    sequential fallback with its reason. `bash ci-local.sh` is still the qualifying run that writes
AGENTS.md:205:  - **Three tiers qualify a landing (GH-831).** After a merge, the hosted reconcile qualifies each
AGENTS.md:206:    landing with one run chosen by its tier, and promotion always runs the full registry. The tiers,
AGENTS.md:212:    the skipped-gate disclosure echoed into the PR description, and merge readiness still
AGENTS.md:213:    outstanding — a bypassed push never authorises merge, promotion, or teardown.
AGENTS.md:244:- `validate.sh` is the code/runtime gate. `utils/pdda/pdda.sh run` and its targeted
AGENTS.md:245:  `utils/pdda/pdda.sh <check>` subcommands are the doc-hygiene gates.
AGENTS.md:275:  pre-advance gate in `marathon-drive.sh` under `XYZ_PYTHON=0`. Such a commit must carry a trailer
AGENTS.md:279:  Frozen-twin-exception: relay-automation/marathon-drive.sh — silently-fake pre-advance gate (GH-319)
AGENTS.md:292:  twin**. `relay-turn-lib.sh` remains a shared Bash runtime dependency rather than a twin, and is the
AGENTS.md:321:  1. **Base Branch Sanity:** The PR targets the active WIP branch (`development`), not `main`.
AGENTS.md:323:  3. **Verification Status:** A test gate ran against the final committed state (either CI or a local `validate.sh` run).
AGENTS.md:326:  **Orchestrator vs. Review Protocol Separation (GH-784):** The Orchestrator (the dispatch/tool driver) cannot self-satisfy the review contract or attest review solely by observing passing test suites. It must mechanically invoke an independent peer/Codex QA turn (`relay-xyz` / `/start-task` Step 8 parity) with recorded receipts under `relay-system/<YYYY-MM-DD>/<label>.codex.md` before approving or signing off on PR creation or promotion. Self-review or test-only observation does not satisfy the Wave QA receipt gate.
AGENTS.md:335:  `isolation: "worktree"` so a runaway destructive command shreds a disposable checkout, not the main
AGENTS.md:352:  git config, remotes, and refs of the repository they are invoked from. On 2026-08-15 the primary
AGENTS.md:355:  ~35 fixture commits. It also **defeated the push gate while corrupting it** — pushes failed with
AGENTS.md:359:    linked worktrees cut off the primary clone, chosen specifically to isolate the risk. **Linked
AGENTS.md:375:  - **Until #564's suite-wide invariant gate lands**, treat any clone you ran the suite in as
AGENTS.md:379:    a null check) is the pattern to copy; `test/gh544-pre-push-gate.sh` has it, 31 other suites do
AGENTS.md:394:    intact means it is your diff or ordinary flakiness: investigate normally. This is a trigger, not a
AGENTS.md:409:    ledger, timestamp-correlated to each gate run), inspect it directly before building a
AGENTS.md:412:- **The local macOS run is the gate; hosted ubuntu is advisory (GH-509).** XYZ is a developer toolkit
AGENTS.md:419:  advisory and tests the wrong OS; and **a green local run is self-reported**, so it does not qualify a
AGENTS.md:420:  promotion. Two hosted **macOS** rules follow (GH-831): a landing on `development` is qualified by the
AGENTS.md:421:  reconcile run its tier selects (the tiers are in `ROUTER.md`), and promotion needs a hosted
AGENTS.md:431:- **`development` is the standing WIP branch — ALL work targets it, including marathon/relay-fired lanes (cut fresh from `main` 2026-07-17, [GH-216](https://github.com/Claude-AI-Tools-Ventura-County/xyz-3-agents-swarm/issues/216); policy widened 2026-07-17 to cover marathon lanes too, first applied to [PR #217](https://github.com/Claude-AI-Tools-Ventura-County/xyz-3-agents-swarm/pull/217)).** The prior `development` had drifted 295 commits behind `main` with no open PRs — retired to `development-archived-2026-07-04` rather than deleted outright. Both manual/exploratory work AND marathon-fired lanes (`marathon/gh-<n>-*` branches, GH-212 convention) now branch off `development` and PR back into it — `--plan`/`marathon.sh` still cuts its own short-lived per-lane branch, just off `development` instead of `main`. Periodically merge `development` → `main` once it's in a shippable state; don't let `main` sit behind `development` indefinitely. Watch for `development` drifting stale again the same way the old one did; re-cut from `main` if it does.

exec
/bin/zsh -lc "nl -ba .github/workflows/ci.yml | sed -n '1,45p;140,240p'; nl -ba ci-local.sh | sed -n '290,440p'; rg -n 'promotion|main|stable|fix.forward|revert|Opinionated|independent|disposable|qualif|PR.*review' SOP.md" in /private/var/folders/69/3l_82qtj7fzglnt_jjg07jh40000gn/T/consult-wt-43891-m8ixsws8
 succeeded in 0ms:
     1	name: CI
     2	
     3	# ── READ THIS BEFORE CONCLUDING "CI IS GREEN" (GH-123, 2026-08-21) ──────────────────────────────
     4	#
     5	# Two things about this file have now been re-litigated more than once. Both are recorded here so
     6	# the next person does not rediscover them from scratch.
     7	#
     8	# 1. THE AUTOMATIC TRIGGERS WERE DEAD FROM 2026-08-17 TO 2026-08-21 (GH-59). This is HISTORY, not a
     9	#    live warning — they work now — but it is written down because it silently voided four days of
    10	#    merges and will be misread later if it isn't.
    11	#
    12	#    From the 2026-08-17 re-arm until 17:09 UTC on 2026-08-21, the ENTIRE run history of this
    13	#    repository was `workflow_dispatch` runs. PRs #116, #121 and #122 all merged with ZERO checks.
    14	#    Then, with no change to this file's triggers, both automatic events began firing normally:
    15	#    run 32506672733 (`pull_request`, branch `docs/gh123-ci-canary-codify`) and run 32506697196
    16	#    (`push`, `development`), minutes apart.
    17	#
    18	#    WHY IT STARTED WORKING IS NOT ESTABLISHED. The only honest statement available from a normal
    19	#    token is that it changed between 16:45 and 17:09 UTC on 2026-08-21. If a repository setting was
    20	#    flipped in that window, say so on #59 — the answer is cheap to record now and expensive to
    21	#    reconstruct later. The audit log needs `admin:org`.
    22	#
    23	#    Ruled out during the outage, with evidence, so nobody re-tests them: billing/spending limit (a
    24	#    dispatch on the same branch ran fine — this was the leading theory and it was wrong), workflow
    25	#    disabled (`state=active`), repo is a fork (it is not), Actions disabled (`enabled: true,
    26	#    allowed_actions: all`), the base-branch filter (#116 targeted `development`, which is listed),
    27	#    the workflow missing from the PR head (`d09bdb6` is an ancestor of every branch tested), and
    28	#    fork-PR approval (zero runs ever sat in `action_required`, so nothing was being created).
    29	#
    30	#    A CONFLICTING PR STILL GETS NO RUN, AND THAT IS NORMAL GITHUB BEHAVIOUR — NOT A RELAPSE.
    31	#    `pull_request` workflows are built against the merge ref (`refs/pull/N/merge`), which GitHub
    32	#    does not create while a PR has conflicts, so a conflicted PR shows ZERO checks — visually
    33	#    identical to the outage above. Measured directly on #126: no run for the 9 minutes it was
    34	#    CONFLICTING, then a `pull_request` run within seconds of a rebase clearing it. It is also why
    35	#    #116 got no checks. Before concluding the triggers have broken again, check
    36	#    `gh pr view <n> --json mergeable` — if it says CONFLICTING, rebase and the run appears.
    37	#
    38	#    THE READING RULE THAT OUTLIVES ALL OF THIS: a clean `mergeStateStatus` means "no *failing
    39	#    required* checks", which is also what it says when no checks exist at all. Confirm a run
    40	#    actually exists before treating a green PR page as evidence — `gh pr view <n> --json
    41	#    statusCheckRollup` names the jobs, and an empty array is the tell. To fire this workflow by
    42	#    hand at any time:
    43	#
    44	#        gh workflow run ci.yml --ref <branch>
    45	#        gh run watch <run-id>
   140	  # HONEST LIMIT ON "EXACT COMMIT" (retained; applies to any re-enabled dispatch): `workflow_dispatch`
   141	  # targets a REF, not an arbitrary SHA — GitHub resolves the ref's current HEAD. So this job cannot
   142	  # be pointed at an old commit; it qualifies whatever that ref points to when dispatched. The resolved
   143	  # SHA is printed into the job summary for exactly this reason: the promotion rule compares against a
   144	  # recorded SHA, not against "the run I remember starting".
   145	  #
   146	  # NO SKIP LIST, deliberately. It invokes the authoritative validator directly rather than scraping
   147	  # `TESTS` out of it — the scrape can only see `.sh` entries, which is how the 20-test Python layer
   148	  # (the AUTHORITATIVE implementation since GH-264) went unexercised in CI for months. A second list
   149	  # is a second thing to keep honest; there is no second list here.
   150	  boundary-macos:
   151	    name: promotion boundary (macOS — the platform we ship to)
   152	    if: github.event_name == 'push' && github.ref == 'refs/heads/main'
   153	    runs-on: macos-latest
   154	    # A bound, not an estimate: an unbounded hang is the expensive failure mode, so cap it rather than
   155	    # discover the cost afterwards. The cap tracks MEASURED hosted runtime, not the August "~13-15 min
   156	    # locally" (GH-823): wave-reconcile.yml runs this same `validate.sh --sequential` on this same runner
   157	    # in 60-92 min per job (2026-09-21..25) for every non-docs landing (GH-831: docs, ledger and skill
   158	    # landings run the Small list there instead), so the old 45-min cap would fail every promotion. Keep it >=
   159	    # that workflow's cap; test/ci-workflow.sh fails if it drops below.
   160	    timeout-minutes: 120
   161	    steps:
   162	      - name: Check out repo
   163	        uses: actions/checkout@v7
   164	        with:
   165	          # Same reason as the canary job: fixtures synthesize an "older" ancestor with
   166	          # `git rev-list --max-parents=0 HEAD`, which a shallow clone silently defeats.
   167	          fetch-depth: 0
   168	
   169	      - name: Prepare git environment for fixture-driven tests
   170	        run: |
   171	          set -euo pipefail
   172	          git config --global init.defaultBranch main
   173	          git config --global user.email "ci@runner.invalid"
   174	          git config --global user.name "CI Runner"
   175	
   176	      - name: Install npm dependencies
   177	        run: npm ci
   178	
   179	      # The hosted runner's Python has no pytest, and validate.sh's python lane needs it — the
   180	      # first boundary dispatch (run 31661285957) failed exactly here. Ironic and instructive:
   181	      # GH-509's own headline defect was "the hosted route never ran the 20 python tests"; the
   182	      # first time they ran on hosted macOS, the environment couldn't run them.
   183	      - name: Install Python dependencies for the full suite
   184	        run: python3 -m pip install --quiet --break-system-packages pytest requests PyYAML
   185	
   186	      - name: Verify automatic wave reconciliation (GH-421)
   187	        run: bash test/gh421-auto-wave-reconcile.sh
   188	
   189	      - name: Run the authoritative validator (no skips)
   190	        env:
   191	          # The one documented exclusion, and it is not a coverage skip: this test makes a real
   192	          # billed API call to a live agent. It self-skips off-PATH anyway; the env var makes the
   193	          # intent explicit rather than incidental.
   194	          RELAY_SELF_SUFFICIENCY_SKIP: "1"
   195	        # `--sequential` is PINNED here and must stay pinned. GH-544 made parallel the default for the
   196	        # local gate, which is correct there — but this job is the promotion boundary, and the whole
   197	        # point of it is that its green means something the local run's cannot. Promotion evidence
   198	        # stays sequential (GH-528 Phase 2 has not been met), so the flag is explicit rather than
   199	        # inherited: a future change to validate.sh's default must not be able to silently change what
   200	        # this job attests. test/ci-workflow.sh asserts the flag is present. It runs the FULL registry
   201	        # whatever the classifier would say about the promotion range: the three-tier routing (GH-831)
   202	        # stops at the hosted reconcile, and this is the last full check before a release (O8).
   203	        run: ./validate.sh --sequential
   204	
   205	      - name: Promotion evidence
   206	        if: always()
   207	        run: |
   208	          set -euo pipefail
   209	          if [ "${{ job.status }}" = "success" ]; then
   210	            line="MACOS-BOUNDARY: green ${GITHUB_SHA}"
   211	            note="This commit is promotion-qualified (GH-509 §6). Cite this SHA, not this run."
   212	          else
   213	            line="MACOS-BOUNDARY: red ${GITHUB_SHA}"
   214	            note="NOT promotable. Unlike the ubuntu canary, this ran on the platform we ship to — a failure here is a real defect for real users."
   215	          fi
   216	          echo "$line"
   217	          echo "$note"
   218	          { echo "### $line"; echo; echo "$note"; } >> "$GITHUB_STEP_SUMMARY"
   219	
   220	  # GH-509 Phase 2 — this job is a PORTABILITY CANARY, not a gate.
   221	  #
   222	  # XYZ ships to macOS developers. Linux and Windows are on the roadmap and are not here yet, so a
   223	  # failure on ubuntu is portability DRIFT, not breakage: it says "this would not work on the platform
   224	  # we do not support yet." Every one of the three CI failures on 2026-08-12 was of exactly that shape
   225	  # (agent CLIs absent from the runner), and treating them as breakage is what produced five hours of
   226	  # unread red across eight commits — which is worse than no signal at all, because it trains everyone
   227	  # to ignore the one channel that might have said something real.
   228	  #
   229	  # `continue-on-error: true` at JOB level lets the workflow run pass while this job's own conclusion
   230	  # still records `failure`, so drift stays queryable through the jobs API without marking the commit
   231	  # broken.
   232	  #
   233	  # HONEST LIMIT, stated because this file is exactly the kind of place GH-419 gets violated: the
   234	  # workflow-contract test can assert this key is PRESENT. It cannot assert GitHub's runtime semantics.
   235	  # The acceptance criterion in PROJECT/2-WORKING/GH-509-CI-MINUTE-BURN.md is therefore a witnessed
   236	  # hosted run, not a green grep.
   237	  #
   238	  # Advisory does NOT mean ignorable, and making it non-blocking supplies no reason for anyone to read
   239	  # it — that critique came from the agy review and it is correct. The mechanism that makes it read is
   240	  # elsewhere: the canary's status is a line in the promotion output, consulted at the moment a human
   290	    echo "=== $t ===" | tee -a "$GATE_SUITE_LOG"
   291	    _s="$(rt_now_ms)"
   292	    # Two tees: the first APPENDS the shared transcript, the second writes the per-suite capture
   293	    # (truncated fresh). BSD tee does NOT permute options — the earlier single
   294	    # `tee "$_one" -a "$GATE_SUITE_LOG"` treated -a as a FILENAME (empirically confirmed:
   295	    # `printf hi | tee ./one -a ./two` leaves a file named '-a' in CWD), creating that stray file
   296	    # in the repo root on every suite. The GH-365 envelope's tree bracket caught it and refused
   297	    # to attest two qualifying runs before the shape was pinned.
   298	    bash "test/$t" 2>&1 | tee -a "$GATE_SUITE_LOG" | tee "$_one"
   299	    _rc="${PIPESTATUS[0]}"
   300	    if [ "$_rc" -eq 0 ]; then
   301	      printf '%s\tpass\n' "$t" >> "$GATE_VERDICTS"
   302	    else
   303	      rc=1
   304	      printf '%s\tFAIL\n' "$t" >> "$GATE_VERDICTS"
   305	      echo "  ^^ FAILED: $t" >&2
   306	    fi
   307	    rt_suite sequential "$t" "$_s" "$(rt_now_ms)" "$_rc" "$_one"
   308	  done
   309	  rm -f "$_one"
   310	
   311	  # GH-377 review blocker 1: the qualifying run must execute the AUTHORITATIVE tier-3 set, not a
   312	  # .sh-only subset. validate.sh owns three non-TESTS lanes; this runner supplies its own envelope
   313	  # bracket (the identity half of lane two), but Python and gamma-poison were historically omitted
   314	  # while the output said "full suite" and the record claimed qualifying evidence. They are part of
   315	  # the loop now, recorded in the verdicts under validate.sh's own PASSED labels so the record and
   316	  # the summary agree on the denominator.
   317	  _s="$(rt_now_ms)"
   318	  _rc=0
   319	  if python3 -m pytest "$HERE/test/test_python_layer.py"; then
   320	    printf '%s\tpass\n' "python:test_python_layer.py" >> "$GATE_VERDICTS"
   321	  else
   322	    _rc=$?   # before any other statement — the printf/echo and the rt_now_ms substitutions reset $?
   323	    rc=1
   324	    printf '%s\tFAIL\n' "python:test_python_layer.py" >> "$GATE_VERDICTS"
   325	    echo "  ^^ FAILED: python:test_python_layer.py" >&2
   326	  fi
   327	  rt_emit suite sequential "python:test_python_layer.py" "$_s" "$(rt_now_ms)" "$_rc"
   328	
   329	  _s="$(rt_now_ms)"
   330	  _rc=0
   331	  if git apply --check "$HERE/test/fixtures/gamma-poison/poison.patch" 2>/dev/null; then
   332	    printf '%s\tpass\n' "gamma-poison-staleness-probe" >> "$GATE_VERDICTS"
   333	  else
   334	    _rc=$?   # before any other statement — same ordering rule
   335	    rc=1
   336	    printf '%s\tFAIL\n' "gamma-poison-staleness-probe" >> "$GATE_VERDICTS"
   337	    echo "  ^^ FAILED: gamma-poison-staleness-probe" >&2
   338	  fi
   339	  rt_emit suite sequential "gamma-poison-staleness-probe" "$_s" "$(rt_now_ms)" "$_rc"
   340	  return $rc
   341	}
   342	
   343	# ── 10. GH-10/GH-365: the shared envelope bracket — assert half ─────────────────────────────────
   344	# The qualifying run writes the gate-evidence record, so it carries the same clone-identity
   345	# bracket validate.sh has, from the SAME shared helper (GH-365 step 1): identity drift fails the
   346	# run (the GH-564 incident), and envelope drift (tracked tree / worktrees / driver lock changed
   347	# under the run) is named and also fails — a qualifying run that cannot retain attributable
   348	# evidence must not exit green (the failure mode #365 exists to prevent).
   349	ci_local_envelope_assert() {
   350	  runner_envelope_assert "$HERE" "ci-local.sh"
   351	  local rc=$?
   352	  RT_ENVELOPE_RC="$rc"; RT_ENVELOPE_DRIFT="${RUNNER_ENVELOPE_DRIFT_FACETS:-none}"
   353	  return "$rc"
   354	}
   355	
   356	# ── run ──────────────────────────────────────────────────────────────────────────────────────────
   357	printf '\033[1mci-local — mirroring .github/workflows/ci.yml tier1\033[0m\n'
   358	printf 'repo: %s\n' "$HERE"
   359	printf 'HEAD: %s\n' "$(git log --oneline -1 2>/dev/null)"
   360	[ "$FAST" -eq 1 ] && printf '\033[33mmode: --fast (full validate.sh suite SKIPPED)\033[0m\n'
   361	# GH-365 step 2: open the retained telemetry record for THIS run (same schema as validate.sh).
   362	# The registered denominator is parsed here, once, exactly the way validate_suite parses TESTS —
   363	# so run.start carries the explicit denominator instead of inheriting a stale section count.
   364	# The denominator comes from validate.sh --list — the READ-ONLY registry surface #141 built for
   365	# exactly this (secondary selectors share one source of truth) — not a second TESTS scrape.
   366	# This is not "invoking validate.sh" in the sense gh544 pins: the gate never runs, no suites, no
   367	# envelope; it prints the manifest and exits.
   368	_declared="$(bash "$HERE/validate.sh" --list | wc -l | tr -d ' ')"
   369	if [ "$FAST" -eq 1 ]; then
   370	  rt_begin "$HERE" "ci-local" "fast" 1 3 "$_declared"
   371	else
   372	  rt_begin "$HERE" "ci-local" "sequential" 1 3 "$_declared"
   373	fi
   374	
   375	step "prerequisites"                check_prereqs
   376	step "shellcheck tracked scripts"   shellcheck_tracked
   377	step "bash syntax"                  bash_syntax_tracked
   378	step "node syntax"                  node_syntax_tracked
   379	step "settings JSON"                settings_json_valid
   380	step "PDDA deterministic gate"      pdda_gate
   381	if [ -n "$BASE" ]; then
   382	  step "frozen twin guard"          frozen_twin_guard
   383	else
   384	  printf '\n\033[33mSKIP: frozen twin guard — CI runs it on pull_request only. Pass --base <ref> to run it.\033[0m\n'
   385	fi
   386	step "npm ci + acorn-extract"       npm_and_acorn
   387	# GH-10/GH-1 + GH-365 step 1: the qualifying run gets the SAME envelope validate.sh uses, from
   388	# the ONE shared helper — harness-registry scratch (XYZ_HARNESS_DB) AND the identity bracket AND
   389	# the tree/worktree/lock bracket. Before GH-365, this run executed the registered suites with no
   390	# scratch envelope at all: harness_app.py writes landed in the TRACKED harnesses.db, the tree
   391	# went dirty, and gate-record.sh then refused to retain the record for exactly the run that
   392	# needed it. Fail closed if the helper is missing — never a second inline envelope.
   393	if [ "$FAST" -eq 0 ]; then
   394	  if [ ! -f "$HERE/test/lib/runner-envelope.sh" ]; then
   395	    echo "ci-local: test/lib/runner-envelope.sh is missing — the shared GH-365 runner envelope cannot be set up; refusing." >&2
   396	    exit 1
   397	  fi
   398	  . "$HERE/test/lib/runner-envelope.sh"
   399	  runner_envelope_begin "$HERE" "ci-local.sh" || exit 1
   400	  RELAY_SELF_SUFFICIENCY_SKIP=1 step "validate.sh suite" validate_suite
   401	  step "clone-identity invariant (GH-1)" ci_local_envelope_assert
   402	  runner_envelope_scrub
   403	fi
   404	
   405	# ── report ───────────────────────────────────────────────────────────────────────────────────────
   406	printf '\n\033[1m─── ci-local summary ───\033[0m\n'
   407	for s in "${PASSED[@]}"; do printf '  \033[32m+\033[0m %s\n' "$s"; done
   408	if [ "${#FAILED[@]}" -gt 0 ]; then
   409	  for s in "${FAILED[@]}"; do printf '  \033[31m-\033[0m %s\n' "$s"; done
   410	  printf '\n\033[31mci-local: %d step(s) failed\033[0m\n' "${#FAILED[@]}"
   411	  printf 'This ran on macOS — the platform XYZ ships to — so a failure here is a real defect for\n'
   412	  printf 'real users. Do not wait for hosted CI to confirm it; the ubuntu job is advisory (GH-509).\n'
   413	  rt_summary "${#PASSED[@]}" "${#FAILED[@]}" "$(( ${#PASSED[@]} + ${#FAILED[@]} ))" "declared=$_declared" "recorded=no"
   414	  exit 1
   415	fi
   416	printf '\n\033[32mci-local: all steps passed\033[0m\n'
   417	printf 'Green on the shipping platform, with the full suite — including the one hosted ubuntu skips.\n'
   418	printf 'NOT a promotion qualification: this run is self-reported. Promotion needs a hosted macOS run\n'
   419	printf 'for this exact commit (GH-509 §6) — a clean machine, and evidence you did not produce.\n'
   420	
   421	# ── GH-509: record that THIS COMMIT was verified here ────────────────────────────────────────────
   422	# Only a full run earns a record. A --fast or --probe run deliberately does not exercise the suite,
   423	# so recording one would make a partial run indistinguishable from a complete one — which is the
   424	# whole failure mode this file keeps warning about in other contexts.
   425	#
   426	# GH-365 step 1: a REFUSED record now fails the qualifying run instead of passing silently
   427	# (`|| true` used to swallow it). The record is the product of this run: a green exit with no
   428	# retained evidence is precisely the "cannot retain its evidence" failure #365 exists to prevent.
   429	# gate-record's own refusal names what made the tree dirty (exit 3) or why no commit was found
   430	# (exit 4); the envelope assert above has already named any drift that explains it.
   431	if [ "$FAST" -eq 0 ] && [ "$PROBE" -eq 0 ]; then
   432	  printf '\n'
   433	  # Delegated rather than inlined, so the REFUSAL has a test that does not cost a 15-minute suite run.
   434	  _gr_rc=0
   435	  bash utils/gate-record.sh --suite-log "$GATE_SUITE_LOG" --verdicts "$GATE_VERDICTS" || _gr_rc=$?
   436	  rt_emit stage stage "gate-record" "$(rt_now_ms)" "$(rt_now_ms)" "$_gr_rc"
   437	  if [ "$_gr_rc" -ne 0 ]; then
   438	    printf '\033[31mci-local: gate-record refused (exit %d) — this qualifying run leaves NO evidence record, so it cannot exit green (GH-365).\033[0m\n' "$_gr_rc" >&2
   439	    rt_summary "${#PASSED[@]}" "${#FAILED[@]}" "$(( ${#PASSED[@]} + ${#FAILED[@]} ))" "declared=$_declared" "recorded=refused-$_gr_rc"
   440	    exit 1
8:> - **Exception to this file's scope**: §4 "Opinionated SOPs" is a general **maintainer-workflow
10:>   maintainer development work, not just testing campaigns, and is optional for downstream users.
37:[3. Local Gate Preflight (non-qualifying)] ──> (./validate.sh)
71:The promotion procedure is four DB/file steps on the RELEASES DB:
92:> **This is a disposable CAMPAIGN clone** (destructive-suite isolation, GH-564) — cloning from
95:> `origin/development` per §4 "Opinionated SOPs", so its `origin` points at GitHub.
97:### Step 3: Local Gate Preflight (non-qualifying)
104:qualifying run that writes the evidence record is `bash ci-local.sh` (see `AGENTS.md`), which
105:remains outstanding until run.
114:Provision a disposable scratch repository outside the codebase:
194:## 4. Opinionated SOPs (XYZ-maintainer defaults — optional downstream)
196:> **Who these are for:** These conventions exist to help the **XYZ maintainers** with our own
199:> maintainers to ignore them, or write a script that strips this section on pull from upstream.
207:  exempt (they live on their own task branch and are disposable).
231:  path above remains user-request-only).
250:   Scopes 1+5, 3+4, and 2 as three PRs; two would have carried the same review weight.
261:5. **Delegate in this shape when lanes are independent:** each lane gets its own fresh
266:   reviewed head — and **independently verifies any claim the gate cannot prove** (the
306:**Deploy ("upload"):** commit and push to `development` (or `main`). The workflow

exec
/bin/zsh -lc "nl -ba SOP.md | sed -n '84,113p;194,236p;253,274p;293,323p'; nl -ba AGENTS.md | sed -n '80,177p;269,305p;338,414p'; nl -ba GUIDING-PRINCIPLES.md | sed -n '1,105p'; nl -ba ROUTER.md | sed -n '108,181p'" in /private/var/folders/69/3l_82qtj7fzglnt_jjg07jh40000gn/T/consult-wt-43891-m8ixsws8
 succeeded in 0ms:
    84	
    85	### Step 2: Isolated Full Clone Provisioning
    86	```bash
    87	git clone . ../XYZ-forge-<topic>
    88	cd ../XYZ-forge-<topic>
    89	bash githooks/install.sh
    90	```
    91	
    92	> **This is a disposable CAMPAIGN clone** (destructive-suite isolation, GH-564) — cloning from
    93	> the local checkout is fine because nothing here ever pushes. It is **not** the fix/feat PR
    94	> lane: new development work clones from the **GitHub remote** and branches off
    95	> `origin/development` per §4 "Opinionated SOPs", so its `origin` points at GitHub.
    96	
    97	### Step 3: Local Gate Preflight (non-qualifying)
    98	Before launching a campaign or spending API tokens:
    99	```bash
   100	./validate.sh
   101	bash utils/fuzzing/fuzz-loop.sh
   102	```
   103	Ensure 100% of test suites pass before proceeding. This is a **self-check preflight** — the
   104	qualifying run that writes the evidence record is `bash ci-local.sh` (see `AGENTS.md`), which
   105	remains outstanding until run.
   106	
   107	### Step 4: Configure Matrix & Telemetry
   108	Define the variation matrix in `utils/ate/variations.<name>.yaml`:
   109	- Always use `{harness_root}` in `command_template` for script paths.
   110	- Ensure the runner emits structured telemetry fields (`duration_ms`, `turn_count`, `prompt_tokens`, `completion_tokens`, `tokens_source`).
   111	- **Diagnostic Probes:** Set `expects_edits: false` on diagnostic grids that read/report without modifying the working tree (prevents false `no_edit` classifications).
   112	
   113	### Step 5: Execute Campaign with Supervision
   194	## 4. Opinionated SOPs (XYZ-maintainer defaults — optional downstream)
   195	
   196	> **Who these are for:** These conventions exist to help the **XYZ maintainers** with our own
   197	> development flow on this repository. They are **not** part of the harness contract.
   198	> **Public users and downstream forks are free to disable them**, instruct their own LLM
   199	> maintainers to ignore them, or write a script that strips this section on pull from upstream.
   200	> Nothing in the codebase enforces them.
   201	
   202	- **CI churn recovery.** When CI churn is suspected, follow [`docs/CI-CHURN-RECOVERY-SOP.md`](docs/CI-CHURN-RECOVERY-SOP.md) (#857). It covers the entry gate for declaring an episode, the phased strategy checklist, and the exit gates for closing it. It grants no standing exception to `AGENTS.md`.
   203	- **The primary clone stays on `development`.** Each device has exactly one
   204	  **operator-designated primary clone** — the long-lived checkout the operator opens by default
   205	  and keeps mapped to GitHub. That clone is always kept on the `development` branch. This rule
   206	  applies **only** to the primary clone by role; task clones provisioned under the next rule are
   207	  exempt (they live on their own task branch and are disposable).
   208	- **Express-to-development is explicit; everything else gets a fresh full clone.** Direct
   209	  commit + push into `development` happens only when the user **explicitly asks** for an express
   210	  commit of critical work. In every other case, the LLM begins new work by provisioning a
   211	  **new local full-clone folder** — a full clone, *not* a git worktree (GH-564) — cloned from
   212	  the GitHub remote so `origin` points at GitHub, wired with the gate, and branched off
   213	  `origin/development`:
   214	
   215	  ```bash
   216	  # Name = <repo-name>-gh<issue>-<very-short-desc>-<yyyy-mm-dd>, a sibling of the primary clone (GH-970)
   217	  N=XYZ-forge-gh1234-showme-command-2026-10-05
   218	  git clone git@github.com:HiQS-Labs/XYZ-forge.git ../$N
   219	  cd ../$N
   220	  bash githooks/install.sh                       # per-clone; the gate does not travel (GH-549)
   221	  git checkout -b feat/$N origin/development     # or fix/ chore/ docs/
   222	  ```
   223	
   224	  The full naming rule (multi-issue groups, `-gate`/`-verify` helper clones, resume before
   225	  re-create) lives in `skills/1-hourly/start-task/SKILL.md` step 3. Work lands by pushing that
   226	  task branch and opening a PR into `development`. **This policy is
   227	  the standing explicit authorization** for that fresh-clone task branch under `AGENTS.md`'s
   228	  "do not create new git branches automatically" rail — the same carve-out shape as the
   229	  marathon per-lane branch. It authorizes exactly one `feat/`/`fix/`/`chore/`/`docs/` branch per
   230	  fresh task clone, and it is *not* a licence to commit directly onto `development` (the express
   231	  path above remains user-request-only).
   232	
   233	### Arc planning — schedule the follow-up lanes, don't discover them
   234	
   235	> Lesson from the GH-280/#291 stretch (2026-08-29): six PRs in ~48h, each small and safe,
   236	> yet the shape of progress was a thicket instead of a line. Post-mortem: the *arc* was
   253	   reconciliation as fallback, the rule is to let hosted runs finish (or pass `--force-local-reconcile`
   254	   in emergencies) and batch multiple PRs (`wave_reconcile.py --pr <N> <M>`) rather than running
   255	   instantly per merge. Task branches must not commit routine view updates (`ROADMAP-DASHBOARD.md`,
   256	   `LEADERBOARD.md`).
   257	4. **Never write bare `#N` for another repo's issues in a PR body.** The reconciler
   258	   resolves every `#N` against *this* repo and exits 6 when it cannot (GH-301 needed an
   259	   offline-manifest escape mid-reconcile). Cross-repo references are written `GH-N`;
   260	   in-repo references may use `#N`.
   261	5. **Delegate in this shape when lanes are independent:** each lane gets its own fresh
   262	   full clone and exactly one branch + one PR; it commits and pushes at every milestone
   263	   (the push gate is the boundary); it never merges its own PR. A single
   264	   orchestrator-reviewer holds merge duty, checks the three predicates (base branch,
   265	   diff size vs logical scope, gate evidence on the final SHA), merges pinned to the
   266	   reviewed head — and **independently verifies any claim the gate cannot prove** (the
   267	   gate-invisible example: a suite exempted from the registry as "pre-existing red").
   268	
   269	### The project website (GitHub Pages) — edit, update, deploy
   270	
   271	`PAGES/` is the root of the live site at <https://hiqs-labs.github.io/XYZ-forge/>.
   272	There is no upload step and no build step for the static pages: what is committed to
   273	`PAGES/` is what gets served. Deploy happens in `.github/workflows/pages.yml`
   274	(Pages is enabled with **Source: GitHub Actions**, i.e. `build_type=workflow` — a custom
   293	```bash
   294	python3 utils/py/site_build.py           # rewrite the two generated pages from the ledgers
   295	python3 utils/py/site_build.py --check   # informational: are committed copies stale?
   296	```
   297	
   298	**Preview locally** (loopback only — never bind a preview server to anything but
   299	127.0.0.1; see §3b on network paths):
   300	
   301	```bash
   302	cd PAGES && python3 -m http.server 8765 --bind 127.0.0.1
   303	# then open http://127.0.0.1:8765/ — links are relative, so they work under any prefix
   304	```
   305	
   306	**Deploy ("upload"):** commit and push to `development` (or `main`). The workflow
   307	triggers on changes to `PAGES/**`, `utils/py/site_build.py`, `utils/py/releases_app.py`,
   308	`releases.db`/`releases.sql`, `harnesses.db`/`harnesses.sql`, and the workflow file —
   309	so a ledger push republishes the roadmap even when nobody re-ran the builder. To
   310	redeploy without a push: `gh workflow run pages.yml --ref development`. Verify with
   311	`gh run watch <id>` and a `curl -sI` of the live URL; the concurrency group (`pages`)
   312	cancels superseded runs, so only one deploy lands at a time. The normal pre-push gate
   313	applies (~8 min if code paths are touched).
   314	
   315	**Site-specific rails:**
   316	
   317	- **Everything in `PAGES/` is publicly served.** No scratch files, notes, or drafts in
   318	  there (the near-miss: `PAGES/TEMP.md` research notes would have shipped as a public
   319	  page; they now live in `temp/`). Scratch goes to `temp/`, never the site root.
   320	- **Relative links only.** The site serves under `/XYZ-forge/`; an absolute path like
   321	  `/assets/style.css` 404s in production while working in some local previews.
   322	- **Adding a page means three edits:** the new file, the nav link in every static page
   323	  *and* the `NAV` list in `utils/py/site_build.py` (the generator does not read the
    80	changes need a rollback path. One-way doors need explicit confirmation before proceeding.
    81	
    82	This scale is how `GUIDING-PRINCIPLES.md` → "The North Star" gets applied per change; that section
    83	owns the *why*, this one owns the read.
    84	
    85	### 4. Size the blast radius before changing shared surfaces
    86	
    87	Before a refactor, schema change, dependency bump, coordination-kernel change, or relay-containment
    88	change, say what ripples, what might break, and who notices. A change you cannot size is not ready.
    89	
    90	### 5. One plan, one ordered list
    91	
    92	When you give executable steps, put them in one numbered list in execution order. Keep verification
    93	inline (`-> expect ...`). Do not scatter action items across prose.
    94	
    95	### 6. Verified beats plausible
    96	
    97	Do not claim success without the relevant test, script, or observable proof. If verification was
    98	skipped or failed, say that plainly and include the result.
    99	
   100	An uncommitted `provenance.jsonl` is not proof (GH-430). Any run cited as evidence in an issue, PR,
   101	ROADMAP entry, or decision record must have its `provenance.jsonl` committed in the same PR — a path
   102	you merely ran and can no longer show counts as no claim at all.
   103	
   104	**A check that cannot fail is not a check.** A passing assertion is evidence only once you have seen
   105	it fail: mutate the thing it guards — break the code, transpose the fix, delete the value — and watch
   106	it go red. If you cannot make it fail, it is decorative, and it is worse than nothing because it
   107	reports confidence it never earned. Witness the failure on an existing suite or record it as a manual check.
   108	Never add a suite to do it; see the *No new tests* rail. This is the precise way this principle fails while looking
   109	satisfied: you *did* verify, and the verification was hollow. Three examples from GH-377/GH-379, all
   110	of which passed cleanly before they were mutated — an `awk` range that terminated on its own first
   111	line, `not matches -- "$pat"` where the helper already supplied `--` so the check searched for the
   112	literal string `--`, and a telemetry `rc` assertion that no *passing* run could ever exercise.
   113	
   114	**A flaky suite is fixed in place if it is in a tier, and turned off if it is not.** Tier membership comes from
   115	`utils/ci-route.sh` (`SUBSYSTEM_TESTS_small`). Turning off means removing it from `validate.sh` `TESTS` and adding it to the
   116	gh306 `EXEMPT` list, keeping the file (#802 operator decision, comment 5841529958; #853).
   117	
   118	**An empty input passes every check.** Before asserting anything about extracted data, assert that
   119	you extracted some: a failed command substitution yields an empty string, a shell redirect creates
   120	the file regardless, and a scanner then reports CLEAN against zero bytes. Size-check the artifact,
   121	or guard the extraction with its own assertion, before trusting a verdict computed from it.
   122	
   123	**Never expose the operator's machine to the network without asking.** A tunnel, port forward, or
   124	remote bridge needs explicit permission each time — running the tests is not permission, and neither
   125	is working on the feature that provides it. `SOP.md` §3b has the incident and the teardown rule that
   126	goes with it.
   127	
   128	**Establish blocker necessity before investing in repair.** An in-flight failing test or unexpected error is not automatically an urgent blocker. When an obstacle's necessity or user consequence is unclear, or after two investigation attempts yield no new evidence, run `sanity-check` (`skills/1-hourly/sanity-check/SKILL.md`) to evaluate whether to fix now, simplify, defer via PRS, or dismiss, before sinking hours into tracing the fail path.
   129	
   130	### 7. Record only consequential bets
   131	
   132	If a change is Costly, One-way door, or assumption-heavy, record the bet in `CHANGELOG.md` per
   133	`PROJECT/PDDA.md`. Below that threshold, skip the ritual.
   134	
   135	### 8. Stay quiet on trivial work
   136	
   137	Most edits are small and reversible. Do not manufacture ceremony for a rename, typo fix, or other
   138	local change.
   139	
   140	## Repo-specific rails
   141	
   142	- **No new tests (GH-831, operator decision 2026-09-25).** This covers three things:
   143	  - Do not add a new `test/` suite or a new entry in `validate.sh`'s `TESTS` registry.
   144	  - Do not add new gate machinery: guards, lanes, runners or telemetry stages.
   145	  - Do not add a test to enforce this rule.
   146	
   147	  Verify a change with the existing suite that covers it, or with a manual check recorded under
   148	  `TESTS-RESULTS/<date>+GH-<n>/` with its `provenance.jsonl`. Edit an existing suite only to keep it truthful
   149	  when the behaviour it pins changes. A red control (see *Verified beats plausible*) is witnessed on an
   150	  existing suite or recorded as a manual check. Reviewers treat a new test file as a finding.
   151	
   152	  The gate is being cut to Small/Medium/Large tiers under [#831](https://github.com/HiQS-Labs/XYZ-forge/issues/831).
   153	  #815, #816, #817 and #819 are superseded; do not implement them.
   154	
   155	- **This repo's purpose is to keep a long-horizon marathon under load — and that is a work-selection
   156	  filter, not a slogan.** The harness is only proven by work long enough, parallel enough, and
   157	  failure-prone enough to tax the whole system: worktree isolation, path claims, the driver lock,
   158	  multi-round handoff, escalation, and resume. Short, single-shot tasks land fine but prove nothing.
   159	  Four rules follow, and they are load-bearing:
   160	
   161	  1. **Exactly one long-horizon marathon is in flight at a time.** When one lands, choosing the next
   162	     is a real decision, not a default. It is named in the roadmap ledger's **Immediate next-up**
   163	     (query via `python3 utils/py/releases_app.py roadmap list`; the RELEASES DB is the source of truth since the
   164	     `ROADMAP_SOURCE=releases` flip) as the marathon, so an agent arriving cold can tell which item
   165	     is the load and which items are riding alongside it.
   166	  2. **Prefer the marathon-shaped candidate.** *Marathon-shaped* means: decomposable into many items
   167	     with an identical transform, a per-item pass condition a machine can check, and a plausible way
   168	     to break the harness. GH-10 (73 unaudited suites, one mechanical adoption each) is the
   169	     archetype. Picking a non-marathon-shaped item over a marathon-shaped one of comparable value
   170	     needs a stated reason — write it in the ledger entry, not in a commit message.
   171	  3. **Only real work.** Never manufacture a marathon to keep the system busy, and never build a
   172	     synthetic workload that cannot damage anything — a run with no blast radius does not surface
   173	     the failures that matter. If nothing genuinely needed is marathon-shaped right now, **the
   174	     correct state is idle**. Say so plainly and do the smaller work; an idle gap is honest signal,
   175	     a fabricated marathon is noise that costs real tokens.
   176	  4. **The point is the failures.** A marathon that completes cleanly and teaches nothing is a
   177	     weaker result than one that escalates and names a defect. Report what broke; do not smooth it.
   269	  `swarm-preflight`). Their `.sh`
   270	  files are historical `XYZ_PYTHON=0` fallbacks: put behavior fixes in the named Python twin, not
   271	  the Bash body. Before committing, run `bash test/gh308-frozen-twin-guard.sh --check --staged`; the
   272	  `Frozen Bash twin guard (GH-308)` step in `.github/workflows/ci.yml` runs the same guard with
   273	  `--base <PR base> --allow-exceptions` on every PR to reject a committed twin edit. **Escape
   274	  hatch:** a safety defect in a fallback can warrant an edit anyway — GH-319 left a silently-fake
   275	  pre-advance gate in `marathon-drive.sh` under `XYZ_PYTHON=0`. Such a commit must carry a trailer
   276	  that **names the twin it covers**, with an em-dash before the reason:
   277	
   278	  ```
   279	  Frozen-twin-exception: relay-automation/marathon-drive.sh — silently-fake pre-advance gate (GH-319)
   280	  ```
   281	
   282	  **Per file, not per PR (GH-321).** Every frozen twin changed in the range must be named by some
   283	  trailer in that range; one exception no longer excuses a different, undeclared edit riding along
   284	  on the same branch — the common case on a multi-lane marathon PR. A trailer naming a path that is
   285	  not a frozen twin fails loudly rather than silently covering nothing, and the bare
   286	  `Frozen-twin-exception: <reason>` form (no path) no longer covers anything. Comma-separate to cover
   287	  several twins with one reason. No trailer, no edit.
   288	
   289	  **`utils/marathon-plan.sh` is no longer the exception (GH-362).** It was, while its Python "port"
   290	  shelled out to a copied node engine with documented gaps; GH-340 deleted that copy and made the
   291	  Python lane native, so the exception outlived its reason and marathon-plan is now the **12th frozen
   292	  twin**. `relay-turn-lib.sh` remains a shared Bash runtime dependency rather than a twin, and is the
   293	  only non-frozen file left in the Tier-A surface.
   294	
   295	  **No new Bash either (GH-551).** New executables are Python in `utils/py/`; the same guard rejects
   296	  a **new** `.sh` file added under `utils/` or `relay-automation/` unless a
   297	  `New-bash-exception: <path> — <reason>` trailer names it (per file, like GH-321). `test/`, git
   298	  hooks, and existing shims are out of scope.
   299	
   300	  **Two edits the guard permits without a trailer, both narrow (GH-362).** A commit that *introduces*
   301	  a path's `FROZEN` banner establishes the freeze for that path and is not a violation of it — a range
   302	  reaching back before the freeze (a release merge, a bisect, an old fork base) contains exactly that
   303	  commit. The exemption covers the establishing edit only; anything touching the path *after* it in
   304	  the same range still needs a trailer. Relatedly, the pre-GH-321 pathless trailer is tolerated **only**
   305	  inside such a commit, because it is permanently in git history and cannot be rewritten — a new
   338	  share `.git` objects/refs, so destructive *git* operations (`update-ref`, `branch -D`, resets,
   339	  force-push) still hit the real repo — a worktree-isolated agent once reset ROOT HEAD via
   340	  `rtl_enforce`'s commit-bypass guard. Harness-driven codex/agy lanes are covered by
   341	  `rtl_worktree_begin` instead and don't need the flag. Known frictions: `--require-clean` self-trips
   342	  on the driver's own lock dir inside a linked worktree, and untracked artifacts are invisible to a
   343	  worktree checkout — commit review inputs first. Read-only subagents (Explore, audits) don't need
   344	  isolation. Related guards: never execute `validate.sh`/`test/*.sh` under a sandboxed Bash call
   345	  (enforced by `relay-automation/hooks/gh177-sandbox-test-guard.sh` — re-run it un-sandboxed; do NOT
   346	  push it to CI to be exercised, see the CI rail below), and `test/mktemp-trap-guard.sh` statically
   347	  outlaws the wipe idiom repo-wide. **The "what it does NOT protect" list above is narrower than
   348	  reality — see the next rail (GH-564): a worktree isolates the working tree only, and everything
   349	  under `.git` is shared, which is why running the suite in one contaminated the parent clone twice.**
   350	- **Run the suite in a SEPARATE FULL CLONE, never in a clone whose state you care about — and a
   351	  linked worktree is NOT a way around it (GH-564).** `validate.sh` and `test/*.sh` can write to the
   352	  git config, remotes, and refs of the repository they are invoked from. On 2026-08-15 the primary
   353	  clone was contaminated **twice in one morning**: `core.bare=true`, `remote.origin.url` repointed at
   354	  a fixture bare repo, a fixture `[user]` identity appended, and `refs/heads/development` reset onto
   355	  ~35 fixture commits. It also **defeated the push gate while corrupting it** — pushes failed with
   356	  `'/var/folders/…/bare.XXXXXX' does not appear to be a git repository` because the suite repointed
   357	  `origin` mid-hook.
   358	  - **The worktree precaution was taken and it FAILED.** Both bursts came from `./validate.sh` run in
   359	    linked worktrees cut off the primary clone, chosen specifically to isolate the risk. **Linked
   360	    worktrees share `.git/config` with the parent clone**, so an escape landing in a worktree's CWD
   361	    writes the parent's config. Reproduced deterministically: from a worktree CWD, `r=""; git -C "$r"
   362	    remote set-url origin "$b"` rewrote the *parent* clone's origin. Same structural fact the
   363	    driver-lock matrix documents from the other side (GH-42/GH-354/GH-448) — a linked worktree
   364	    resolves to the parent's `git-common-dir`, which is why it grants no second lane either.
   365	  - **State the boundary precisely, because the previous rail's version was too narrow.** The rail
   366	    above says worktree isolation does not protect against destructive *git operations*. That is
   367	    true and insufficient: a worktree isolates the **working tree only**. Everything reached through
   368	    `.git` — config, remotes, refs, objects, hooks — is shared with the parent clone, whether it is
   369	    touched deliberately or by an escaped fixture. Only a **separate full clone** isolates any of it.
   370	  - **Why it escapes at all:** `git -C ""` is documented to leave the working directory unchanged and
   371	    `cd ""` is a bash no-op, and these suites run without `set -e` — so one unguarded
   372	    `r="$(mktemp -d …)"` silently redirects every "fixture" operation onto the caller's clone. It
   373	    fires under **parallel** load (the failure mode of `mktemp`), which is why a serial re-run of the
   374	    same suite reproduces nothing and must not be read as an all-clear. GH-177 family.
   375	  - **Until #564's suite-wide invariant gate lands**, treat any clone you ran the suite in as
   376	    suspect: check `git config --get core.bare`, `git remote -v`, `git config --local --get user.email`,
   377	    and `git log --oneline -1` before trusting a push, a fetch, or a green run from it. A guarded
   378	    fixture helper (`require_fixture`: the path must exist AND live under `$WORK` — containment, not
   379	    a null check) is the pattern to copy; `test/gh544-pre-push-gate.sh` has it, 31 other suites do
   380	    not.
   381	  - **Validate a sandbox path at the USE boundary, not where it was created (GH-567).** An empty
   382	    variable does not fail — `git -C ""` uses the current directory, `cd ""` is a no-op,
   383	    `rm -rf "$VAR/"` becomes `/`, `find "$VAR" -delete` becomes `.`. So guard immediately before the
   384	    first dangerous use **in every function that receives the path**, not once at the `mktemp` that
   385	    derived it: a variable that was safe at line 10 can be empty at line 50, and a derivation-site
   386	    check never covers a path passed in from elsewhere. Assert non-empty, a **resolved** descendant
   387	    of the sandbox root, and the expected type — `require_fixture`'s current `case "$p" in "$WORK"/*)`
   388	    is lexical and still accepts `$WORK/../../<real repo>`, so harden it before copying it into the
   389	    other 31. `set -e` is not the containment proof; these suites deliberately run without it.
   390	  - **A clone whose identity changed under a run cannot attribute that run (GH-567).** If a suite
   391	    fails only under parallel load, compare `core.bare`, `git remote -v`, the local user identity and
   392	    `HEAD` against their pre-run values **before** blaming your diff. Unexpected drift invalidates
   393	    every result from that clone — re-clone, then run candidate and base at the same width. Identity
   394	    intact means it is your diff or ordinary flakiness: investigate normally. This is a trigger, not a
   395	    licence to write failures off as harness noise; the 2026-08-15 incident cost several full-suite
   396	    runs to a single green control run treated as proof, which is one sample from a nondeterministic
   397	    process.
   398	  - **An audit that recognizes only one invocation shape stops covering the same operation reached a
   399	    different way (GH-195).** `marathon-root-audit.sh` exists (GH-401) specifically to catch an
   400	    unscoped marathon-drive invocation writing into the real clone instead of a fixture — but its
   401	    detector only matches `bash <driver>.sh`. A test that calls `python3 marathon_drive.py` directly
   402	    is invisible to it. That exact gap let `test/gh115-round-cap.sh` commit a live transcript onto
   403	    whichever real clone was running `validate.sh`, every single run, reproduced across 4 separate
   404	    clones including a brand-new one. **If you add or harden an audit that matches on invocation
   405	    text, ask what it does NOT match, not just what it does.** Diagnosing this cost ~2.5h chasing
   406	    plausible-but-wrong external causes (a leftover process, a second concurrent agent, a scheduled
   407	    job) before a one-shot stack-trace at the actual write call site named the real culprit in one
   408	    run — when a repeatable artifact exists (here: the per-clone `.tick/attempts/<phase>` fire
   409	    ledger, timestamp-correlated to each gate run), inspect it directly before building a
   410	    process-hunting hypothesis chain. Full writeup:
   411	    [GH-195-MARATHON-ROOT-AUDIT-BLIND-SPOT.md](PROJECT/3-COMPLETED/GH-195-MARATHON-ROOT-AUDIT-BLIND-SPOT.md).
   412	- **The local macOS run is the gate; hosted ubuntu is advisory (GH-509).** XYZ is a developer toolkit
   413	  for **macOS**; Linux and Windows are on the roadmap and not here yet. So `./validate.sh` (or
   414	  `./ci-local.sh`) on your Mac is the highest-fidelity evidence available — it is the shipping
     1	# Guiding Principles
     2	
     3	North star for **XYZ Forge**, the multi-agent coordination harness behind the `tick` event-log kernel and `relay-automation/` relay stack. When a choice is unclear, the option that keeps agents synchronized, contained, and verifiable — without leaking or destroying work — wins. AGENTS.md is the behavioral playbook; ROUTER.md is the entry-point map; this is the *why*.
     4	
     5	## The North Star
     6	
     7	There is no perfect architecture and no finished codebase. The bar is not perfection — it is that
     8	every change leaves the harness **more durable, more reversible, and less duplicated** than it found
     9	it, and that the three stay in balance:
    10	
    11	- **Durable** — it removes the root cause and the next planned change builds on it, rather than being
    12	  torn out when the obvious next feature lands.
    13	- **Reversible** — the cost of being wrong is known and bounded before the change lands. A change
    14	  nobody can undo is a bet, not a fix, and gets treated as one.
    15	- **DRY** — nothing canonical lives in two places where it can drift. One source of truth, and every
    16	  other surface is a pointer or a projection of it.
    17	
    18	**Do not build a new layer, module, or sub-system when an existing piece of code can be extended
    19	easily, logically, and safely.** Extending an existing abstraction beats standing up a parallel,
    20	siloed system, even when the parallel path is faster to write today — the parallel path is what
    21	later has to be kept in sync, and what silently drifts when it isn't. If the existing abstraction
    22	genuinely cannot carry the new case, say so in one line, with the reason, before forking.
    23	
    24	These three pull against each other, and that tension is the decision, not a problem to average
    25	away: the most durable fix is often the least reversible, and collapsing two near-duplicates is a
    26	DRY win that can widen the blast radius. Name the trade and pick; do not split the difference by
    27	building both.
    28	
    29	This section is canonical. `AGENTS.md` owns how it is applied to a given change — the reversibility
    30	scale (§3) and blast-radius sizing (§4) — and principles 6, 7, and 10 below are the build-time and
    31	done-time expressions of it. Where another doc restates this, that doc is the copy and this is the
    32	original.
    33	
    34	## Purpose
    35	
    36	XYZ Forge is a local-first operations system for humans directing agents across their repositories:
    37	capture → rate → plan → preflight → execute → gate → land → record. Its `tick` kernel coordinates
    38	local claims through an event log and exclusive locks; its relay and Marathon tooling drive bounded
    39	build and review work. Containment controls reduce accidental writes but do not guarantee safety
    40	outside their enforced boundaries; linked worktrees share Git state. The product prioritizes
    41	coordination, recoverability and verifiable outcomes. The operator remains the decision authority.
    42	
    43	XYZ is not enterprise application lifecycle management or an agent marketplace. It currently
    44	assumes specified work rather than providing a structured spec/PRD-generation pipeline of its own;
    45	that capability gap is not a permanent prohibition on future product work. PDDA’s governance-layer
    46	anti-scope does not prohibit XYZ’s coordination and execution features.
    47	
    48	## The quality bar
    49	
    50	Every agent turn is a signal. A turn is high-quality only when it is all four:
    51	
    52	- **Attested** — carries its receipts: source, evidence, confidence. Never a bare verdict. A relay review names which claim is wrong and why; a build turn names the seam it touched.
    53	- **Relevant** — ranked, not dumped. Volume is not value. One real bug beats five nits and a phantom.
    54	- **Fresh** — current, not stale. A turn that reads a stale `STATE.md` or misses an epoch fence is wrong by construction.
    55	- **Structured** — one shape, clean for the operator to read and for downstream agents to feed on.
    56	
    57	Fail a pillar, and the turn, feature, or relay review isn't done.
    58	
    59	## How it's built
    60	
    61	1. **Coordination is local-transport only.** `.tick/events/` is the shared bus; claims resolve from there, not from a remote. No per-event push/fetch; no remote dependency at runtime. A coordination primitive that reaches out is a coordination primitive that can fail or leak.
    62	
    63	2. **One canonical event log for tick coordination.** `.tick/events/` records coordination events; `.tick/STATE.md` is a derived view. Coordination verbs read and fold the events and append changes through the event API. Other subsystems retain their own documented sources of truth, including the RELEASES roadmap ledger. Do not create competing copies of canonical state.
    64	
    65	3. **Containment is non-negotiable.** A headless turn must not: self-commit mid-turn, orphan a peer's concurrent commit, or write outside its allowlist. The allowlist, worktree isolation, and commit-bypass guard exist because a driven agent will do all three if unconstrained — not hypothetically, but as documented live incidents (GH-13, GH-14, GH-17). New relay paths must clear the containment bar before they ship.
    66	
    67	4. **Skill-first; never improvise the harness.** The `relay-xyz` skill owns the locator, sandbox rules, exit codes, and the safety boundary. A session that improvises those from `ls relay-automation/` silently skips the skill's safety layer. In sessions that install and invoke the `PreToolUse` hook, `relay-automation/hooks/relay-xyz-guard.sh` checks supported driver invocations for the skill’s setup evidence; this is not a guarantee that every runtime invokes that hook. Add capabilities to the skill; do not work around it.
    68	
    69	5. **Adversarially proven before commercially viable.** The harness exists to run against real codebases. Features in the adversarial-hardening track (epoch fencing, chaos suite, cross-repo E2E) must be verified to survive deliberate abuse — stale writers, zombie claims, macOS case-sensitivity, concurrent peer commits — not just the happy path. A feature that clears the happy path and skips chaos is half-done.
    70	
    71	6. **Build durable, not band-aid.** Durable means it removes the root cause and the next planned change builds on it — not a patch torn out when the obvious next feature lands. A band-aid is wasted work unless a demo strictly needs one, and a demo band-aid is tagged for removal so it isn't silently inherited.
    72	
    73	7. **Least code that clears the bar.** The `tick` coordination kernel uses Node's standard library. The repository also ships `package.json` and `package-lock.json` for Acorn-based source analysis. Prefer reusing or extending what exists; the smallest change that stays correct, contained, and durable wins. Net-new code is a cost to justify. Deleting code counts as progress.
    74	
    75	8. **Honest; the operator decides.** Surface what failed and why — never mask a stall as success or an escalation as a stall. A headless turn self-repairs within a bounded exit-code menu (`exit 3` stall, `exit 4` escalated-by-design, `exit 6` containment revert), then stops; it never loops forever or silently swallows an error. Destructive actions require explicit authorization.
    76	
    77	9. **Docs support resumable work (PDDA).** ROUTER points to the governing contracts; the RELEASES DB owns this repository's roadmap ledger (queried via `python3 utils/py/releases_app.py roadmap list`). Linked PROJECT documents hold plans, decisions and handoff detail; CHANGELOG records dated outcomes. Resume execution using those documents together with the relevant runtime state and evidence. If current documentation contradicts the implementation, correct it or explicitly record the unresolved discrepancy.
    78	
    79	10. **Done means verified.** "Done" is `validate.sh` green, the relevant PDDA checks passing, and any relay review returning `Approved` — not work that looks finished. An unverified success claim is itself a low-quality signal.
    80	
    81	11. **Issue-first; every non-trivial change has a signal stream.** Any change beyond a 2–3 line fix opens a GitHub issue first, then gets a `GH-<number>` in-repo pointer doc, then lands. The issue is the machine-queryable signal stream; the `PROJECT/**` doc is the execution surface of record. Genuinely trivial edits (≤2–3 line fixes, typos, path repoints, doc-only one-liners) are exempt.
    82	
    83	12. **Independent Verification (Separated Grading)** — The agent that produces a turn must not be the sole grader of its own quality. Verification must be performed by an independent deterministic check or a separate reviewing agent before the lock releases. Applies to: the relay's structural block validator (`bin/validate-relay-block` — Phase 1 of GH-21), consult-verify diversity (Phase 3), and any other post-generation quality gate.
    84	
    85	13. **A green gate without a witnessed red control is not evidence.** Every new or materially changed decision gate needs a recorded demonstration that it fails for the right reason: a pre-fix replay, deliberate mutation, or controlled bad input. Witness it on an existing suite, or record it as a manual check under `TESTS-RESULTS/`. Never add a new test suite to do it (GH-831: no new tests). Do not mistake a check that validates the artifact it just generated (#351) or a parity check that compares a lane to itself (#348) for evidence; both shapes are structurally unable to falsify their claim.
    86	
    87	## Applying this
    88	
    89	Adding a feature or weighing a tradeoff, ask: *does this keep agents coordinated without collision, contained within their scope, and verifiable to an outside observer? And is "done" provable by running `validate.sh`?* If any answer is no, reconsider.
    90	
    91	---
    92	
    93	## Conventions
    94	
    95	### Strict-mode policy (bash `set -e`)
    96	
    97	Python is the default implementation for the twelve frozen Tier-A entry points. Existing Bash
    98	bodies are compatibility fallbacks selected with `XYZ_PYTHON=0`; their strict-mode choices remain
    99	subsystem-specific. Consult each existing script’s header and error handling before changing it.
   100	New executables under `utils/` or `relay-automation/` follow AGENTS.md’s Python and exception rules.
   101	This section does not authorize edits to frozen Bash twins.
   102	
   103	### Tool install paths — never inside another app's folder (GH-347)
   104	
   105	**This harness's tool binaries never live inside another application's private directory.** Not the
   108	**GH-35 also added TIERED SELECTION on top, as a separate axis from width.** `utils/ci-route.sh`
   109	owns one fail-closed subsystem registry (hq, releases, telemetry, ate, swe-diagram, pdda,
   110	agent-chorus, standup, skills-army-hq, plus `small`, a gate-only list that claims no paths); a push the classifier rates `tier=2` runs only those focused
   111	suites at the boundary, `--tier 1` runs the docs gate, and everything else — unknown paths, unclaimed
   112	test edits, kernel surfaces — runs the full suite. `--auto` classifies a local diff the same way.
   113	Tiers 1 and 2 are pre-push speed and are labelled NOT promotion evidence; only `ci-local.sh`'s
   114	sequential full run qualifies (GH-509).
   115	
   116	**GH-831 (2026-09-25) made these three tiers for what qualifies a landing.** The push hook is unchanged.
   117	After a merge, the hosted reconcile (`wave-reconcile.yml`) qualifies each landing with **one** run,
   118	picked by classifying the landing's changes at the tested commit:
   119	
   120	- **Small** — docs, the ledger dumps (`releases.*`, `harnesses.*`) and non-core skill files (tier 1):
   121	  `validate.sh --sequential --subsystem small`, the PDDA, PRS and canary suites plus the PDDA gate
   122	  and the Python layer. The receipt records the list it ran.
   123	- **Medium** — mapped non-core code (tier 2): the full registry at the reconcile, the area's suites at push.
   124	- **Large** — core harness, unmapped code, gate surfaces (tier 3): the full registry.
   125	
   126	Promotion always runs the full registry. Eight skill-text suites are off, recorded in
   127	`test/gh306-registry-bidirectional.sh`'s EXEMPT list, and no new suites are added (AGENTS.md). The code of
   128	core skills (`relay`, `relay-xyz`, `relay-automation`, `merge-cleanup`, `express`, `jog`) never routes as
   129	docs. Skill markdown keeps its existing docs routing, except that `relay-xyz` and `relay-automation` stay
   130	full-gate surfaces for every file. merge-cleanup's `SKILL.md` and `WORKTREE-SAFETY.md` are full-gate files too:
   131	they are what `gh436-merge-cleanup` reads, and GH-836 D1 moved that suite from Small to Large.
   132	Plan: [GH-831](PROJECT/2-WORKING/GH-831-THREE-TIER-GATE.md).
   133	
   134	`--burst` / `XYZ_VALIDATE_MAX_JOBS` are honoured for tier 2: 2 is the default width, not a pin.
   135	Run one gate at a time on a host: a concurrent relay turn, second gate or pollers lengthen the run
   136	(`nice` protects the editor, not the wall-clock).
   137	
   138	**What still qualifies a claim is unchanged.** `./validate.sh` in either mode is a self-check;
   139	`ci-local.sh` is the run that writes the evidence record, it does **not** call `validate.sh`, and it
   140	stays sequential. The macOS promotion boundary in `ci.yml` pins `--sequential` explicitly for the same
   141	reason. GH-528 Phase 2 (multi-width stress evidence) is still **owed** — the flip was an operator
   142	decision taken with that evidence outstanding, mitigated by the announced fallback rather than
   143	discharged. See `PROJECT/2-WORKING/GH-528-TEST-SUITE-RECALIBRATION.md`, #509 and #544.
   144	
   145	For document hygiene:
   146	
   147	```bash
   148	utils/pdda/pdda.sh run
   149	```
   150	
   151	For targeted PDDA debugging (subcommands of the single dispatcher):
   152	
   153	```bash
   154	utils/pdda/pdda.sh frontmatter
   155	utils/pdda/pdda.sh status-table
   156	utils/pdda/pdda.sh hardcoded-paths
   157	utils/pdda/pdda.sh roadmap
   158	utils/pdda/pdda.sh roadmap-coverage
   159	utils/pdda/pdda.sh changelog
   160	utils/pdda/pdda.sh stale
   161	utils/pdda/pdda.sh issue-doc-sync   # warn-only: flags 2-WORKING/GH-*.md docs drifted from their GitHub issue state
   162	utils/pdda/pdda.sh releases         # legacy releases check (skips when RELEASES.md is retired)
   163	utils/pdda/pdda.sh releases-current # read-only roll-up: queries releases.db (GH-568)
   164	utils/pdda/pdda.sh quad-concepts    # opt-in: requires a "## Quad Concepts" section of 1-4 bullets (lever: .pdda-quad / PDDA_QUAD)
   165	utils/pdda/pdda.sh glance           # read-only roll-up: title + Quad Concepts for each PROJECT/2-WORKING doc
   166	utils/pdda/pdda.sh governance       # repo-root governance-doc cross-reference + doc/code drift
   167	utils/pdda/pdda.sh marathon-qa      # mechanical marathon Wave QA receipt & checklist gate (GH-784)
   168	utils/pdda/pdda.sh gh-refresh       # refresh the cached GitHub issue-state file issue-doc-sync reads offline (needs gh)
   169	utils/pdda/pdda.sh catchup          # LLM repo triage + ROUTER.md recommendations (delegates to pdda-catchup.sh)
   170	utils/pdda/pdda.sh doc-ready        # LLM readiness review — set PDDA_LLM_BIN (codex/claude/agy) for recommendations, else it self-skips
   171	```
   172	
   173	## The RELEASES DB — two subsystems, one ledger (GH-32 / GH-69)
   174	
   175	`releases.db` + `releases.sql` hold TWO mirrored subsystems, both operated through ONE CLI,
   176	`utils/py/releases_app.py` (alias: the `/releases` skill). Read
   177	[RELEASES-DB-FAQS.md](RELEASES-DB-FAQS.md) before merging either file — the SQLite binary is
   178	derived; the SQL dump is what git actually merges, and a conflicted merge has a one-command
   179	resolver (`utils/releases-merge-resolve.sh`).
   180	
   181	```bash

exec
/bin/zsh -lc "nl -ba skills/2-daily/merge-cleanup/scripts/merge_cleanup.py | sed -n '1,85p'; rg -n 'argparse|primary|strategy|prs-only|reconcile-pr|merge_pr|--match-head|gh.*merge|landing_clone' skills/2-daily/merge-cleanup/scripts/merge_cleanup.py" in /private/var/folders/69/3l_82qtj7fzglnt_jjg07jh40000gn/T/consult-wt-43891-m8ixsws8
 succeeded in 0ms:
     1	#!/usr/bin/env python3
     2	"""merge_cleanup.py — Master orchestrator for the /merge-cleanup skill.
     3	
     4	Implements the 6-phase ladder:
     5	1. Discover & Inventory checkouts.
     6	2. Active Process & Session Inspection.
     7	3. Git Safety & Worktree Verification.
     8	4. PR Matrix & Topological Sorting.
     9	5. Safe Execution & Post-Merge Reconciliation.
    10	6. Safe Teardown conforming strictly to WORKTREE-SAFETY.md.
    11	"""
    12	
    13	import json
    14	import re
    15	import os
    16	import sys
    17	import argparse
    18	import subprocess
    19	import shutil
    20	import time
    21	from pathlib import Path
    22	from typing import List, Dict, Any, Optional, Tuple
    23	
    24	from scan_clones import (
    25	    DEFAULT_SAFE_ROOTS,
    26	    DEFAULT_NEVER_DELETE,
    27	    is_safe_deletable_path,
    28	    scan_directories,
    29	    inspect_checkout,
    30	    inspect_primary_landing,
    31	    format_primary_landing,
    32	    format_scan_table,
    33	    format_completion_and_followup_summary,
    34	    format_issue_marker_body,
    35	    resolve_canonical_issue,
    36	    run_git
    37	)
    38	from toposort_prs import (
    39	    fetch_open_prs,
    40	    toposort_prs,
    41	    format_pr_table,
    42	    FetchError,
    43	)
    44	from scan_clones import GH_BIN_ENV
    45	import attempt_record
    46	import ledger_merge
    47	from ledger_merge import (
    48	    LEDGER_DUMP,
    49	    pre_merge_ledger_gate,
    50	    resolve_ledger_conflict,
    51	    tool_path,
    52	)
    53	import json
    54	import tempfile
    55	
    56	# Labels that mean "do not land this" (#444): the merge loop never touches a PR carrying one.
    57	HOLD_LABEL_TOKENS = ("hold", "do not merge", "do-not-merge", "blocked", "wip")
    58	HOSTED_WAIT_ENV = "MERGE_CLEANUP_HOSTED_WAIT_S"
    59	HOSTED_POLL_ENV = "MERGE_CLEANUP_HOSTED_POLL_S"
    60	# GH-629: the run for a just-pushed head can take a few seconds to appear in `gh run list`; an
    61	# empty answer inside this window is "not yet", not "no hosted workflow". Only after it elapses
    62	# does an empty list select the local writer.
    63	HOSTED_GRACE_ENV = "MERGE_CLEANUP_HOSTED_GRACE_S"
    64	
    65	
    66	def _gh_bin() -> str:
    67	    return os.environ.get(GH_BIN_ENV) or "gh"
    68	
    69	
    70	def _gh(args: List[str], cwd: Path, timeout: int = 180) -> subprocess.CompletedProcess:
    71	    try:
    72	        return subprocess.run([_gh_bin()] + args, cwd=str(cwd), capture_output=True, text=True, check=False, timeout=timeout)
    73	    except (OSError, subprocess.TimeoutExpired) as exc:
    74	        return subprocess.CompletedProcess(args=args, returncode=127, stdout="", stderr=str(exc))
    75	
    76	
    77	# --- GH-623: network resilience — bounded calls, transient-only retry, defer instead of stop ----
    78	# The incident run lost 3 of 7 PRs to one DNS failure and never retried anything. The contract,
    79	# pinned by TestGh623Resilience: a TRANSIENT network failure is retried 3 times total (sleeps of
    80	# 2s then 4s between the three calls) and, at the two pre-decision call sites, DEFERS that one PR
    81	# while the rest of the queue continues; anything non-transient stops exactly as before. A hung
    82	# call reaches this machinery because every retry-site git call is bounded in time (_net_git).
    83	
    84	RETRY_ATTEMPTS = 3
    85	RETRY_BACKOFF_S = (2, 4)      # sleeps BETWEEN attempts: 3 calls, 2 sleeps
17:import argparse
30:    inspect_primary_landing,
31:    format_primary_landing,
150:def execute_pr_merge(pr_num: int, repo_path: Path, strategy: str = "squash", dry_run: bool = True) -> bool:
156:        log(f"[DRY RUN] Would merge PR #{pr_num} via `gh pr merge {pr_num} --{strategy}{delete_text}`")
159:    merge_args = ["pr", "merge", str(pr_num), f"--{strategy}"]
162:    log(f"Merging PR #{pr_num} via `gh {' '.join(merge_args)}`...")
163:    res = _gh(merge_args, repo_path, timeout=600)
165:        # GH-852: gh can fail or be killed after GitHub has merged (#810). Only GitHub's own
170:            log_warn(f"`gh pr merge` exited {res.returncode} but PR #{pr_num} reads MERGED as {oid[:10]} — continuing")
181:    log_err(f"PR #{pr_num}: `gh pr merge` exited 0 but the PR does not read MERGED on re-query — treating as failed")
287:def prepare_landing_clone(pr: Dict[str, Any], primary_repo: Path, integration_branch: str,
292:    url = origin_url(primary_repo)
294:        return {"clone": None, "merge_rc": None, "error": "primary has no origin remote"}
324:def validate_head_in_second_clone(primary_repo: Path, source_clone: Path, sha: str, workdir: Path) -> Tuple[bool, str]:
327:    url = origin_url(primary_repo)
352:def push_resolved_head(pr: Dict[str, Any], clone: Path, sha: str, primary_repo: Path) -> Tuple[bool, str]:
354:    live = refresh_pr(pr["number"], primary_repo)
395:    source for `merged` is the caller's `if merged:` — a `gh pr merge` whose PR then reads MERGED
396:    with a merge commit, whether gh exited 0 or failed after GitHub had merged (GH-852).
398:    Deliberately NOT emitted from --reconcile-pr. That mode now verifies the PR is MERGED before
467:    seen_ours = None    # the in-flight run was identified by this merge's SHA, not adopted unidentified
571:    `merged_head`, when given, is the PR's merge commit as GitHub reports it (--reconcile-pr);
572:    otherwise the primary's HEAD, which the Phase-5 fast-forward has just moved to the merge."""
632:    """Commit, push, and verify every primary-side write made after a PR lands."""
663:        log_err(f"PR #{pr_num}: post-merge durability check failed — primary must be clean and match origin/{integration_branch}")
665:    log(f"✅ PR #{pr_num} post-merge writes committed; primary is clean at origin/{integration_branch}")
676:def refresh_for_teardown(checkouts: List[Dict[str, Any]], primary_repo: Path,
685:        info = inspect_checkout(Path(c["path"]), primary_repo_path=primary_repo, exclude_patterns=excludes,
837:def _await_mergeable(p_num: int, info: Dict[str, Any], primary_repo: Path) -> Dict[str, Any]:
850:        info = refresh_pr_with_retry(p_num, primary_repo)
854:def land_prs(ordered_prs: List[Dict[str, Any]], primary_repo: Path, args, dry_run: bool) -> int:
861:    origin = origin_url(primary_repo) or ""
866:        coordinator = attempt_record.record_path(primary_repo, origin, 0).parent
896:            info = refresh_pr_with_retry(p_num, primary_repo)
919:            info = _await_mergeable(p_num, info, primary_repo)
938:            prep = prepare_landing_clone(info, primary_repo, branch, workdir)
958:                    record_path = attempt_record.record_path(primary_repo, origin, p_num)
973:                # C: one durable attempt record at the pinned coordinator (the --primary path),
975:                record = attempt_record.record_path(primary_repo, origin, p_num)
1018:                ok, why = validate_head_in_second_clone(primary_repo, clone, b1["commit"], workdir)
1023:                ok, why = push_resolved_head(info, clone, b1["commit"], primary_repo)
1036:                info = refresh_pr_with_retry(p_num, primary_repo)
1044:                    info = refresh_pr_with_retry(p_num, primary_repo)
1049:                info = _await_mergeable(p_num, info, primary_repo)
1062:                prep = prepare_landing_clone(info, primary_repo, branch, workdir)
1082:                log(f"[DRY RUN] Would merge PR #{p_num} via `gh pr merge {p_num} --{args.strategy} --delete-branch`")
1084:            live = refresh_pr_with_retry(p_num, primary_repo)
1097:            _protect_stacked_dependents(info, open_prs, primary_repo, branch)
1098:            if not execute_pr_merge(p_num, primary_repo, strategy=args.strategy, dry_run=False):
1100:            # Land it locally before anything writes into the primary. In particular, emitting
1103:            fetched = _retry_call(lambda: _net_git(primary_repo, ["fetch", "origin", branch]),
1108:            ff = run_git(primary_repo, ["merge", "--ff-only", f"origin/{branch}"])
1111:                log_err("PR is merged remotely but the primary did not advance — reconcile by hand.")
1114:                    p_num, primary_repo, integration_branch=branch, dry_run=False,
1118:            # GH-549/GH-624: report only after the merge, primary fast-forward, and reconcile
1121:            emit_pr_merged(primary_repo, pr, dry_run=False)
1122:            if not commit_and_push_phase5_writes(p_num, primary_repo, branch):
1151:def prepare_primary_landing(primary_repo: Path, args) -> Dict[str, Any]:
1152:    info = inspect_primary_landing(primary_repo, integration_branch=args.integration_branch)
1157:        result = run_git(primary_repo, ["update-ref", "-d", "REBASE_HEAD", oid])
1161:        log_warn(f"pruned orphaned REBASE_HEAD {oid}; rechecking primary readiness")
1162:        return inspect_primary_landing(primary_repo, integration_branch=args.integration_branch)
1172:    parser = argparse.ArgumentParser(
1175:    # C: the primary is the coordinator of the attempt record and the target of every landing.
1178:    parser.add_argument("--primary", required=True, help="Path to the primary working repo (required; never inferred from the CWD)")
1182:    parser.add_argument("--strategy", choices=["squash", "merge", "rebase"], default="squash", help="PR merge strategy")
1184:    parser.add_argument("--prs-only", action="store_true", help="Only list and sequence open PRs")
1186:    parser.add_argument("--reconcile-pr", type=int, default=0, help="Run post-merge reconcile on a specific PR number")
1187:    parser.add_argument("--integration-branch", default="development", help="Branch PRs land on and the primary must be able to fast-forward (default: development)")
1189:    parser.add_argument("--allow-unready-primary", action="store_true", help="Explicitly defer primary-checkout cleanup and proceed even though the primary cannot receive the landing")
1198:        primary_repo = Path(args.primary).expanduser().resolve()
1199:        ledger_merge.TOOL_FALLBACK_ROOT = primary_repo
1201:        log_err(f"cannot resolve the primary path {args.primary!r}: {exc}")
1206:    log(f"Operating on primary repo: {primary_repo}")
1210:    # Phase 0: the primary on-disk checkout, before ANY other mode dispatches. It receives every
1212:    # detail discovered at merge time. This must stay above --reconcile-pr: that mode launches
1215:    primary_landing = prepare_primary_landing(primary_repo, args)
1219:    print(format_primary_landing(primary_landing) + "\n")
1221:    def _primary_blocks(action: str) -> bool:
1222:        """True when `action` must be refused because the primary cannot receive it."""
1223:        if primary_landing["landing_ready"] or args.allow_unready_primary or dry_run:
1225:        log_err(f"REFUSING to {action}: the primary checkout cannot receive the landing.")
1226:        for b in primary_landing["blockers"]:
1228:        log_err("Fix the primary first, or pass --allow-unready-primary to proceed anyway.")
1233:        if _primary_blocks("reconcile"):
1236:        # primary's HEAD; a PR GitHub does not report as merged has nothing to reconcile.
1237:        info = refresh_pr_with_retry(args.reconcile_pr, primary_repo)
1246:            args.reconcile_pr, primary_repo,
1252:    checkouts = scan_directories(search_roots, prefix_filter=args.prefix, primary_repo=primary_repo, excludes=args.exclude, integration_branch=args.integration_branch)
1271:                if post_issue_marker(primary_repo, issue_num, body, dry_run=dry_run):
1286:        prs = fetch_open_prs_with_retry(str(primary_repo))
1308:        if not primary_landing["landing_ready"]:
1310:                "This sequence is NOT executable as things stand: the primary checkout cannot "
1330:        log("Refreshing remote refs before the first merge, then re-checking the primary...")
1333:        # existing --allow-unready-primary override still applies unchanged.
1334:        fetched = _retry_call(lambda: _net_git(primary_repo, ["fetch", "origin", args.integration_branch]),
1336:        if fetched.returncode != 0 and not args.allow_unready_primary:
1344:            log_err("Fix the remote access, or pass --allow-unready-primary to proceed on stale evidence.")
1346:        primary_landing = prepare_primary_landing(primary_repo, args)
1347:        print(format_primary_landing(primary_landing) + "\n")
1363:    # teardown-only. The operator — not the skill — owns any decision to leave the primary
1365:    if _primary_blocks("execute cleanup"):
1372:        rc = land_prs(ordered_prs, primary_repo, args, dry_run)
1384:    fresh = refresh_for_teardown(checkouts, primary_repo, excludes=args.exclude, integration_branch=args.integration_branch)
1392:            backup_root = Path(args.backup_root).resolve() if args.backup_root else primary_repo.parent / "_backups"
1398:                repo_name=primary_repo.name,

codex
The plan keeps the full-range review and exact-main hosted qualification. Its main gaps are an executable path around the coordinator’s primary-side push and the ordering of evidence commits versus candidate qualification. I’ll check those before assigning severity.
exec
/bin/zsh -lc "nl -ba AGENTS.md | sed -n '306,338p;350,375p;411,440p'; nl -ba ROUTER.md | sed -n '66,91p'; nl -ba .github/workflows/ci.yml | sed -n '54,100p;240,263p'; nl -ba PROJECT/3-COMPLETED/GH-822-PROMOTION.md | sed -n '1,160p'" in /private/var/folders/69/3l_82qtj7fzglnt_jjg07jh40000gn/T/consult-wt-43891-m8ixsws8
 succeeded in 0ms:
   306	  pathless trailer is still rejected everywhere.
   307	- **Builder/orchestrator role split (GH-221)** — **Claude Code (terminal and VS Code agents) is the
   308	  orchestrator and reviewer, never a default builder.** It plans, dispatches marathon/relay lanes, and
   309	  reviews/verifies their output; it does not drive itself headlessly as a build lane. **Agy CLI and
   310	  Codex CLI are the builders** — the two cost-blind (subscription-billed) headless build lanes
   311	  `marathon.sh`/`marathon-drive.sh` default to (GH-212). **Claude CLI (subscription or API, according to its authentication route) is
   312	  NOT a builder by default** — `--builder claude` stays fully supported, but only as an explicit,
   313	  usage-acknowledged choice the *user* makes locally (their own `--builder claude` flag or a local
   314	  settings override), never something a session reaches for on its own reasoning that it's "just
   315	  another supported builder option." If a task calls for a headless build lane and neither agy nor
   316	  codex is available, stop and ask — don't default to spawning a headless Claude CLI turn.
   317	
   318	  **As the orchestrator, you are the final outer reviewer of any emitted artifact (e.g., an automated PR).**
   319	  You must treat an automation's emission as an event requiring inspection, not as an automatic success.
   320	  Before permitting an automated loop to proceed to its next iteration, you must query and verify the emitted PR:
   321	  1. **Base Branch Sanity:** The PR targets the active WIP branch (`development`), not `main`.
   322	  2. **Diff Size Sanity:** The diff size matches the logical scope of the fix (e.g. < 500 lines for targeted bugs).
   323	  3. **Verification Status:** A test gate ran against the final committed state (either CI or a local `validate.sh` run).
   324	  **Halt Condition:** If an emitted artifact fails any of these predicates, you must suspend the automation loop immediately.
   325	
   326	  **Orchestrator vs. Review Protocol Separation (GH-784):** The Orchestrator (the dispatch/tool driver) cannot self-satisfy the review contract or attest review solely by observing passing test suites. It must mechanically invoke an independent peer/Codex QA turn (`relay-xyz` / `/start-task` Step 8 parity) with recorded receipts under `relay-system/<YYYY-MM-DD>/<label>.codex.md` before approving or signing off on PR creation or promotion. Self-review or test-only observation does not satisfy the Wave QA receipt gate.
   327	- **HQ (multi-repo command center)** — for cross-repo tasking (resolve a project → land intake on its
   328	  own PDDA rails → prepare dispatch), drive `utils/hq/hq.sh` via the `/hq` skill rather than hand-editing
   329	  another repo's docs. Full command surface (`status`/`resolve`/`next`/`park`/`promote`/`queue`/`fire`),
   330	  install, and the resolution ladder and agent-facing invocation flow + guardrails are in [skills/2-daily/hq/SKILL.md](skills/2-daily/hq/SKILL.md). Write paths preview by default; `fire` never drives the harness.
   331	- Changes to `.tick/events/`, `src/project.js`, relay containment, or event/verb shape are usually
   332	  broader than they look. Treat them as at least Costly until proven otherwise.
   333	- **Contain tree-touching subagents with `isolation: "worktree"` (GH-177/GH-233).** A Claude Code
   334	  session spawning Agent/Workflow subagents that will *modify files* in this repo should pass
   335	  `isolation: "worktree"` so a runaway destructive command shreds a disposable checkout, not the main
   336	  tree (this repo has been wiped twice — see
   337	  `PROJECT/3-COMPLETED/GH-177-MKTEMP-TRAP-REPO-WIPE.md`). Know what it does NOT protect: worktrees
   338	  share `.git` objects/refs, so destructive *git* operations (`update-ref`, `branch -D`, resets,
   350	- **Run the suite in a SEPARATE FULL CLONE, never in a clone whose state you care about — and a
   351	  linked worktree is NOT a way around it (GH-564).** `validate.sh` and `test/*.sh` can write to the
   352	  git config, remotes, and refs of the repository they are invoked from. On 2026-08-15 the primary
   353	  clone was contaminated **twice in one morning**: `core.bare=true`, `remote.origin.url` repointed at
   354	  a fixture bare repo, a fixture `[user]` identity appended, and `refs/heads/development` reset onto
   355	  ~35 fixture commits. It also **defeated the push gate while corrupting it** — pushes failed with
   356	  `'/var/folders/…/bare.XXXXXX' does not appear to be a git repository` because the suite repointed
   357	  `origin` mid-hook.
   358	  - **The worktree precaution was taken and it FAILED.** Both bursts came from `./validate.sh` run in
   359	    linked worktrees cut off the primary clone, chosen specifically to isolate the risk. **Linked
   360	    worktrees share `.git/config` with the parent clone**, so an escape landing in a worktree's CWD
   361	    writes the parent's config. Reproduced deterministically: from a worktree CWD, `r=""; git -C "$r"
   362	    remote set-url origin "$b"` rewrote the *parent* clone's origin. Same structural fact the
   363	    driver-lock matrix documents from the other side (GH-42/GH-354/GH-448) — a linked worktree
   364	    resolves to the parent's `git-common-dir`, which is why it grants no second lane either.
   365	  - **State the boundary precisely, because the previous rail's version was too narrow.** The rail
   366	    above says worktree isolation does not protect against destructive *git operations*. That is
   367	    true and insufficient: a worktree isolates the **working tree only**. Everything reached through
   368	    `.git` — config, remotes, refs, objects, hooks — is shared with the parent clone, whether it is
   369	    touched deliberately or by an escaped fixture. Only a **separate full clone** isolates any of it.
   370	  - **Why it escapes at all:** `git -C ""` is documented to leave the working directory unchanged and
   371	    `cd ""` is a bash no-op, and these suites run without `set -e` — so one unguarded
   372	    `r="$(mktemp -d …)"` silently redirects every "fixture" operation onto the caller's clone. It
   373	    fires under **parallel** load (the failure mode of `mktemp`), which is why a serial re-run of the
   374	    same suite reproduces nothing and must not be read as an all-clear. GH-177 family.
   375	  - **Until #564's suite-wide invariant gate lands**, treat any clone you ran the suite in as
   411	    [GH-195-MARATHON-ROOT-AUDIT-BLIND-SPOT.md](PROJECT/3-COMPLETED/GH-195-MARATHON-ROOT-AUDIT-BLIND-SPOT.md).
   412	- **The local macOS run is the gate; hosted ubuntu is advisory (GH-509).** XYZ is a developer toolkit
   413	  for **macOS**; Linux and Windows are on the roadmap and not here yet. So `./validate.sh` (or
   414	  `./ci-local.sh`) on your Mac is the highest-fidelity evidence available — it is the shipping
   415	  platform with the real toolchain. Operator-retired suites stay out of both runners;
   416	  their retained manual files are listed in gh306 EXEMPT (GH-854). The hosted `canary-ubuntu`
   417	  job is `continue-on-error: true`: its red means *portability drift*, not breakage, and must not be
   418	  reported as a broken commit. Two consequences that bite: **never defer a test run to CI** — CI is
   419	  advisory and tests the wrong OS; and **a green local run is self-reported**, so it does not qualify a
   420	  promotion. Two hosted **macOS** rules follow (GH-831): a landing on `development` is qualified by the
   421	  reconcile run its tier selects (the tiers are in `ROUTER.md`), and promotion needs a hosted
   422	  full-registry run for that exact commit. When a claim really is about
   423	  Linux, the canary is the right instrument and its red is authoritative.
   424	- **Commit to the QUEUE; re-anchor, don't rabbit-hole (GH-45).** A wave's committed lane list *is* the
   425	  active commitment — after each lane attempt, re-read it before acting further. A driven lane that
   426	  fails **parks** after `LANE_MAX_ATTEMPTS` (default 2): the driver (`marathon-drive.sh` /
   427	  `relay-drive.sh`) refuses to re-fire it (exit 8, no token), you capture the findings as an issue and
   428	  stop. Re-firing a parked lane or going off-wave to deep-dive one item requires an explicit operator
   429	  override (`--force`) or a replan note — never a quiet slide off the plan.
   430	- **Do not create new git branches** automatically. Only create a new branch if explicitly requested by the user. **This governs interactive work only — it is NOT a licence to commit a marathon onto `development`.** The very next bullet is the carve-out: a marathon/relay-fired lane cuts its own `marathon/gh-<n>-*` branch and PRs back into `development`, and that per-lane branch IS the explicitly-requested case. Read 2026-08-15 as permission to skip the branch, which is how four Meter commits landed straight on `development` with no PR (GH-561). The guard now refuses that (`marathon_drive.py`'s branch guard protects `development`, not just `origin/HEAD`), because a rule an agent can talk itself past is not a rule.
   431	- **`development` is the standing WIP branch — ALL work targets it, including marathon/relay-fired lanes (cut fresh from `main` 2026-07-17, [GH-216](https://github.com/Claude-AI-Tools-Ventura-County/xyz-3-agents-swarm/issues/216); policy widened 2026-07-17 to cover marathon lanes too, first applied to [PR #217](https://github.com/Claude-AI-Tools-Ventura-County/xyz-3-agents-swarm/pull/217)).** The prior `development` had drifted 295 commits behind `main` with no open PRs — retired to `development-archived-2026-07-04` rather than deleted outright. Both manual/exploratory work AND marathon-fired lanes (`marathon/gh-<n>-*` branches, GH-212 convention) now branch off `development` and PR back into it — `--plan`/`marathon.sh` still cuts its own short-lived per-lane branch, just off `development` instead of `main`. Periodically merge `development` → `main` once it's in a shippable state; don't let `main` sit behind `development` indefinitely. Watch for `development` drifting stale again the same way the old one did; re-cut from `main` if it does.
   432	- **Anti-pattern: renaming a branch with an open PR via GitHub's branch-rename API
   433	  (`POST /repos/{owner}/{repo}/branches/{branch}/rename`, or `gh api ... branches/<old>/rename`).**
   434	  It does **not** rename in place — it deletes the old ref and recreates a new one, which GitHub
   435	  treats as `head_ref_deleted` and **auto-closes the open PR** pointed at that branch (found
   436	  2026-07-10 renaming a branch backing PR #193; recovered by opening a new PR from the renamed
   437	  branch and pointer-commenting the closed one). If a branch needs a new name and has an open PR:
   438	  either rename it *before* opening the PR, or accept that renaming after will require re-opening a
   439	  fresh PR — don't assume the PR follows the rename.
   440	- **Aider Configuration (AIDER.md / GH-77)**: When using Aider as a headless runner against OpenRouter, do not hardcode the API key or attempt to use a secrets manager. The `OPENROUTER_API_KEY` is securely stored at `~/secrets/openrouter/openrouter.txt` and is exported dynamically by `~/.zshrc`.
    66	
    67	```bash
    68	bash githooks/install.sh        # ONCE PER CLONE — wires the pre-push gate (GH-544)
    69	bash githooks/install.sh --check # is this clone gated? exit 1 if not
    70	./validate.sh              # the gate — PARALLEL by default (GH-544), auto-sized to the host (GH-35)
    71	./validate.sh --print-mode # which mode would this host pick, and why — runs nothing
    72	./validate.sh --sequential # force the sequential run (see the hook’s measured GREEN in Ns line)
    73	./validate.sh --tier 2 --subsystem hq   # GH-35: one subsystem's focused suites (pre-push speed, NOT evidence)
    74	./validate.sh --sequential --subsystem small  # GH-831: the Small list — locally a self-check; hosted, the reconcile's qualifying run for docs/ledger/skill landings
    75	./validate.sh --auto       # GH-35: classify the git diff, run the minimal safe tier (fails closed to 3)
    76	./validate.sh --throttle   # GH-35: 2 workers under nice — quiet-machine mode (--burst restores full width)
    77	bash ci-local.sh           # the QUALIFYING run — sequential + writes the gate record (GH-509/GH-536)
    78	```
    79	
    80	**Both gate entry points refuse to run from a linked git worktree (GH-45)** — a worktree shares
    81	the parent clone's `.git`, and an observed suite escape corrupted the parent (core.bare, origin,
    82	remote refs, development). Run the gate from a separate disposable full clone; `XYZ_ALLOW_WORKTREE_GATE=1` is the
    83	announced override for disposable runs.
    84	
    85	**Local push checks and hosted CI both apply.** This repository is public; the workflow covers
    86	pushes and pull requests to `main` and `development`. Hosted macOS promotion evidence requires an
    87	actual passing run for the exact commit; the Ubuntu canary remains advisory. Install the local
    88	hook with `githooks/install.sh` for each clone — `.git/hooks/` does not travel with a clone. One
    89	installation covers that clone’s branches and linked worktrees. Run mutation-heavy gates and
    90	pushes that invoke them from a separate disposable full clone, as required by AGENTS.md.
    91	Bypasses (`git push --no-verify`, `XYZ_SKIP_PREPUSH=1`) announce that the local gate was skipped.
    54	#
    55	#    The lesson is structural, not about that one file: when this job is red, open the JOB and look
    56	#    for steps marked `-`. A short green run is the symptom to distrust. Steps here are ordered
    57	#    cheapest-first, so an early failure hides the most.
    58	#
    59	#    Run 32504570094 (2026-08-21, against 02ce229) is the first end-to-end execution. Baseline:
    60	#    shellcheck / bash+node syntax / settings JSON / PDDA gate / acorn-extract all PASS on Linux;
    61	#    7 assertions across 5 suites fail. Tracked in GH-123 — read it before assuming any of them is
    62	#    environment noise, and see the GH-232 note further down for why that assumption is expensive.
    63	#
    64	#    THIS IS STILL TRUE NOW THAT THE AUTOMATIC TRIGGERS WORK, and that is the point. Runs
    65	#    32506672733 (`pull_request`) and 32506697196 (`push` on `development`) both concluded
    66	#    **success** while this job concluded **failure** on the same 7 assertions. So the trap did not
    67	#    end with the outage in note 1 — restoring the triggers restored a green checkmark on every PR
    68	#    that is reporting a red canary underneath it. Until GH-123 is cleared, treat this job's own
    69	#    conclusion as the signal and the run's conclusion as decoration.
    70	#
    71	# GH-216 cut `development` as the WIP branch that all work targets, but these
    72	# triggers stayed pinned to `main` — so no PR into `development` ran CI at all.
    73	# Both branches are gated here; add any future long-lived integration branch too.
    74	# ── HOSTED CI RE-ARMED FOR THE PUBLIC REPOSITORY (XYZ-forge #16, 2026-08-17) ─────────────────────
    75	#
    76	# GH-544 deliberately removed `push:` and `pull_request:` while the source repository was private.
    77	# That bridge had one explicit end condition: the repository becomes public. HiQS-Labs/XYZ-forge
    78	# is public, so automatic triggers are restored here. The local pre-push gate remains useful as the
    79	# earliest signal; hosted CI restores independent attestation and the Linux portability canary.
    80	#
    81	# WHY: measured in #509/#528 — Aug 1-14 cost $21.99 gross / $10.00 billed, exhausting the 2,000
    82	# included minutes on Aug 11 and hitting the $10 spending limit on Aug 14, which blocked Actions
    83	# outright. Projection at that cadence was ~$47/mo gross. We do not pay that for an internal tool.
    84	#
    85	# THE BRIDGE HAS ENDED. The re-arm keeps the constraints the private-phase analysis established:
    86	#   1. `push:` and `pull_request:` cover main and development. The macOS job itself remains guarded
    87	#      to a push on main; GH-347 moved the Ubuntu portability canary to push-on-development plus
    88	#      deliberate dispatch, so pull requests complete without paying for an advisory full suite.
    89	#   2. Expect a BATCH of accumulated Linux portability drift on the first green-field run. The local
    90	#      gate is macOS, so the platform we ship to stayed covered — the ubuntu canary did not, and drift
    91	#      has been accumulating unreported since this date. That backlog is the known, accepted cost of
    92	#      this decision, not a surprise.
    93	#   3. The GH-509 macOS boundary is again the promotion witness for an exact main commit.
    94	#
    95	# EVERYTHING BELOW IS DELIBERATELY PRESERVED — jobs, routing, and especially the GH-509 Phase 4 cost
    96	# analysis in the macOS job's header. That reasoning is what you will want when re-arming; deleting it
    97	# and rediscovering it on an invoice is the failure this comment exists to prevent.
    98	on:
    99	  push:
   100	    branches: [main, development]
   240	  # elsewhere: the canary's status is a line in the promotion output, consulted at the moment a human
   241	  # is already deciding something. If two consecutive promotions ship with drift named and unresolved,
   242	  # this job has proven it is not being actioned and should be deleted rather than kept as decoration.
   243	  canary-ubuntu:
   244	    name: portability canary (ubuntu — advisory, never breakage)
   245	    # GH-347: integration-time signal, not PR feedback. A development push is the last recurring
   246	    # point before promotion where this drift can be acted on; workflow_dispatch is the deliberate
   247	    # fallback. Push-to-main is after the promotion decision, and pull_request was the 8m54s long pole.
   248	    if: >-
   249	      (github.event_name == 'push' && github.ref == 'refs/heads/development') ||
   250	      github.event_name == 'workflow_dispatch'
   251	    runs-on: ubuntu-latest
   252	    continue-on-error: true
   253	    steps:
   254	      - name: Check out repo
   255	        uses: actions/checkout@v7
   256	        with:
   257	          # GH-232: several tests (e.g. xyz-vendor.sh's staleness check) use `git rev-list
   258	          # --max-parents=0 HEAD` to synthesize an "older" ancestor commit for a fixture. The
   259	          # default shallow clone (depth 1) makes the boundary commit look parentless, so it
   260	          # resolves to the SAME commit as HEAD — silently defeating the fixture, not a real bug.
   261	          fetch-depth: 0
   262	
   263	      - name: Classify CI route
     1	---
     2	title: "GH-822: 2026-09-25 post-merge review — promote development to main and publish 0.9.0 Cargo"
     3	status: Complete
     4	gh_issue: 822
     5	source: https://github.com/HiQS-Labs/XYZ-forge/issues/822
     6	doc_type: feedback
     7	created: 2026-09-25
     8	updated: 2026-09-25
     9	owner: operator (via /start-task)
    10	goal: >
    11	  Promote development to main with GH-509 hosted macOS evidence for the exact commit, then publish the
    12	  ledger's 0.9.0 "Cargo" as the first GitHub Release on that commit.
    13	related:
    14	  - "#823 / PR #824 — boundary-macos cap 45 -> 120 (the one code blocker), merged 61f09827"
    15	  - "#796 — integration batch whose landings (#794, #795, #765) the review covered"
    16	  - "#105 — 0.9.0 Cargo tracking issue"
    17	---
    18	
    19	# GH-822 — promote development to main and publish 0.9.0 Cargo
    20	
    21	## Status
    22	
    23	| What was just completed | What's next |
    24	|---|---|
    25	| `main` fast-forwarded `29144118..a076b1b1` (full pre-push gate green; `enforce_admins` restored, protection identical to the snapshot). `boundary-macos` went green on the exact SHA: `MACOS-BOUNDARY: green a076b1b1`, `validate.sh --sequential` 422/422 in 78 min (CI run 36184841355). GitHub Release [0.9.0 "Cargo"](https://github.com/HiQS-Labs/XYZ-forge/releases/tag/0.9.0) published on `a076b1b1` as Latest; the ledger write-back (GH_URL plus `shipped` 2026-09-25) is in this PR. | Merge this write-back PR; the hosted reconciler closes #822 and moves this doc to 3-COMPLETED. The next promotion follows the same steps. |
    26	
    27	## Scope
    28	
    29	The review itself lives in [#822](https://github.com/HiQS-Labs/XYZ-forge/issues/822): the last-12-hour merges are
    30	compatible, with no conflicts and no regressions found. It named two promotion blockers, #823 (done) and a
    31	GH-784 promotion QA receipt (`AGENTS.md:302`, this PR). Operator decisions on 2026-09-25:
    32	
    33	- **Recut `main` from `development`.** Old `main` (`29144118`) is a strict ancestor with no commits of its own,
    34	  so a fast-forward push gives the same result as deleting and recreating it.
    35	- **Publish a GitHub Release, not a bare tag**, through the `/releases` Publish subroutine, as 0.9.0 "Cargo"
    36	  after trimming its unfinished items.
    37	
    38	## Cargo trim (ledger, this PR)
    39	
    40	The manifest had 6 `dialed_in` items; the rest were already shipped or cut. **Applied on this branch** after the
    41	promotion QA approved the plan, and read back with `releases show`; `releases check` is clean:
    42	
    43	- #663 was closed as completed on 2026-09-17 by `4481ab48` (`fix(GH-663)`), so it was marked `shipped` with that evidence.
    44	- #342, #255, #256, #275 and #345 are still open, so they were **cut** from Cargo and **dialed into 0.6.0 "Front-Door"**,
    45	  the next unshipped release after Cargo by target date (`releases next`). Cargo now has no `dialed_in` items.
    46	
    47	The exit criterion (a vendored repo runs `releases init/add` and `export_timeline.py --preview` from `.xyz/`,
    48	and `xyz-sync.sh update` preserves its ledger) is covered by gh105-vendor-releases-addon, gh107-timeline-json-seam,
    49	gh103-timeline-exporter, gh349-releases-roadmap-vendored, gh197-vendor-tier-split and gh312-vendor-preserves-state.
    50	All six passed in the 2026-09-25 qualifying `ci-local.sh` run on `9ab269c8`.
    51	
    52	## Promotion steps: executed 2026-09-25 (historical record; do not re-run for 0.9.0)
    53	
    54	Results of each step below:
    55	
    56	1. `P` = `a076b1b117a68252dc3d9d1c4901b0c31fcb4db3`, the reconciled tip after #826. No other merges landed in the window.
    57	2. `main` was fast-forwarded `29144118..a076b1b1` at 20:16:49Z behind a green full pre-push gate. `enforce_admins` was off from
    58	   19:57:52Z to 20:16:49Z and restored; `enabled: true` was verified, and the protection matched its snapshot.
    59	3. `MACOS-BOUNDARY: green a076b1b1`: `validate.sh --sequential` 422/422 in 78 min (CI run 36184841355).
    60	4. [0.9.0 "Cargo"](https://github.com/HiQS-Labs/XYZ-forge/releases/tag/0.9.0) was published on `a076b1b1` as Latest at 21:37:16Z. The ledger
    61	   write-back (GH_URL plus `shipped`) landed in the follow-up PR.
    62	5. Not needed: step 3 was green.
    63	
    64	The steps as planned, kept as the template for the next promotion (use a new version, never 0.9.0 again):
    65	
    66	1. Choose the SHA `P` = the `development` tip after this PR's reconcile. Hold other merges until step 3 finishes.
    67	2. `gh api -X DELETE repos/HiQS-Labs/XYZ-forge/branches/main/protection/enforce_admins`, then
    68	   `git push origin P:refs/heads/main`, then **always**, even if the push failed,
    69	   `gh api -X POST repos/HiQS-Labs/XYZ-forge/branches/main/protection/enforce_admins`.
    70	   → expect `main` = `development` = `P`, and
    71	   `gh api repos/HiQS-Labs/XYZ-forge/branches/main/protection/enforce_admins --jq .enabled` prints `true`.
    72	   Do not continue until it does.
    73	3. Watch `boundary-macos` on that push. → expect `MACOS-BOUNDARY: green P` in the job summary.
    74	4. `/releases` Publish: `gh release create <next-version> --target P --title … --notes …` from that release's ledger block, marked
    75	   Latest. Then write back `releases update --gh-release-url` and `releases ship --evidence` in a small follow-up PR.
    76	5. If step 3 is red, do not publish. Fix forward on `development` and promote again; never force-push `main`.
    77	
    78	**Reversibility:** Costly but recoverable. `main` can be moved back only by a force push, which protection
    79	forbids, so a bad promotion is fixed forward. The Release and its tag can be deleted and re-created.
    80	**Blast radius:** nothing in the repo consumes this repo's `main` (the default branch is `development`), and the
    81	Release is the first published.
    82	
    83	## Rating
    84	
    85	`rated 85/55/50/70` (2026-09-25).
    86	
    87	- **Priority 85:** the operator is promoting now.
    88	- **Severity 55:** `main` is 1,799 commits and 5.5 weeks stale, and no Release has ever been published. It blocks
    89	  no development work.
    90	- **Appeal 50:** neutral.
    91	- **Effort 70:** mostly hosted waits and ledger verbs, little code.
    92	
    93	## Merge evidence
    94	
    95	- PR #826 merged 2026-09-25 — linked issue still OPEN; doc stays active by design (GH-202: promotion requires the issue to be closed).

exec
/bin/zsh -lc "rg -n 'push|noop|up.to.date|read |local_sha|remote_sha|new.*commit|exit 0|gate|XYZ_SKIP' githooks/pre-push; nl -ba skills/2-daily/merge-cleanup/scripts/merge_cleanup.py | sed -n '145,183p;1071,1128p'; rg -n 'qualification|stable|SHA|provenance|commit' TESTS-RESULTS/README.md PROJECT/PDDA.md" in /private/var/folders/69/3l_82qtj7fzglnt_jjg07jh40000gn/T/consult-wt-43891-m8ixsws8
 succeeded in 0ms:
2:# pre-push — run the gate before anything reaches the remote. (GH-544)
4:# WHY THIS EXISTS: the push boundary gives the author the earliest complete local signal. Hosted CI
6:# advisory; local commits remain free and ungated on purpose, while a push is checked before it
11:# important choice in this file. A slow pre-push hook risks producing `--no-verify` as a reflex,
12:# and a gate that is routinely bypassed is worth less than no gate, because it also produces
15:# GH-35 added a NARROWER route below the fast gate: a push whose changed paths all map to a
19:# path also routes fast and belongs on the full gate. Every narrower route fails closed to the
23:# writes the gate record. This hook is a guard against pushing something obviously broken, not an
28:# HOW IT IS REACHED: not directly. `install.sh` puts a dispatch stub in `.git/hooks/pre-push` and that
30:# a branch that predates this file still gets gated (the stub falls back to running `validate.sh`),
34:#   git push --no-verify        # native git; cannot be removed, and should not be
35:#   XYZ_SKIP_PREPUSH=1 git push # for automation that has already gated
38:# operator-requested WIP draft may push past this gate only with current focused evidence for the
39:# changed area, the skipped-gate disclosure echoed into the PR description, and merge readiness
40:# still outstanding. A bypassed push never authorises merge, promotion, or teardown.
44:# nothing to gate — but a pre-push hook only ever runs inside a repo, so reaching this branch means
45:# something is wrong, and "something is wrong" must not resolve to "push anyway". Refusing is
46:# recoverable (--no-verify); a silently ungated push is not.
48:  echo "pre-push: cannot resolve the repository root — REFUSING the push rather than skipping the gate." >&2
49:  echo "pre-push:   Override with 'git push --no-verify' if you know why this happened." >&2
53:  echo "pre-push: $REPO/validate.sh is missing or not executable — REFUSING the push." >&2
54:  echo "pre-push:   A gate that cannot run is not a gate that passed." >&2
58:# A delete-only push has nothing to test. `git push --delete branch` and a deleting refspec both
62:# skip. If stdin is empty (some callers), fall through and gate — failing open on an empty read would
67:while read -r _lref _lsha _rref _rsha; do
78:  echo "pre-push: delete-only push — no gate to run."
79:  exit 0
82:if [ "${XYZ_SKIP_PREPUSH:-0}" != "0" ]; then
83:  # Announced, never silent: a skipped gate that says nothing is indistinguishable from a passing one.
84:  echo "pre-push: SKIPPED by XYZ_SKIP_PREPUSH — nothing was verified before this push." >&2
85:  exit 0
88:# A docs-only commit is still checked, but by the deterministic documentation gate instead of the
90:# These routes are intentionally narrow: a force push, an unavailable remote base, a URL push,
92:# `route=fast`+`tier=2` (registered utility subsystems) falls back to the full gate. A bad range
93:# must cost time, never coverage. GH-487: the FIRST push of a new branch (all-zero remote SHA) no
95:# (development, then main) of the remote being pushed to, and only when the base evidence is
99:# unverifiable, or empty-range evidence all fall back to the full gate with a named reason.
101:# GH-487: resolve each pushed ref pair to the range that classifies it. An existing remote ref
102:# uses its own SHA (the update range, exactly as before). A first push of a new branch has no
104:# local tracking ref: a backward force-push of the integration branch leaves the tracking ref
110:_push_remote="${1:-}"
114:  [ "${#_real_ref_pairs[@]}" -gt 0 ] || { _base_note="pre-push: no ref pairs to classify — running the full gate."; return 1; }
115:  local pair local_sha remote_sha cand base adv mbs
123:    case "$_push_remote" in
125:        _base_note="pre-push: remote '${_push_remote:-<none>}' is not a configured remote name (a URL push?) — no verifiable integration base, running the full gate."
130:    # carry a separate pushurl, and `git ls-remote <name>` resolves the FETCH url — which would
131:    # attest a server the push never touches. Resolve the push URL explicitly and probe that.
132:    _probe_target="$(git remote get-url --push "$_push_remote" 2>/dev/null)" || _probe_target=""
134:      _base_note="pre-push: cannot resolve a push URL for '$_push_remote' — running the full gate."
150:      _base_note="pre-push: could not verify the integration tip on '$_push_remote' via its push URL (git ls-remote failed or timed out) — running the full gate.
151:pre-push:   (if offline, bypass with 'XYZ_SKIP_PREPUSH=1 git push' or 'git push --no-verify')"
154:    while read -r _sha _ref; do
162:      _base_note="pre-push: no integration branch advertised on '$_push_remote' (neither development nor main) — running the full gate."
167:    IFS='|' read -r local_sha remote_sha <<<"$pair"
169:    case "$remote_sha" in
174:          cand="refs/remotes/$_push_remote/$cand_name"
177:          # direction is safe — so any mismatch means stale evidence, which is the full gate's
180:          mbs="$(git merge-base --all "$cand" "$local_sha" 2>/dev/null)" || { continue; }
182:            _base_note="pre-push: ambiguous integration base (multiple best common ancestors with $_push_remote/$cand_name) — running the full gate."
187:          [ "$base" != "$local_sha" ] || { base=""; continue; }   # empty range: nothing to classify
191:          [ -n "$_base_note" ] || _base_note="pre-push: no fresh merge-base with $_push_remote's integration branch (tracking ref stale or absent — fetch and retry, or take the full gate)."
196:        git cat-file -e "${remote_sha}^{commit}" 2>/dev/null || return 1
197:        git merge-base --is-ancestor "$remote_sha" "$local_sha" 2>/dev/null || return 1
198:        base="$remote_sha"
201:    _base_pairs+=("$local_sha|$base")
206:classify_push() {
210:  local pair local_sha base
212:    IFS='|' read -r local_sha base <<<"$pair"
214:    git diff --no-renames --name-only "$base" "$local_sha" || return 1
215:  done | "$REPO/utils/ci-route.sh" push
218:run_docs_gate() {
220:    echo "pre-push: docs-only route selected but the PDDA gate is missing — REFUSING the push." >&2
225:  # a documentation-only push into an accidental second blocking policy.
229:# Hand the push's changed paths to validate.sh --tier 2 (GH-35). The paths file is the contract
232:run_tier2_gate() {
234:  echo "pre-push: utility-only update — running the tier 2 subsystem gate, not the full suite (GH-35)."
235:  "$REPO/validate.sh" --print-mode --tier 2 2>&1 | sed 's/^/pre-push:   /'
238:  # gate whose width/nice policy was measured at +10, and failing gh35-test-tiers.sh's own
239:  # worker-nice pin on EVERY push. Resource policy belongs to validate.sh (GH-35's own rule).
250:  _cls="$(classify_push 2>/dev/null || true)"
255:_gate_name="full validation"
259:  _gate_name="deterministic documentation gate"
260:  echo "pre-push: docs-only update — running the documentation gate, not validate.sh."
261:  if run_docs_gate; then
262:    echo "pre-push: documentation gate GREEN in $((SECONDS - _start))s — pushing."
263:    exit 0
269:  # must say tier 2 AND name runnable suites, or this arm is skipped and the full gate runs.
270:  _paths_file="$(mktemp "${TMPDIR:-/tmp}/prepush-paths.XXXXXX")"
272:    # Same resolved bases as classify_push — the range is computed ONCE per push, never twice.
274:      IFS='|' read -r _ls _bs <<<"$pair"
277:    _gate_name="tier 2 subsystem gate (GH-35)"
278:    if run_tier2_gate "$_paths_file"; then
279:      echo "pre-push: tier 2 gate GREEN in $((SECONDS - _start))s — pushing."
281:      exit 0
287:  # An unusable paths file falls through to the full gate below — fail closed, never open.
289:  echo "pre-push: running the full gate before this push reaches the remote (GH-544)."
290:  echo "pre-push:   bypass with 'git push --no-verify' or XYZ_SKIP_PREPUSH=1 — both are recorded here, not hidden."
291:  "$REPO/validate.sh" --print-mode 2>&1 | sed 's/^/pre-push:   /'
293:  # See the note in run_tier2_gate: no outer `nice` — it is relative and stacks onto the +10
296:  # the hosted reconcile already do. It cost 1-2.7 min and an API call on every full-gate push, and a
297:  # backend hiccup refused the push. RELAY_SELF_SUFFICIENCY_SKIP=0 opts back in; relay-automation/README.md
300:    echo "pre-push: full gate GREEN in $((SECONDS - _start))s — pushing."
301:    exit 0
308:pre-push: $_gate_name RED (exit $_rc) after $((SECONDS - _start))s — push REFUSED.
312:  Hosted CI may run after the push, but this local boundary is the earliest full signal and the
315:  To push anyway (and you may have a good reason — a WIP branch, a known-red baseline):
316:    git push --no-verify
   145	
   146	def log_err(msg: str):
   147	    print(f"merge-cleanup: ERROR — {msg}", file=sys.stderr)
   148	
   149	
   150	def execute_pr_merge(pr_num: int, repo_path: Path, strategy: str = "squash", dry_run: bool = True) -> bool:
   151	    """Merges a pull request via gh CLI."""
   152	    delete_branch = pr_num not in _WITHHOLD_BRANCH_DELETE
   153	    _WITHHOLD_BRANCH_DELETE.discard(pr_num)
   154	    delete_text = " --delete-branch" if delete_branch else ""
   155	    if dry_run:
   156	        log(f"[DRY RUN] Would merge PR #{pr_num} via `gh pr merge {pr_num} --{strategy}{delete_text}`")
   157	        return True
   158	
   159	    merge_args = ["pr", "merge", str(pr_num), f"--{strategy}"]
   160	    if delete_branch:
   161	        merge_args.append("--delete-branch")
   162	    log(f"Merging PR #{pr_num} via `gh {' '.join(merge_args)}`...")
   163	    res = _gh(merge_args, repo_path, timeout=600)
   164	    if res.returncode != 0:
   165	        # GH-852: gh can fail or be killed after GitHub has merged (#810). Only GitHub's own
   166	        # MERGED + merge commit counts, the same evidence the zero-exit path requires below.
   167	        info = refresh_pr(pr_num, repo_path)
   168	        oid = (info.get("mergeCommit") or {}).get("oid")
   169	        if info.get("state") == "MERGED" and oid:
   170	            log_warn(f"`gh pr merge` exited {res.returncode} but PR #{pr_num} reads MERGED as {oid[:10]} — continuing")
   171	            return True
   172	        log_err(f"Failed to merge PR #{pr_num}: {res.stderr.strip()}")
   173	        return False
   174	    # E: a zero exit is not a landing (#510 class). The remote must say MERGED.
   175	    for _ in range(6):
   176	        info = refresh_pr(pr_num, repo_path)
   177	        if info.get("state") == "MERGED" and (info.get("mergeCommit") or {}).get("oid"):
   178	            log(f"✅ PR #{pr_num} is MERGED as {info['mergeCommit']['oid'][:10]}")
   179	            return True
   180	        time.sleep(2)
   181	    log_err(f"PR #{pr_num}: `gh pr merge` exited 0 but the PR does not read MERGED on re-query — treating as failed")
   182	    return False
   183	
  1071	            for d in gate["diagnostics"]:
  1072	                log(f"  gate: {d}")
  1073	            if not gate["green"]:
  1074	                log_err(f"PR #{p_num}: pre-merge ledger gate RED — not merged:")
  1075	                for f in gate["failures"]:
  1076	                    log_err(f"  - {f}")
  1077	                keep_workdir = True
  1078	                return 2
  1079	            log(f"PR #{p_num}: pre-merge ledger gate green on {info['headRefOid'][:10]} + origin/{branch}")
  1080	
  1081	            if dry_run:
  1082	                log(f"[DRY RUN] Would merge PR #{p_num} via `gh pr merge {p_num} --{args.strategy} --delete-branch`")
  1083	                continue
  1084	            live = refresh_pr_with_retry(p_num, primary_repo)
  1085	            if live.get("error"):
  1086	                log_err(f"PR #{p_num}: final eligibility refresh failed — {live['error']}")
  1087	                return 2
  1088	            if live.get("isDraft"):
  1089	                log(f"PR #{p_num}: SKIPPED (draft before merge)")
  1090	                failed[p_num] = "draft"
  1091	                continue
  1092	            if live.get("headRefOid") != info.get("headRefOid"):
  1093	                log_err(f"PR #{p_num}: head changed after validation — not merging")
  1094	                return 2
  1095	            _WITHHOLD_BRANCH_DELETE.discard(p_num)
  1096	            open_prs = getattr(args, "_open_prs_for_stacks", ordered_prs)
  1097	            _protect_stacked_dependents(info, open_prs, primary_repo, branch)
  1098	            if not execute_pr_merge(p_num, primary_repo, strategy=args.strategy, dry_run=False):
  1099	                return 2
  1100	            # Land it locally before anything writes into the primary. In particular, emitting
  1101	            # pr_merged before this fast-forward dirties releases.sql and can block the landing
  1102	            # (GH-624). GH-623: the fetch is bounded and retried on transient network failures.
  1103	            fetched = _retry_call(lambda: _net_git(primary_repo, ["fetch", "origin", branch]),
  1104	                                  f"post-merge fetch for PR #{p_num}")
  1105	            if fetched.returncode != 0:
  1106	                log_err(f"post-merge fetch failed: {fetched.stderr.strip()} — stopping")
  1107	                return 2
  1108	            ff = run_git(primary_repo, ["merge", "--ff-only", f"origin/{branch}"])
  1109	            if ff.returncode != 0:
  1110	                log_err(f"fast-forward to origin/{branch} FAILED: {ff.stderr.strip() or 'git refused'}")
  1111	                log_err("PR is merged remotely but the primary did not advance — reconcile by hand.")
  1112	                return 2
  1113	            if not run_post_merge_reconcile(
  1114	                    p_num, primary_repo, integration_branch=branch, dry_run=False,
  1115	                    pr_head=info.get("headRefOid")):
  1116	                log_err(f"PR #{p_num}: post-merge reconciliation FAILED — stopping before the next PR")
  1117	                return 2
  1118	            # GH-549/GH-624: report only after the merge, primary fast-forward, and reconcile
  1119	            # (including any fast-forward performed by reconciliation) all succeeded. `pr` rather
  1120	            # than `info` because the emitter reads the body for `Closes #N`.
  1121	            emit_pr_merged(primary_repo, pr, dry_run=False)
  1122	            if not commit_and_push_phase5_writes(p_num, primary_repo, branch):
  1123	                log_err(f"PR #{p_num}: post-merge writes were not made durable — stopping before the next PR")
  1124	                return 2
  1125	        # GH-623: deferrals count as non-landed outcomes too — a deferred PR blocks only its
  1126	        # HARD dependents; soft dependents were attempted above. Exit 3 keeps the shape
  1127	        # "the queue completed but not everything landed"; 2 remains a hard stop.
  1128	        # Drafts are expected skips, not a failed run. Keep them in the dependency map
TESTS-RESULTS/README.md:3:This directory contains committed execution artifacts, benchmark datasets, and structured telemetry logs from autonomous testing campaigns (such as ATE variation runs, fuzzing loops, and harness evaluations).
PROJECT/PDDA.md:197:prove or kill a risky approach before committing the plan to it. Their output is durable **memory**, and under
PROJECT/PDDA.md:242:stream lives in GitHub (machine-queryable state, labels, commit↔issue linkage); the execution
PROJECT/PDDA.md:252:one-liner, formatting — commit directly with a clear message and no issue. When in doubt, open the
PROJECT/PDDA.md:278:- When execution starts, **promote** it to `PROJECT/2-WORKING/` — keep the `GH-` prefix for provenance —
PROJECT/PDDA.md:303:- each finding still carries a stable `check` id (e.g. `pdda-check-frontmatter`) in stdout and the
PROJECT/PDDA.md:418:  commit by more than `PDDA_CHANGELOG_STALE_DAYS` days (default `0`)
PROJECT/PDDA.md:654:  verifies recorded status, not independent authorship or exact reviewed SHA.
PROJECT/PDDA.md:730:  accounted for, so a block for it is by definition a duplicate. That is testable in a way "is this
PROJECT/PDDA.md:791:the ledger, checks evidence-backed contradictions against `CHANGELOG.md`, reachable commits, merged
PROJECT/PDDA.md:924:default `observe`.** (So an env var overrides a committed `.pdda-mode` — convenient for a one-off
PROJECT/PDDA.md:925:`PDDA_MODE=observe` pass against a repo otherwise committed to `full`.) The point is an **adoption
PROJECT/PDDA.md:940:  committing `.pdda-mode` with `full`.
PROJECT/PDDA.md:994:updated **at the end of each iteration**. It is the one narrative/provenance log this contract
PROJECT/PDDA.md:999:provenance/narrative log, and it also absorbs the run-specific compliance findings the retired
PROJECT/PDDA.md:1020:  dated correction, not by editing history. This is the provenance guarantee the retired RECAP
PROJECT/PDDA.md:1039:  even in `full`) when the newest dated entry predates the latest git commit by more than
PROJECT/PDDA.md:1153:These need a decision before the automation should be considered stable:

exec
/bin/zsh -lc "nl -ba .github/workflows/ci.yml | sed -n '98,139p;330,455p'; nl -ba utils/gate-record.sh | sed -n '35,155p'; nl -ba skills/2-daily/merge-cleanup/SKILL.md | sed -n '139,176p;212,233p'; cat TESTS-RESULTS/README.md" in /private/var/folders/69/3l_82qtj7fzglnt_jjg07jh40000gn/T/consult-wt-43891-m8ixsws8
 succeeded in 0ms:
    98	on:
    99	  push:
   100	    branches: [main, development]
   101	  pull_request:
   102	    branches: [main, development]
   103	  workflow_dispatch:
   104	
   105	concurrency:
   106	  # Cancel superseded runs within the same event lane. Keep manual integration runs
   107	  # independent so a branch push cannot cancel an operator-requested full gate.
   108	  group: ${{ github.workflow }}-${{ github.event_name }}-${{ github.event.pull_request.number || github.ref }}
   109	  cancel-in-progress: true
   110	
   111	permissions:
   112	  contents: read
   113	
   114	jobs:
   115	  # GH-509 Phase 4 — THE PROMOTION BOUNDARY. This is the only job whose green means anything about
   116	  # what we ship, because it is the only one running the platform we ship to.
   117	  #
   118	  # WHY IT IS RARE, AND MUST STAY RARE: hosted macOS runners bill at roughly 10x Linux. At the volume
   119	  # this repo generates (37 pushes to `development` in one 24h sample) macOS-everywhere would cost
   120	  # thousands a month. Do NOT add `pull_request` here.
   121	  #
   122	  # WHY `workflow_dispatch` WAS REMOVED (2026-08-13, measured — this was the original design and it
   123	  # did not survive contact with the invoice). The theory was that a dispatch costs "well under a
   124	  # dollar a handful of times a month". The org's actual August usage says otherwise: macOS 3-core
   125	  # 75 minutes = **$4.65 net**, against Ubuntu's 2,740 minutes = $4.44 net. Seventy-five macOS minutes
   126	  # cost more than 2,740 Linux minutes, because macOS bills ~10x AND draws no included-minute discount
   127	  # on a private repo. Three dispatches on one branch in one day consumed roughly half a $10 monthly
   128	  # budget. The gating was correct; what was missing was any brake on how often the deliberate trigger
   129	  # gets pulled — and "deliberate" is not a rate limit when the same person can dispatch it while
   130	  # iterating on the workflow itself.
   131	  #
   132	  # WHAT THIS COSTS US, STATED PLAINLY: the original argument for `workflow_dispatch` was real —
   133	  # work lands on `development` and `main` sees almost nothing, so a main-only boundary arrives AFTER
   134	  # the promotion decision rather than before it. That gap is now open. The substitute is the LOCAL
   135	  # gate on the platform we ship to: `./validate.sh` (and, per GH-528, `--parallel N` for a ~3-minute
   136	  # run) plus `utils/gate-record.sh`, which is self-reported and does NOT qualify a promotion. If a
   137	  # pre-merge macOS witness is needed for a specific commit, re-enable this trigger deliberately,
   138	  # spend the ~$1.25-1.50, and turn it back off — rather than leaving it armed by default.
   139	  #
   330	          set -euo pipefail
   331	          git ls-files -- '*.sh' | while IFS= read -r file; do
   332	            [ -n "$file" ] || continue
   333	            bash -n "$file"
   334	          done
   335	
   336	      - name: Node syntax check tracked JavaScript
   337	        if: steps.route.outputs.docs_only != 'true'
   338	        run: |
   339	          set -euo pipefail
   340	          git ls-files -- 'src/*.js' 'bin/*.js' | while IFS= read -r file; do
   341	            [ -n "$file" ] || continue
   342	            node --check "$file"
   343	          done
   344	
   345	      - name: Validate .claude/settings JSON
   346	        if: steps.route.outputs.docs_only != 'true'
   347	        run: |
   348	          set -euo pipefail
   349	          git ls-files -- '.claude/settings*.json' | while IFS= read -r file; do
   350	            [ -n "$file" ] || continue
   351	            python3 -m json.tool "$file" >/dev/null
   352	          done
   353	
   354	      - name: Run PDDA deterministic gate
   355	        # PDDA owns documentation state. Run it when that state changes and at every full boundary,
   356	        # but keep its ~2.5-minute scan out of code-only fast PRs.
   357	        if: steps.route.outputs.pdda_needed == 'true'
   358	        run: |
   359	          set -euo pipefail
   360	          utils/pdda/pdda.sh run
   361	          # Checks this repo owns, kept OUTSIDE the sync-managed utils/pdda/ tree because the
   362	          # 2026-08-03 sync (cfd56b0) deleted three of them from upstream's script without a word.
   363	          # Warn-only by contract — it reports, it never gates.
   364	          utils/pdda-local-checks.sh run
   365	
   366	      # GH-308 froze the eleven Tier-A Bash twins and AGENTS.md told readers "CI supplies
   367	      # GH308_FROZEN_TWIN_BASE to reject a committed twin edit". Nothing did — the agy review of
   368	      # PR #318 caught the claim as false ([Blocker]). This is that wiring.
   369	      #
   370	      # Escape hatch: a safety defect in a frozen fallback can legitimately warrant an edit (GH-319
   371	      # left a silently-fake pre-advance gate in marathon-drive.sh under XYZ_PYTHON=0). Such a commit
   372	      # must carry a trailer naming the twin it covers, which makes the exception auditable in
   373	      # `git log` instead of invisible:
   374	
   375	      # GH-230: prove the README Quickstart's npm-dependency path works from a fresh
   376	      # clone, so a missing-install-step regression fails here instead of on a
   377	      # newcomer's machine.
   378	      - name: Install npm dependencies and run acorn-extract test
   379	        if: steps.route.outputs.docs_only != 'true'
   380	        run: |
   381	          set -euo pipefail
   382	          npm ci
   383	          bash test/acorn-extract.sh
   384	
   385	      # GH-232: the acting-agent's user/keychain config and default `git init` branch name are
   386	      # macOS-dev-machine assumptions baked into several fixture-driven tests (e.g. archive-writers.sh,
   387	      # xyz-vendor.sh do a bare `git init` and expect the resulting branch to be "main"). ubuntu-latest's
   388	      # git has no global identity and may default new repos to a non-"main" branch, so prepare both
   389	      # here rather than touch the tests themselves (out of scope for this lane).
   390	      - name: Prepare git environment for fixture-driven tests
   391	        if: steps.route.outputs.docs_only != 'true'
   392	        run: |
   393	          set -euo pipefail
   394	          git config --global init.defaultBranch main
   395	          git config --global user.email "ci@runner.invalid"
   396	          git config --global user.name "CI Runner"
   397	
   398	      # Same install as the promotion-boundary job: without pytest, wave_reconcile's qualification
   399	      # refuses by design (#750), so gh425 went red here and the python lane was skipped (#886).
   400	      - name: Install Python dependencies for the full suite
   401	        if: steps.route.outputs.docs_only != 'true'
   402	        run: python3 -m pip install --quiet --break-system-packages pytest requests PyYAML
   403	
   404	      - name: Run Fast Gate tests (Pull Request)
   405	        # Whole-job budget target: < 3 minutes for a code-only fast PR.
   406	        if: github.event_name == 'pull_request' && steps.route.outputs.route == 'fast'
   407	        env:
   408	          RELAY_SELF_SUFFICIENCY_SKIP: "1"
   409	          CHANGED_TESTS: ${{ steps.route.outputs.changed_tests }}
   410	        run: |
   411	          set -euo pipefail
   412	          FAST_TESTS=(
   413	            "worktree-isolation.sh"
   414	            "shim-worktree.sh"
   415	            "gh292-worktree-vendored-discovery.sh"
   416	            "relay-target-root.sh"
   417	            "relay-target-root-paths.sh"
   418	            "relay-target-root-relayfile.sh"
   419	            "relay-target-root-newfile.sh"
   420	            "gh289-target-root-build-turn.sh"
   421	            "gh410-containment-advisory.sh"
   422	            "tick-foreign-cwd.sh"
   423	            "mktemp-trap-guard.sh"
   424	          )
   425	          if [[ -n "$CHANGED_TESTS" ]]; then
   426	            IFS=',' read -r -a routed_tests <<<"$CHANGED_TESTS"
   427	            for t in "${routed_tests[@]}"; do
   428	              already_listed=0
   429	              for existing in "${FAST_TESTS[@]}"; do
   430	                [[ "$existing" == "$t" ]] && { already_listed=1; break; }
   431	              done
   432	              [[ "$already_listed" -eq 1 ]] || FAST_TESTS+=("$t")
   433	            done
   434	          fi
   435	          FAILED=0
   436	          for t in "${FAST_TESTS[@]}"; do
   437	            echo "=== $t ==="
   438	            bash "test/$t" || FAILED=1
   439	          done
   440	          exit "$FAILED"
   441	
   442	      # GH-232: PR #231 ran the full ./validate.sh suite on ubuntu-latest for the first time and
   443	      # found ~12 failures, assumed to be Ubuntu-environment-only and scoped out of CI. Re-diagnosed
   444	      # directly against a real ubuntu:latest container (not guessed at from macOS): almost all were
   445	      # masked by two things, now both fixed — (1) marathon.sh/marathon-drive.sh (and dependents
   446	      # debug-mantra.sh/driver-lock.sh) used a BSD-only `sed -i ''` invocation that mis-parses under
   447	      # GNU sed; (2) driver-lock.sh/xyz-harness-hooks.sh stubbed CLAUDE_BIN/AGY_BIN but not
   448	      # CODEX_BIN — the actual default builder — so they only "passed" locally because a real `codex`
   449	      # binary happened to be on the developer's own PATH, masking the gap; ubuntu CI has no such
   450	      # binary. path-integrity.sh/archive-writers.sh/relay-file-seeding-visibility.sh/xyz-vendor.sh/
   451	      # hq.sh/relay-pkg-freshness.sh all passed cleanly once re-tested for real — no ubuntu-specific
   452	      # bug in any of them. Registry concurrency is now unregistered by operator disposition
   453	      # (GH-854/GH-917); its retained manual suite must not appear in --skip.
   454	      # GH-379: this step CALLS validate.sh. It must never go back to iterating suites itself.
   455	      #
    35	    *) echo "gate-record: unknown argument: $1" >&2; exit 2 ;;
    36	  esac
    37	done
    38	
    39	# Resolve to absolute BEFORE the `cd "$REPO"` below, or a relative --suite-log silently resolves
    40	# against the wrong directory and the hash is quietly omitted.
    41	[ -n "$SUITE_LOG" ] && case "$SUITE_LOG" in /*) ;; *) SUITE_LOG="$PWD/$SUITE_LOG" ;; esac
    42	[ -n "$VERDICTS" ]  && case "$VERDICTS"  in /*) ;; *) VERDICTS="$PWD/$VERDICTS"   ;; esac
    43	cd "$REPO" 2>/dev/null || { echo "gate-record: no such repo: $REPO" >&2; exit 2; }
    44	
    45	# `--verify` is load-bearing: bare `git rev-parse HEAD` in a repo with NO COMMITS prints the
    46	# literal string "HEAD" to stdout while erroring, so the no-commit branch below never fired and this
    47	# script cheerfully wrote `.gate-evidence/HEAD.txt`. Caught by test/gh509-gate-evidence.sh case 3.
    48	sha="$(git rev-parse --verify HEAD 2>/dev/null || true)"
    49	if [ -z "$sha" ]; then
    50	  echo "gate-record: no commit to record against (not a git repo, or no commits)" >&2
    51	  exit 4
    52	fi
    53	
    54	# THE REFUSAL IS THE WHOLE INTEGRITY STORY. A record keyed to a commit hash while uncommitted edits
    55	# sit in the tree attests to a state that was never tested — worse than no record, because it reads
    56	# as evidence. Refuse, say why, and name what made it dirty rather than leaving the operator to guess.
    57	dirty="$(git status --porcelain 2>/dev/null | head -5)"
    58	if [ -n "$dirty" ]; then
    59	  echo "gate-record: REFUSED — working tree is dirty" >&2
    60	  echo "gate-record: a record keyed to ${sha:0:8} would name a state that was never tested" >&2
    61	  printf '%s\n' "$dirty" | sed 's/^/  /' >&2
    62	  exit 3
    63	fi
    64	
    65	# GH-536: `result: green` alone is a bare assertion about output that no longer exists by the time
    66	# anyone reads the record — a reader cannot tell "the suite ran and passed" from "someone stamped
    67	# green". Two additions fix that, and neither changes what the record MEANS.
    68	#
    69	# `output-sha256` makes the record TAMPER-EVIDENT: edit the transcript afterwards and the hash stops
    70	# matching. It deliberately does NOT make the record attested — a hash you compute on your own
    71	# machine over output you produced proves diligence, not provenance, and someone can still stub a
    72	# suite and hash the doctored result. That distinction is why the disclaimer below is unchanged:
    73	# #536 argued this earns a higher trust level, and it does not. Promotion still needs the hosted run.
    74	sha256_of() {
    75	  if command -v shasum >/dev/null 2>&1; then shasum -a 256 "$1" | awk '{print $1}'
    76	  elif command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" | awk '{print $1}'
    77	  else echo "unavailable"; fi
    78	}
    79	
    80	mkdir -p .gate-evidence
    81	{
    82	  printf 'commit: %s\n' "$sha"
    83	  printf 'result: green\n'
    84	  printf 'scope: full local suite (ci-local.sh, %s)\n' "$(uname -s)"
    85	  printf 'host: %s %s\n' "$(uname -s)" "$(uname -r)"
    86	  printf 'recorded: %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    87	  if [ -n "$SUITE_LOG" ] && [ -f "$SUITE_LOG" ]; then
    88	    printf 'output-sha256: %s\n' "$(sha256_of "$SUITE_LOG")"
    89	    printf 'output-bytes: %s\n' "$(wc -c < "$SUITE_LOG" | tr -d ' ')"
    90	  else
    91	    # Say so rather than omitting the field. A record missing a line reads as an older format; a
    92	    # record that states the transcript was unavailable cannot be mistaken for one that had it.
    93	    printf 'output-sha256: unavailable (no suite transcript passed to gate-record)\n'
    94	  fi
    95	  printf 'NOT-promotion-evidence: self-reported; promotion needs a hosted macOS run (GH-509)\n'
    96	  if [ -n "$VERDICTS" ] && [ -f "$VERDICTS" ]; then
    97	    printf 'suites: %s recorded\n' "$(grep -c . "$VERDICTS" 2>/dev/null || echo 0)"
    98	    printf -- '--- per-suite verdicts ---\n'
    99	    cat "$VERDICTS"
   100	  else
   101	    printf 'suites: not recorded (no verdict list passed to gate-record)\n'
   102	  fi
   103	} > ".gate-evidence/${sha}.txt"
   104	echo "gate-record: recorded .gate-evidence/${sha:0:8}.txt"
   105	if [ -f "utils/py/gate_receipt.py" ]; then
   106	  python3 utils/py/gate_receipt.py write --repo . --sha "$sha" --gate "ci-local.sh" --mode "sequential" --exit-code 0 >/dev/null 2>&1 || true
   107	fi
   108	exit 0
   139	   whether it is still pending or already covered. Offer keep, selectively recover via a
   140	   reviewed PR, or discard for the operator to decide. Never auto-merge, auto-delete branches,
   141	   mark disposal complete, or tear down source checkouts merely because the backup is pushed.
   142	   Include the overview in the final chat and qualifying batch issue even on a stopped run.
   143	
   144	### Phase 1: Discover & Inventory
   145	- Always includes the primary checkout from Phase 0, then locates further candidate repositories under `SAFE_ROOTS` — `~/Documents/GH Repos`, `~/agent-workspaces`, `~/Documents/agent-workspaces`, `~/marathon-clones` (where `/jog`, marathon flows and older `/start-task` runs create task clones; task clones that follow the GH-970 location decision are siblings of the primary, found with `--root "$(dirname <primary>)"`). The list in `scan_clones.py` is the list in `WORKTREE-SAFETY.md` §16.1; a test pins the parity (GH-534 A.1).
   146	- Evaluates component-aware containment (`_within(child, parent)`) and refuses `NEVER_DELETE` protected roots (`$HOME`, `~/Documents`, `~/Desktop`, `/`).
   147	- Distinguishes **Linked Worktrees** (`.git` is a file with pointer `gitdir: ...`) from **Standalone Clones** (`.git` is a directory).
   148	- Uses `git worktree list --porcelain` to determine parent-child relationships.
   149	
   150	### Phase 2: Active Process & Session Inspection
   151	- Checks driver locks: `.git/relay-driver.lock` (or vendored `.relay-driver.lock`) and validates holder PID liveness via `kill -0 <pid>`.
   152	- Checks `.tick/` active claims through the **event log fold**, never `STATE.md` (a derived snapshot): `tick claims --json` with `TICK_REPO_ROOT` pinned to the coordination root (a linked worktree's is its parent clone's). Any claimed task → `ACTIVE_TICK_CLAIM` naming task and agent; a `.tick/locks/` entry of any shape counts; `tick` missing, failing, or an events directory that is missing/unreadable → `PRESERVE_UNVERIFIED_SESSION` naming why (GH-534 A.4, `decisions/2026-09-09-tick-claims-verb.md`).
   153	- Checks live file handles via `lsof -F pcn +D <checkout>` from a CWD outside it. Three outcomes, because `lsof +D` exits 1 whether idle or held: a normal exit with code 0/1 **and** empty stderr is a complete enumeration (matches → `ACTIVE_PROCESS` naming PIDs and commands, none → verified idle); a signal-killed/timed-out/absent `lsof`, or **any** stderr line (`WARNING: can't opendir`), is incomplete → `PRESERVE_UNVERIFIED_SESSION` naming the warning.
   154	- **Activity Window Ladder (10m + 60m Recency Detection):** Inspects non-ephemeral file modification timestamps (`mtime` ignoring `.git`, `node_modules`, `.venv`, `.DS_Store`, and `*.sqlite-wal`/`*.sqlite-shm`) to classify:
   155	  - **`ACTIVE_WRITING`** ($\le 10$m): In-progress active editing.
   156	  - **`RECENT_IDLE`** ($10\text{m} - 60\text{m}$): Paused session, recent edits.
   157	  - **`DORMANT`** ($> 60$m): Zero file modifications in over an hour.
   158	  - When open file handles are detected on a `DORMANT` checkout, `ACTIVE_PROCESS` is annotated with `(Dormant handle: 0 files modified in >60m)` to distinguish idle background handles from active editing.
   159	- Honors explicit user exclusion patterns (e.g. `--exclude gh427`). A bare PR number (`--exclude 427`) also drops that PR from the Phase 4 queue, logged as `excluded by --exclude` (GH-736).
   160	
   161	### Phase 3: Git Safety & Worktree Verification
   162	- **Dirty status:** reads the complete NUL-safe `git status --porcelain -z --untracked-files=all` and names **every** file in the disposition. There is no regenerable-artifact allowance: `harnesses.db` carries invocation data, `*.db.bak` may be the last pre-rebuild copy (GH-534 A.3).
   163	- **Stashes:** Asserts `git stash list` is empty (0 unpopped stashes).
   164	- **Landed vs unlanded refs, by provenance (A.2):** after a verified `git fetch origin <integration-branch>`, every local ref tip — all `refs/heads/*`, detached `HEAD`, any local-only ref — must be either (1) reachable from `origin/<integration-branch>`, or (2) the exact `headRefOid` of a **MERGED** PR (base = integration branch, `gh pr list --state merged`, remote identity bound to the clone's `origin`) whose merge commit is reachable **and** whose landed content equals the branch's — per-path blob ids and modes from `git diff --raw --full-index`, so whitespace and binaries count. Anything else is `PRESERVE_UNPUSHED` naming the ref, the commit and the reason (no merged PR; content differs from PR #N; lookup unavailable). Squash merges no longer read as "unpushed forever"; a changed conflict resolution or a commit after the PR head still preserves. `git cherry` is never an authorization input.
   165	- **Completion Confidence & Agent Follow-up (Medium Scan Ladder):**
   166	  - **Medium Scan:** Inspects commit logs for QA attestations (`relay-drive: attest ... approved`, `status — final QA approved`, `LGTM`, `QA approved`), working tree cleanliness, and PDDA task checklists under `PROJECT/2-WORKING/`.
   167	  - **Deep Scan Escalation:** If unlanded commits exist without QA attestation, marks confidence as `MEDIUM` and recommends a deeper scan. The deeper scan is [`/merge-cleanup-deep`](https://github.com/HiQS-Labs/XYZ-forge/blob/development/skills/3-weekly/merge-cleanup-deep/SKILL.md) (GH-728): it consumes this skill's `scan_clones.py --json` audit, zips every preserved checkout to a dated backup, fans out ≤3 read-only sub-agents by branch family, and returns PR-WORTHY / SUPERSEDED / NEEDS-OWNER / ABANDON-CANDIDATE verdicts with the deciding evidence; disposable checkouts come back here for Phase 6 teardown. `/recon` or `/debug-mantra` remain the tools for a single clone's conflict.
   168	  - **Agent Follow-up:** Identifies the owning agent (via `.tick` claim, author/co-author, or PID command name) and provides actionable follow-up guidance.
   169	- **Canonical GitHub Issue Marker (`--marker`):**
   170	  - Resolves linked canonical issue (via branch name, directory name, or commit log regex) and formats a structured status checkpoint comment to post to GitHub.
   171	- **Worktree dependencies:** Verifies no other linked worktrees point to a clone before marking it disposable.
   172	- **Every safety query fails closed (A.5):** a non-zero or unparseable `git status`, `stash list`, `worktree list`, `for-each-ref`, `fetch`, `tick claims` or `lsof` → `PRESERVE_UNVERIFIED_QUERY` / `PRESERVE_UNVERIFIED_SESSION` naming the query. No result is ever defaulted to "none".
   173	
   174	### Phase 4: PR Matrix & Topological Sorting
   175	- Runs only after Phase 0 has reported. The PR sequence is advice until the primary can receive it.
   176	- Fetches open PRs via GitHub API (`gh pr list`). The discovery call is bounded in time and retried on transient network failures (GH-623): a FAILED discovery is an error, never an empty queue — after three transient retries it exits 2 before Phase 6, because rolling into teardown on a false "no PRs" would report success while the queue was silently skipped.
   212	
   213	`/merge-cleanup` is a driven workflow, not a one-shot report. Follow the loop; do not stop at the
   214	first refusal, do not degrade the scope silently, and do not report completion over PRs that were
   215	never attempted:
   216	
   217	1. **Dry run first** (Phase 0 + audit + sequence):
   218	   `python3 skills/2-daily/merge-cleanup/scripts/merge_cleanup.py --primary "$PRIMARY" --prefix <name>`
   219	2. **Fix the primary** so Phase 0 reports landing-ready (commit or park the dirty intake files per
   220	   the Phase 0 rules). A dirty primary is a blocker to FIX, not a reason to silently switch to
   221	   `--teardown-only` and still report completion (the incident's S1 false-Done). If a blocker
   222	   cannot be resolved autonomously, finish every independent step first, then report the blockers
   223	   and stop — address them or report them; never silently truncate the task.
   224	3. **Execute:** add `--execute`. If the sequenced queue holds **≥3 PRs**, open the batch issue first
   225	   — see [Batch issue protocol (GH-944)](#batch-issue-protocol-gh-944--caller-owned-for-queues-of-three-or-more) —
   226	   and keep it current through the run.
   227	4. **On exit 3** (handoff / park / defer): read the printed `export MERGE_CLEANUP_RECORD=...`
   228	   paths, work the caller ladder below for handoffs, then **re-run with `--resume --execute`** to
   229	   continue the queue. Repeat until exit 0 or a stop. Deferred PRs (network) are named in the
   230	   summary; they are not PR failures — re-run once the network is healthy.
   231	5. **On exit 2**: diagnose before anything else; the diagnostic names the gate. A re-run is only
   232	   valid once the cause is fixed.
   233	
# Test Results & Artifacts (`TESTS-RESULTS/`)

This directory contains committed execution artifacts, benchmark datasets, and structured telemetry logs from autonomous testing campaigns (such as ATE variation runs, fuzzing loops, and harness evaluations).

## Purpose

Per repo rail **Rule 6 ("Verified beats plausible" / GH-430)**, claims cited in issues, PRs, ROADMAP entries, or model registries must be backed by retained, verifiable evidence. This directory provides a permanent, auditable home for these empirical test receipts.

## Directory Structure

Each testing campaign is recorded in a dedicated subfolder following the naming convention:

```
TESTS-RESULTS/
├── README.md
└── YYYY-MM-DD+GH-<issue-number>/
    ├── SUMMARY.md                          # Human-readable rollup & configuration details
    ├── error_log.jsonl                     # Structured telemetry & classifier output
    └── <benchmark-name>.jsonl              # Raw baseline measurements & metrics
```

### Contents of Each Folder

1. **`SUMMARY.md`**: Overview of the run, duration, model/harness under test, variations matrix, and high-level findings.
2. **`error_log.jsonl`**: Machine-readable JSONL records containing versioned schemas (`schema_version: "1.0"`), iteration metrics (`duration_ms`, `turn_count`, `prompt_tokens`, `completion_tokens`, `total_tokens`), command outputs, and local LLM classifications.
3. **Receipts & Baselines (`*.jsonl`)**: Raw trial outputs backing entries in `HARNESS-MODELS-REGISTRY.md` or active working docs.

## How to Inspect Results

To inspect recent runs or summarize triage distributions:

```bash
python3 utils/ate/scripts/checkin.py --tail 50 \
  --log "TESTS-RESULTS/YYYY-MM-DD+GH-<issue-number>/error_log.jsonl"
```

exec
/bin/zsh -lc "rg -n '1012|primary|push|promotion' PARKED/* | head -60; nl -ba PROJECT/PDDA.md | sed -n '638,658p'; rg -n 'freeze|head|recovery|rollback|revert' PROJECT/1-INBOX/GH-1012-STABLE-PROMOTION.md" in /private/var/folders/69/3l_82qtj7fzglnt_jjg07jh40000gn/T/consult-wt-43891-m8ixsws8
 succeeded in 0ms:
PARKED/2026-08-20-gh103-timeline-spike.md:20:  Candidate homes: `utils/pdda/pdda.sh releases` (warn-only lane) or the pre-push tier registry
PARKED/2026-08-19-session-close.md:30:| [#59](https://github.com/HiQS-Labs/XYZ-forge/issues/59) | P2 | Re-arm hosted CI: repo is public, Actions enabled, triggers in ci.yml — yet pushes produce zero runs. Find the cause, then narrow triggers to push/merge on `development`+`main`, then wire the required status check behind `main`'s branch protection (protection is already live, PR-required). | `check: gh issue view 59 --json state` |
PARKED/2026-08-19-session-close.md:31:| [#58](https://github.com/HiQS-Labs/XYZ-forge/issues/58) | P2/P3 | GH-35 Phase 3 follow-ups: tier-2 skips the hygiene suites (security-scan, mktemp-trap-guard, path-integrity, checkjs) — P2; `--tier 3 --subsystem X` silently runs tier 2 — P3; pre-push mktemp-failure path contradicts its comment (`_rc` unbound) — P3. Recommended: ride with Phase 3's registry widening, not before. | `check: gh issue view 58 --json state` |
PARKED/2026-08-19-session-close.md:62:  files including validate.sh). Never pushed, no worktree. Deleted;
PARKED/2026-09-23-gh762-followups.md:4:reconciled. They stay in their issue/PDDA homes; this file is the visibility and promotion pointer.
PARKED/2026-10-05-gh976-session.md:19:  it **set** when the primary clone holds a live driver lock. Next check: whether `validate.sh` should
PARKED/2026-10-05-gh970-merge-cleanup-wording.md:5:  placement to `/start-task`; after GH-970, start-task clones are siblings of the primary. Codex GH-970 review nit.
PARKED/2026-10-05-gh970-merge-cleanup-wording.md:7:  ("legacy and marathon clones; pass `--root "$(dirname <primary>)"` for start-task siblings") into the next
PARKED/2026-09-07-clone-inventory.md:3:13 XYZ-forge clones on disk (~1.2 GB) plus the primary checkout. Snapshot taken
PARKED/2026-09-07-clone-inventory.md:16:untracked in the primary checkout at `~/Documents/GH Repos/XYZ-forge`.
PARKED/2026-09-07-clone-inventory.md:32:`git push origin development` — PID 97203, started 2026-09-07 22:51, still
PARKED/2026-09-07-clone-inventory.md:34:last 24 h. **Do not delete while that push is in flight.** Re-check the PID,
PARKED/2026-09-07-clone-inventory.md:35:confirm whether the push landed or hung, then retire the clone.
PARKED/2026-09-07-clone-inventory.md:37:This is the background-push race the session memory warns about.
PARKED/merge-cleanup-audit-2026-09-09.md:3:## Phase 1-3: checkout inventory (8 standalone clones + 1 primary; ZERO linked worktrees)
PARKED/merge-cleanup-audit-2026-09-09.md:7:| **primary** `GH Repos/XYZ-forge` | feat/gh518-muse-harness-route | 6 M + 4 ?? | (PR 520 pushed) | PRIMARY — dirty, blocks ff-merge |
PARKED/merge-cleanup-audit-2026-09-09.md:11:| marathon-clones/marathon-gh-490-roadmap-db-flip | marathon/gh-490-prep | 0 | prep branch fully pushed; local `development` holds **6** commits absent from BOTH origin/development and origin/marathon/gh-490-prep | PRESERVE_UNPUSHED — also PR 495 source |
PARKED/merge-cleanup-audit-2026-09-09.md:12:| GH Repos/XYZ-forge-gh516-express-v2 | feat/gh516-express-v2 | 0 | fully pushed | HOLD until PR 519 lands, then disposable |
PARKED/merge-cleanup-audit-2026-09-09.md:20:**Teardown eligibility: 0 of 7 in-scope clones.** Every one holds unpushed commits, uncommitted
PARKED/merge-cleanup-audit-2026-09-09.md:25:None of the clones shares the primary's object store: every one has its own `.git` with no
PARKED/merge-cleanup-audit-2026-09-09.md:27:primary checkout are therefore invisible to all of them.
PARKED/merge-cleanup-audit-2026-09-09.md:35:| 520 | GH-518 muse-turn shim + fail-closed model policy | **CLEAN / MERGEABLE** | primary (current branch) |
PARKED/merge-cleanup-audit-2026-09-09.md:64:`LEADERBOARD.md`, renumber only unpublished CHANGELOG entries, run the gate, push. Per the
PARKED/merge-cleanup-audit-2026-09-09.md:65:recorded session trap, the gate must run in a throwaway clone — the primary goes RED because the
PARKED/handoff-pr519-agy-relay.md:17:2. Work in a **disposable full clone**, not in the primary checkout at
PARKED/handoff-pr519-agy-relay.md:21:   Reason this is mandatory: gate runs in the primary go RED because the Antigravity language
PARKED/handoff-pr519-agy-relay.md:74:Once the branch is repaired, gated green, and pushed, run a `/relay-xyz` loop with **agy** as
PARKED/handoff-pr519-agy-relay.md:85:  covers the new direct-push mode rather than just passing.
PARKED/handoff-pr519-agy-relay.md:103:Then, in the primary checkout:
PARKED/handoff-pr519-agy-relay.md:125:- Do not delete or tear down any clone. Eight clones currently hold unpushed work; teardown is
PARKED/PARKED.md:52:  that only accepts pushes to `development`, orphaned when #347 moved the canary. Dead code that
PARKED/GH-346-followups.md:44:- `test/gh75-dashboard.sh:11` retains `printf '%s' "$1" | grep -Fq -- "$2"` under pipefail. The full macOS gate on 039de104 reported `printf: write error: Broken pipe` and failed its trust-header assertion; its built-in sequential retry passed and the final gate passed 409/409. Source: `TESTS-RESULTS/2026-10-10+GH-1015/gh75-full-gate-failure.log`, full-gate-push.log.gz and provenance.jsonl. Dashboard/test source was unchanged by GH-1015. The runner's generic “driver-lock contention” diagnosis is not established by this artifact. This repeats the quiet-grep hazard already noted above and addressed in GH-807's separate suite. Outside the three observer-review edits; no longer a publication blocker after the existing gate's successful retry. Next CI triage: verify the helper failure and Small membership, then apply AGENTS' existing tier/retirement policy; do not add a new suite or move it into the driver-lock lane merely on the generic warning.
PARKED/2026-09-07-clone-inventory-unstuck.md:7:primary was at `c4088fae`. Every diff in that table was measured against the
PARKED/2026-09-27-gh854-window.md:7:- **merge-cleanup pushes with nothing to commit.** On #803's landing, the hosted reconcile had already written everything. `commit_and_push_phase5_writes` still ran `git push origin HEAD:development` on an up-to-date HEAD. The pre-push router routes an empty range to the full gate, so that no-op push cost an 80-minute full gate (`merge_cleanup.py`, `commit_and_push_phase5_writes`). Next check: skip the push when `HEAD == origin/<integration>` after the fetch. Candidate for the #854 branch list or a follow-up to #852.
PARKED/2026-09-27-gh854-window.md:11:## Repeat occurrence — 2026-10-10, merge batch #1012
PARKED/2026-09-27-gh854-window.md:13:After #1014's hosted reconciliation had published all writes, `commit_and_push_phase5_writes` still pushed an already-equal development HEAD. The hook launched the full suite with its cwd in the primary checkout, violating the separate-full-clone rail. The owning coordinator and descendants were stopped; no qualification is attributed to that aborted run. HEAD/origin/core.bare/tracked state and protected refs were checked, and a current-queue resume completed Phase5/Phase6 exit0 without another no-change push. The valid separate-clone hosted qualification remains 409/409 on the exact merge. Evidence: `TESTS-RESULTS/2026-10-09+GH-1012/1014-noop-push-primary-gate-interruption.json` and `final-resume-cleanup.log`. This repeats the existing finding; a code fix stays outside this merge batch. Next check remains skipping an unnecessary push after fetching and proving equality, while isolating any required mutation-heavy gate.
   638	Scope:
   639	- `PROJECT/2-WORKING/MARATHON-PLAN-*.md` and `PROJECT/3-COMPLETED/` marathon plan docs, or a target
   640	  passed via `--doc <path>`.
   641	
   642	Minimum behavior:
   643	- verify that the marathon plan doc carries an `## Acceptance & Quality Checklist`
   644	- verify each wave contains the three mandatory items: Proof of Done test suite, Post-Build Codex QA
   645	  relay, and peer review adjudication
   646	- for every checked item (`- [x]`) referencing a `relay-system/` transcript, assert that the
   647	  transcript file actually exists on disk; emit `error` on missing files (falsified / hollow check)
   648	- `--pre-pr --wave N` requires one explicit plan and a positive existing wave; require that wave's
   649	  items and receipts, while future waves remain pending. All waves still need mandatory structure.
   650	- `--pre-pr` without `--wave` requires all waves for final closeout. Docs marked `Completed` or in
   651	  `3-COMPLETED` always require all waves, even with a selector.
   652	- Codex receipts for checked or required items must have a first `STATUS:` header of `Approved` or
   653	  `Closed`. Accept Markdown links and backticked paths; reject empty/nonterminal receipts. This
   654	  verifies recorded status, not independent authorship or exact reviewed SHA.
   655	- during routine active development in `2-WORKING`, report unverified waves as `warn` so in-progress
   656	  development does not block normal gates prematurely
   657	
   658	#### RELEASES.md — release ledger
70:   Verify exact published head, independent QA, gates, merge commit and reconciliation receipts.
73:2. Pin main base and reconciled development head, enumerate the complete range and map changed
76:   agreed stop/rollback conditions; refresh if either remote moves.
86:5. Open a promotion PR from the approved development head into main. Record base/head, evidence,
88:   reviewed head matches published head, required PR checks current and review approved.
96:## Preservation and rollback
99:recoverable through explicit revert commits with reviewed/gated evidence. Main promotion is
103:version, tag or package publication is selected by this plan. Refresh exact-head evidence before
104:any merge; an active peer, changed PR head or unknown remote outcome prevents replay.

codex
**ANSWER:** Block promotion execution for now. The plan preserves the right safety requirements, but leaves publication containment, final candidate binding, and tested recovery unresolved. PR954/PR1024 remain prerequisites until explicitly deferred; this preflight does not approve their merge.

- **[Blocker] Prerequisites remain outstanding.** The plan correctly retains held drafts when the operator has not answered and protects PR1019’s active peer refresh. Complete their actual requirements or obtain explicit deferral before pinning the candidate. Do not reset attempts or compete with the peer. (`PROJECT/1-INBOX/GH-1012-STABLE-PROMOTION.md:37–43,68–72`)

- **[Blocker] Step 1 has no concrete safe coordinator path.** The coordinator calls primary-side `git push` unconditionally, including when no writes exist. That can invoke the full gate in the valued primary, contrary to the isolation contract. Merely saying “establish containment” does not resolve execution. Do not bypass hooks or silently substitute another `--primary`, which also relocates coordination state. (`skills/2-daily/merge-cleanup/scripts/merge_cleanup.py:631–648`; `ROUTER.md:85–90`; `SOP.md:203–207`)
  
  **Smallest existing path:** publish necessary task/evidence branches through normal hooked pushes from independent disposable full clones, then use ordinary GitHub PR landing and hosted reconciliation while preserving merge-cleanup’s readiness, dependency, ledger, QA and outcome checks. The primary receives verified remote commits by fast-forward without invoking its push path. If mechanically executing the coordinator is mandatory, its publication defect is an actual blocker requiring a separate bounded repair.

- **[Blocker] Evidence commits can invalidate the pinned candidate.** Step 2 pins development, but step 3 requires committing provenance afterward; independent QA receipts may also add commits. Specify how those artifacts land, then re-pin and qualify the resulting reconciled head. Retained evidence must identify the **tested SHA**, separately from the commit carrying that evidence. A passing run on an earlier head cannot qualify a later evidence-bearing head. (`PROJECT/1-INBOX/GH-1012-STABLE-PROMOTION.md:73–88`; `AGENTS.md:100–102`; `ci-local.sh:51–62,431–438`)

- **[Should] Explicitly preserve promotion ancestry and close the merge race.** The plan requires merge strategy for PR1019 but does not specify it for development → main. Use an ordinary **merge commit**, retain development, and bind submission to the reviewed head—for example, existing `gh pr merge --merge --match-head-commit <D>` semantics. Recheck main base immediately before landing; changed base/head requires refreshed range assessment. Review all of `B..D`, including reconciliation and evidence commits, rather than only the listed PRs. (`PROJECT/1-INBOX/GH-1012-STABLE-PROMOTION.md:33–35,69,73–88`; `SOP.md:263–267`; `AGENTS.md:431`)
  
  The coordinator’s current final refresh is followed by a merge command without an atomic head-match argument, so its refresh alone does not eliminate that race. (`skills/2-daily/merge-cleanup/scripts/merge_cleanup.py:159–163,1084–1098`)

- **[Blocker before main landing] Recovery is described, not demonstrated.** “Ordinary reviewed revert/fix-forward PR” is the right direction, but add a witnessed disposable-clone recovery exercise: identified last-good base, chosen merge method, appropriate revert/mainline selection, restored-tree comparison, existing checks and committed provenance. Identify who acts and when a red/absent boundary triggers recovery. Reachability of old main does not itself prove recoverability. (`PROJECT/1-INBOX/GH-1012-STABLE-PROMOTION.md:98–104`; `AGENTS.md:78–80,104–107`)

- **[Pass, with a necessary clarification] Local and hosted evidence are correctly distinct.** Run full `ci-local.sh --base B` on clean candidate `D` in a disposable macOS clone; retain its SHA record and transcript. After protected PR landing, obtain actual successful `boundary-macos` evidence for resulting main SHA `M`. Record `B`, `D`, `M` and their relationship. PR CI can skip both jobs: the boundary runs only on **push to main**, and the Ubuntu canary runs on development push or dispatch. Neither skipped checks, historical 409/409 results nor a green workflow aggregate establishes promotion qualification. (`ci-local.sh:56–62,418–419`; `.github/workflows/ci.yml:152,203–218,248–252`)

- **[Pass / unresolved execution condition] Independent QA and protections remain required.** Steps 4–6 correctly require independent relay QA and unchanged protections. This consult is not the final range review or that QA receipt. Fresh protection/required-check configuration remains unknown under this advisory’s no-provider constraint. If unchanged protections cannot admit the ordinary PR, stop; do not repeat GH-822’s toggle. (`AGENTS.md:326`; `PROJECT/1-INBOX/GH-1012-STABLE-PROMOTION.md:59–60,82–91,110`)

- **[Should] Select the stable representation before closeout.** An existing issue/PRS evidence-linked designation can name exact qualified `M`, boundary run/job and QA receipts without inventing a release version or tag. Later metadata commits must not silently transfer that designation to another SHA. State the qualification achieved, not an unsupported assertion of runtime stability. (`PROJECT/1-INBOX/GH-1012-STABLE-PROMOTION.md:92–94,102–114`)

**RECOMMENDATION:** Correct the publication path, evidence ordering, ancestry-preserving merge and tested recovery; then resolve prerequisites and perform exact-range qualification before any protected-main landing.
tokens used
101,676
**ANSWER:** Block promotion execution for now. The plan preserves the right safety requirements, but leaves publication containment, final candidate binding, and tested recovery unresolved. PR954/PR1024 remain prerequisites until explicitly deferred; this preflight does not approve their merge.

- **[Blocker] Prerequisites remain outstanding.** The plan correctly retains held drafts when the operator has not answered and protects PR1019’s active peer refresh. Complete their actual requirements or obtain explicit deferral before pinning the candidate. Do not reset attempts or compete with the peer. (`PROJECT/1-INBOX/GH-1012-STABLE-PROMOTION.md:37–43,68–72`)

- **[Blocker] Step 1 has no concrete safe coordinator path.** The coordinator calls primary-side `git push` unconditionally, including when no writes exist. That can invoke the full gate in the valued primary, contrary to the isolation contract. Merely saying “establish containment” does not resolve execution. Do not bypass hooks or silently substitute another `--primary`, which also relocates coordination state. (`skills/2-daily/merge-cleanup/scripts/merge_cleanup.py:631–648`; `ROUTER.md:85–90`; `SOP.md:203–207`)
  
  **Smallest existing path:** publish necessary task/evidence branches through normal hooked pushes from independent disposable full clones, then use ordinary GitHub PR landing and hosted reconciliation while preserving merge-cleanup’s readiness, dependency, ledger, QA and outcome checks. The primary receives verified remote commits by fast-forward without invoking its push path. If mechanically executing the coordinator is mandatory, its publication defect is an actual blocker requiring a separate bounded repair.

- **[Blocker] Evidence commits can invalidate the pinned candidate.** Step 2 pins development, but step 3 requires committing provenance afterward; independent QA receipts may also add commits. Specify how those artifacts land, then re-pin and qualify the resulting reconciled head. Retained evidence must identify the **tested SHA**, separately from the commit carrying that evidence. A passing run on an earlier head cannot qualify a later evidence-bearing head. (`PROJECT/1-INBOX/GH-1012-STABLE-PROMOTION.md:73–88`; `AGENTS.md:100–102`; `ci-local.sh:51–62,431–438`)

- **[Should] Explicitly preserve promotion ancestry and close the merge race.** The plan requires merge strategy for PR1019 but does not specify it for development → main. Use an ordinary **merge commit**, retain development, and bind submission to the reviewed head—for example, existing `gh pr merge --merge --match-head-commit <D>` semantics. Recheck main base immediately before landing; changed base/head requires refreshed range assessment. Review all of `B..D`, including reconciliation and evidence commits, rather than only the listed PRs. (`PROJECT/1-INBOX/GH-1012-STABLE-PROMOTION.md:33–35,69,73–88`; `SOP.md:263–267`; `AGENTS.md:431`)
  
  The coordinator’s current final refresh is followed by a merge command without an atomic head-match argument, so its refresh alone does not eliminate that race. (`skills/2-daily/merge-cleanup/scripts/merge_cleanup.py:159–163,1084–1098`)

- **[Blocker before main landing] Recovery is described, not demonstrated.** “Ordinary reviewed revert/fix-forward PR” is the right direction, but add a witnessed disposable-clone recovery exercise: identified last-good base, chosen merge method, appropriate revert/mainline selection, restored-tree comparison, existing checks and committed provenance. Identify who acts and when a red/absent boundary triggers recovery. Reachability of old main does not itself prove recoverability. (`PROJECT/1-INBOX/GH-1012-STABLE-PROMOTION.md:98–104`; `AGENTS.md:78–80,104–107`)

- **[Pass, with a necessary clarification] Local and hosted evidence are correctly distinct.** Run full `ci-local.sh --base B` on clean candidate `D` in a disposable macOS clone; retain its SHA record and transcript. After protected PR landing, obtain actual successful `boundary-macos` evidence for resulting main SHA `M`. Record `B`, `D`, `M` and their relationship. PR CI can skip both jobs: the boundary runs only on **push to main**, and the Ubuntu canary runs on development push or dispatch. Neither skipped checks, historical 409/409 results nor a green workflow aggregate establishes promotion qualification. (`ci-local.sh:56–62,418–419`; `.github/workflows/ci.yml:152,203–218,248–252`)

- **[Pass / unresolved execution condition] Independent QA and protections remain required.** Steps 4–6 correctly require independent relay QA and unchanged protections. This consult is not the final range review or that QA receipt. Fresh protection/required-check configuration remains unknown under this advisory’s no-provider constraint. If unchanged protections cannot admit the ordinary PR, stop; do not repeat GH-822’s toggle. (`AGENTS.md:326`; `PROJECT/1-INBOX/GH-1012-STABLE-PROMOTION.md:59–60,82–91,110`)

- **[Should] Select the stable representation before closeout.** An existing issue/PRS evidence-linked designation can name exact qualified `M`, boundary run/job and QA receipts without inventing a release version or tag. Later metadata commits must not silently transfer that designation to another SHA. State the qualification achieved, not an unsupported assertion of runtime stability. (`PROJECT/1-INBOX/GH-1012-STABLE-PROMOTION.md:92–94,102–114`)

**RECOMMENDATION:** Correct the publication path, evidence ordering, ancestry-preserving merge and tested recovery; then resolve prerequisites and perform exact-range qualification before any protected-main landing.
