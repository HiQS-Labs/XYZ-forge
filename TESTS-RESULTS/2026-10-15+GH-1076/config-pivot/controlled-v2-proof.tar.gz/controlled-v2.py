"""Unregistered controlled fixture: production @2 writer/reader and real local FF-race recovery.

Validation results are simulated fixture telemetry, never software qualification.
No registered test/case edits, installs, GitHub writes, or primary configuration changes.
"""
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from unittest.mock import patch

sys.dont_write_bytecode = True
task = Path("/Users/noelsaw/Documents/Codex/2026-10-14/task")
source = task / "forge-gh1076-spike"
out = task / "gh1076-debug"
sys.argv = ["manual-controlled-fixture", str(source)]
existing = (source / "test/gh740-hosted-lane-publish.sh").read_text()
existing = existing.split("<<'PY'\n", 1)[1].rsplit("\nPY", 1)[0].split("unittest.main(", 1)[0]
ns = {"__name__": "existing_gh740_fixture"}
exec(compile(existing, "existing-gh740-fixture", "exec"), ns)
wave = ns["wave"]
real_mkdtemp = tempfile.mkdtemp
with patch.object(tempfile, "mkdtemp", side_effect=lambda *a, **kw: real_mkdtemp(*a, **dict(kw, dir=out))):
    fixture = ns["PublishTests"]()
    fixture.setUp()
# Do not call fixture.doCleanups(): preserve all fixture repositories and unique commits.
root, writer, racer = fixture.tmp, fixture.clone, fixture.racer
(out / "controlled-v2-fixture-path.txt").write_text(str(root) + "\n")

def git(repo, *args, check=True):
    return subprocess.run(["git", *args], cwd=repo, text=True, capture_output=True, check=check)

def oid(repo):
    return git(repo, "rev-parse", "HEAD").stdout.strip()

# Seed actual current policy/config owners and existing suite names as fixture-only placeholders.
for name in ["utils/ci-route.sh", "utils/py/device_config.py"]:
    target = writer / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source / name, target)
router = (writer / "utils/ci-route.sh").read_text()
for key in ["small", "skills_army_hq"]:
    names = re.findall(r'^SUBSYSTEM_TESTS_' + key + r'="([^"]*)"$', router, re.M)[0].split()
    for name in names:
        p = writer / "test" / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("# CONTROLLED PLACEHOLDER; this suite is not executed in the demonstration.\n")
payload = writer / "skills/3-weekly/skills-army-hq/README.md"
payload.parent.mkdir(parents=True)
payload.write_text("Controlled fixture content.\n")
(writer / ".gitignore").write_text(".tick/\n")
(writer / "validate.sh").write_text('''#!/usr/bin/env bash
set -eu
echo "CONTROLLED FIXTURE: simulated validation outcomes; NO registered suites executed."
python3 - "$@" <<'FIXTURE'
import sys,os,json,pathlib,subprocess
sys.path.insert(0,os.path.join(os.environ['GH1076_SOURCE'],'utils/py'))
import wave_reconcile as w
root=os.getcwd()
sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
phase=sys.argv[sys.argv.index('--subsystem')+1]
spec=next(s for s in w.content_profile_phases(root,sha) if s[0]==phase)
_,gate,names,extras=spec
run=sha[:9]+'-'+str(os.getppid())
rows=[dict(event='run.start',commit=sha,mode='sequential',tier=2,registered=406,width=1)]
rows += [dict(event='suite',lane='sequential',name=n,rc=0,skip_lines=0) for n in names]
rows += [dict(event='suite',lane='non-suite',name=n,rc=0,skip_lines=0) for n in extras]
rows += [dict(event='stage',lane='non-suite',name='envelope-assert',rc=0)]
rows += [dict(event='run.summary',passed=len(names)+len(extras)+1,failed=0,
 total=len(names)+len(extras)+1,envelope_rc='0',envelope_drift='none',
 suite_events=str(len(names)+len(extras)),run_set=str(len(names)),registered='406',suite_events_match='yes')]
for r in rows:r.update(run=run,runner='validate')
p=pathlib.Path('.tick/telemetry');p.mkdir(parents=True,exist_ok=True)
(p/('validate-sequential-controlled-'+str(os.getppid())+'.jsonl')).write_text(''.join(json.dumps(r)+'\\n' for r in rows))
FIXTURE
''')
(writer / "validate.sh").chmod(0o755)
git(writer, "add", "-A")
git(writer, "commit", "-qm", "Controlled fixture base; validation is simulated")
git(writer, "push", "-q", "origin", "HEAD:development")
base = oid(writer)
payload.write_text(payload.read_text() + "One modified tracked content file.\n")
git(writer, "commit", "-qam", "Controlled content-only landing; no real GitHub PR")
tested = oid(writer)
git(writer, "push", "-q", "origin", "HEAD:development")
git(racer, "fetch", "-q", "origin")
git(racer, "merge", "--ff-only", "-q", "origin/development")
meta = dict(number=7, state="MERGED", baseRefName="development",
            headRefOid=tested, mergeCommit={"oid": tested}, title="CONTROLLED FIXTURE ONLY")
meta_path = root / "controlled-meta.json"
meta_path.write_text(json.dumps(meta))
settings = root / "on.json"
settings.write_text('{"ci":{"optimized":true}}\n')
bin_dir = root / "bin"
bin_dir.mkdir()
npm = shutil.which("npm")
(bin_dir / "npm").write_text('#!/bin/sh\nif [ "$1" = ci ]; then echo "CONTROLLED: npm ci simulated; no installation"; exit 0; fi\nexec ' + repr(npm) + ' "$@"\n')
(bin_dir / "npm").chmod(0o755)

spec = importlib.util.spec_from_file_location("controlled_publisher", source / "utils/py/hosted_lane_publish.py")
publisher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(publisher)
recompute = root / "recompute.py"
recompute.write_text('''import os,sys,json,pathlib,subprocess
sys.path.insert(0,os.path.join(os.environ['GH1076_SOURCE'],'utils/py'))
import wave_reconcile as w
assert '--only-receipted' in sys.argv and '--skip-pull' in sys.argv
meta=json.loads(pathlib.Path(os.environ['GH1076_META']).read_text())
entries=w.committed_qualifications(os.getcwd())
accepted=[e for e in entries if w.qualification_receipt_matches(os.getcwd(),e,meta)]
assert len(accepted)==1 and accepted[0]['schema_version']=='wave-qualification@2'
pathlib.Path(os.environ['GH1076_RECOMPUTE']).write_text(json.dumps(dict(argv=sys.argv[1:],accepted=1,suite_reruns=0)))
with open('releases.sql','a') as f:f.write('-- controlled recomputed transition after applicable @2 replay\\n')
''')
environment = dict(PATH=str(bin_dir) + os.pathsep + os.environ["PATH"],
    GH1076_SOURCE=str(source), GH1076_META=str(meta_path),
    GH1076_RECOMPUTE=str(root / "recompute-observation.json"),
    XYZ_CI_OPTIMIZED="1", XYZ_DEVICE_CONFIG_PATH=str(settings), PYTHONDONTWRITEBYTECODE="1")
capture = io.StringIO()
original_commit, original_push = publisher.commit, publisher.push
commits, pushes = [], []

def preserving_commit(paths, message):
    sha = original_commit(paths, message)
    git(writer, "update-ref", "refs/gh1076-preserved/commit-" + str(len(commits)), sha)
    commits.append(dict(sha=sha,paths=paths,message=message))
    return sha

def raced_push():
    if not pushes:
        with (racer / "releases.sql").open("a") as f:
            f.write("-- controlled racer's contribution\n")
        git(racer, "commit", "-qam", "Controlled racer; local bare remote only")
        git(racer, "push", "-q", "origin", "HEAD:development")
    result = original_push()
    pushes.append(result)
    return result

old_cwd = os.getcwd()
with patch.dict(os.environ, environment), contextlib.redirect_stdout(capture), contextlib.redirect_stderr(capture):
    try:
        os.chdir(writer)
        journal = wave.RollbackJournal(writer)
        selected = wave.select_qualification_gate(writer, [meta], dict(os.environ))
        wave.qualify_landings(str(writer), [meta], journal)
        raw_paths = list((writer / "TESTS-RESULTS").rglob("provenance.jsonl"))
        assert len(raw_paths) == 1
        entry = json.loads(raw_paths[0].read_text())
        assert entry["schema_version"] == "wave-qualification@2"
        before = {str(p.relative_to(writer)): hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in raw_paths + [writer / entry["telemetry"]]}
        with (writer / "releases.sql").open("a") as f:
            f.write("-- controlled stale transition to discard\n")
        with patch.object(publisher, "commit", side_effect=preserving_commit), patch.object(publisher, "push", side_effect=raced_push):
            rc = publisher.main(["--reconcile-args", "--pr 7 --catch-up --gate --qualify",
                                 "--reconcile-cmd", sys.executable + " " + str(recompute)])
        accepted = wave.qualification_receipt_matches(str(writer), entry, meta)
        generic_error = wave.validate_pre_merge_receipts(str(writer), oid(writer), 7)
        with patch.dict(os.environ, XYZ_CI_OPTIMIZED="0"):
            disabled_accepts = wave.qualification_receipt_matches(str(writer), entry, meta)
        after = {p: hashlib.sha256((writer / p).read_bytes()).hexdigest() for p in before}
        ledger = (writer / "releases.sql").read_text()
        report = dict(kind="CONTROLLED FIXTURE ONLY; not software/PR qualification or live hosted activation",
            source_head=git(source,"rev-parse","HEAD").stdout.strip(),fixture_root=str(root),
            fixture_base=base,fixture_tested=tested,synthetic_github_metadata=meta,
            actual_selected_gate=selected[0],production_writer_schema=entry["schema_version"],
            simulated_phases=entry["phases"],publisher_rc=rc,push_results=pushes,
            preserved_commits=commits,receipt_hashes_before=before,receipt_hashes_after=after,
            raw_receipts_byte_equal=before==after,production_reader_accepts=accepted,
            generic_premerge_error=generic_error,disabled_reader_accepts=disabled_accepts,
            recompute=json.loads((root/"recompute-observation.json").read_text()),
            racer_preserved="-- controlled racer's contribution" in ledger,
            stale_transition_discarded="-- controlled stale transition" not in ledger,
            validation_simulated=True,npm_ci_simulated=True,installations=0,
            limits="Actual production writer/reader/publisher with real local Git FF rejection and recovery. Validation outcomes and recompute transitions are fixture stubs. This is not a real eligible GitHub PR, executed registered suites or live hosted recovery.")
        assert rc==0 and pushes==[False,True,True] and accepted and not disabled_accepts
        assert generic_error and before==after and report["racer_preserved"] and report["stale_transition_discarded"]
        (out/"controlled-v2-report.json").write_text(json.dumps(report,indent=2)+"\n")
        (out/"controlled-qualification-record.json").write_text(json.dumps(dict(kind="CONTROLLED ONLY; simulated outcomes",production_output=entry),indent=2)+"\n")
    finally:
        os.chdir(old_cwd)
        (out/"controlled-v2-driver.log").write_text(capture.getvalue())
print(json.dumps({k:report[k] for k in ["fixture_root","actual_selected_gate","production_writer_schema","push_results","raw_receipts_byte_equal","production_reader_accepts","generic_premerge_error","disabled_reader_accepts","recompute","racer_preserved","stale_transition_discarded","limits"]},indent=2))
